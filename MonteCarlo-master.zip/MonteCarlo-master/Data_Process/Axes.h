#ifndef AXES_H_INCLUDED
#define AXES_H_INCLUDED

#include <cmath>
#include <vector>
#include <utility>
#include <iostream>

class axis{
    protected:

        double m_inferior_limit;
        double m_superior_limit;


    public:

        unsigned int Bins;

        axis(){}

        axis(unsigned int n_bins, double inferior_limit, double superior_limit){
            Bins = n_bins;
            m_inferior_limit = inferior_limit;
            m_superior_limit = superior_limit;
        }

        virtual ~axis(){}

        bool in_range(double data_point){
            return data_point >= m_inferior_limit && data_point <= m_superior_limit;
        }

        virtual std::pair <unsigned int, double> Bin_and_Norm(double data_point) =0;

        virtual std::vector <double> Mean_values() =0;

        virtual std::vector <double> LHS_values() =0;

        virtual std::vector <double> Norm_values() =0;
};


class lin_axis : public axis{
    public:

        lin_axis(){}

        lin_axis(unsigned int n_bins, double inferior_limit, double superior_limit)
            : axis(n_bins, inferior_limit, superior_limit) {};


        std::pair <unsigned int, double> Bin_and_Norm(double data_point){

            if ( !in_range(data_point) ) {
                std::cout << "Data point out of axis range.\n";
            }

            unsigned int bin;
            double norm;

            bin = (unsigned int) std::floor( (data_point - m_inferior_limit) * ( (double) Bins ) / (m_superior_limit - m_inferior_limit) );

            norm = ( (m_superior_limit - m_inferior_limit) / (double) Bins );

            return std::pair <unsigned int, double> (bin, norm);
        }


        std::vector <double> Mean_values(){

            std::vector <double> mean_values(Bins);

            for(unsigned int bin_number = 0; bin_number < Bins; bin_number++){
                mean_values[bin_number] = ( ( ( (double) bin_number ) + 0.5 ) * (m_superior_limit - m_inferior_limit)
                                           / ( (double) Bins ) ) + m_inferior_limit;
            }

            return mean_values;
        }


        std::vector <double> LHS_values(){

            std::vector <double> lhs_values(Bins);

            for(unsigned int bin_number = 0; bin_number < Bins; bin_number++){
                lhs_values[bin_number] = ( (double) bin_number  * (m_superior_limit - m_inferior_limit) / (double) Bins ) + m_inferior_limit;
            }

            return lhs_values;
        }


        std::vector <double> Norm_values(){

            double norm = ( (m_superior_limit - m_inferior_limit) / (double) Bins );

            std::vector <double> norm_values(Bins, norm);

            return norm_values;
        }
};


class log_axis : public axis{
    public:

        log_axis(){}

        log_axis(unsigned int n_bins, double inferior_limit, double superior_limit)
            : axis(n_bins, inferior_limit, superior_limit) {};


        std::pair <unsigned int, double> Bin_and_Norm(double data_point){

            if ( !in_range(data_point) ) {
                std::cout << "Data point out of axis range.\n";
            }

            unsigned int bin;
            double norm;

            double range_ratio = m_superior_limit / m_inferior_limit;

            double inferior_data_value;
            double superior_data_value;

            bin = (unsigned int) std::floor( ( std::log(data_point) - std::log(m_inferior_limit) ) * ( (double) Bins ) / std::log(range_ratio) );

            inferior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double) Bins ), bin );
            superior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double) Bins ), ( bin + 1 ) );

            norm = superior_data_value - inferior_data_value;

            return std::pair <unsigned int, double> (bin, norm);
        }


        std::vector <double> Mean_values(){

            double range_ratio = m_superior_limit / m_inferior_limit;

            double inferior_data_value;
            double superior_data_value;


            std::vector <double> mean_values(Bins);

            for(unsigned int bin_number = 0; bin_number < Bins; bin_number++){
                inferior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double)Bins ), bin_number );
                superior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double)Bins ), ( bin_number + 1 ) );

                mean_values[bin_number] = inferior_data_value + ( (superior_data_value - inferior_data_value) / 2.0 );
            }

            return mean_values;
        }


        std::vector <double> LHS_values(){

            double range_ratio = m_superior_limit / m_inferior_limit;

            double inferior_data_value;

            std::vector <double> lhs_values(Bins);

            for(unsigned int bin_number = 0; bin_number < Bins; bin_number++){
                inferior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double)Bins ), bin_number );

                lhs_values[bin_number] = inferior_data_value;
            }

            return lhs_values;
        }


        std::vector <double> Norm_values(){

            double range_ratio = m_superior_limit / m_inferior_limit;

            double inferior_data_value;
            double superior_data_value;


            std::vector <double> norm_values(Bins);

            for(unsigned int bin_number = 0; bin_number < Bins; bin_number++){
                inferior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double)Bins ), bin_number );
                superior_data_value =  m_inferior_limit * std::pow( std::exp( std::log(range_ratio) / (double)Bins ), ( bin_number + 1 ) );

                norm_values[bin_number] = superior_data_value - inferior_data_value;
            }

            return norm_values;
        }
};
#endif // AXES_H_INCLUDED
