#include <cmath>
#include "Structs_header.h"
#include "Conditional_Functions.h"
#include "Tracking_and_Interaction_header.h"

bool Combine_Conditions( std::vector <condition_call> v_func, neutron_struct neutron ){

    bool result = true;

    if (v_func.size() > 0) {
        for (auto & func : v_func) {
            result = result && func(neutron);
        }
    }

    return result;
}


bool In_Sphere (neutron_struct Neutron) {
    return std::sqrt( std::pow( Neutron.eos_position.x, 2.0) +
                      std::pow( Neutron.eos_position.y, 2.0) +
                      std::pow( Neutron.eos_position.z, 2.0) ) <= 100;
}


bool Is_Thermal (neutron_struct Neutron) {
    return Neutron.distribution == 1;
}


bool Is_Intermediate (neutron_struct Neutron) {
    return Neutron.distribution == 2;
}


bool Is_Fission (neutron_struct Neutron) {
    return Neutron.distribution == 3;
}


bool After_250 (neutron_struct Neutron) {
    return Neutron.step >= 250;
}

bool After_500 (neutron_struct Neutron) {
    return Neutron.step >= 500;
}

bool After_750 (neutron_struct Neutron) {
    return Neutron.step >= 750;
}

bool After_1000 (neutron_struct Neutron) {
    return Neutron.step >= 1000;
}


bool Left_Sphere (neutron_struct Neutron) {
    bool in_at_start;
    bool out_at_end;

    in_at_start = std::sqrt( std::pow( Neutron.sos_position.x, 2.0) +
                             std::pow( Neutron.sos_position.y, 2.0) +
                             std::pow( Neutron.sos_position.z, 2.0) ) <= 100;

    out_at_end = std::sqrt( std::pow( Neutron.eos_position.x, 2.0) +
                            std::pow( Neutron.eos_position.y, 2.0) +
                            std::pow( Neutron.eos_position.z, 2.0) ) > 100;

    return in_at_start && out_at_end;
}


bool Entered_Sphere (neutron_struct Neutron) {
    bool out_at_start;
    bool in_at_end;

    out_at_start = std::sqrt( std::pow( Neutron.sos_position.x, 2.0) +
                              std::pow( Neutron.sos_position.y, 2.0) +
                              std::pow( Neutron.sos_position.z, 2.0) ) > 100;

    in_at_end = std::sqrt( std::pow( Neutron.eos_position.x, 2.0) +
                           std::pow( Neutron.eos_position.y, 2.0) +
                           std::pow( Neutron.eos_position.z, 2.0) ) <= 100;

    return out_at_start && in_at_end;
}

bool U238_Reaction (neutron_struct Neutron) {
    return Neutron.isotope_of_last_interaction == 238.0;
}


bool Forward_Scattering (neutron_struct Neutron) {
    bool forward_s;
    bool largest;

    forward_s = radial_position(Neutron.eos_position) > radial_position(Neutron.sos_position);
    largest   = radial_position(Neutron.eos_position) >= Neutron.largest_R;

    return forward_s && largest;
}


bool In_Solution (neutron_struct Neutron) {
    rectangular_geometry_struct Geometry;// [cm]
    Geometry.R1 = 27.9244;
    Geometry.R2 = 28.1244;
    Geometry.R3 = 43.1244;

    return check_region(Neutron.sos_position, Geometry) == 1;
}


bool In_Shell (neutron_struct Neutron) {
    rectangular_geometry_struct Geometry;// [cm]
    Geometry.R1 = 27.9244;
    Geometry.R2 = 28.1244;
    Geometry.R3 = 43.1244;

    return check_region(Neutron.sos_position, Geometry) == 2;
}


bool In_Reflector (neutron_struct Neutron) {
    rectangular_geometry_struct Geometry;// [cm]
    Geometry.R1 = 27.9244;
    Geometry.R2 = 28.1244;
    Geometry.R3 = 43.1244;

    return check_region(Neutron.sos_position, Geometry) == 3;
}
