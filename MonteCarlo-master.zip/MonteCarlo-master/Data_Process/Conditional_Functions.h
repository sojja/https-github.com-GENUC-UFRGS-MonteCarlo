#ifndef CONDITIONAL_FUNCTIONS_H_INCLUDED
#define CONDITIONAL_FUNCTIONS_H_INCLUDED

#include <vector>
#include "Structs_header.h"

typedef bool (*condition_call)(neutron_struct);

bool Combine_Conditions( std::vector <condition_call> v_func, neutron_struct neutron );


bool In_Sphere (neutron_struct Neutron);

bool Is_Thermal (neutron_struct Neutron);

bool Is_Intermediate (neutron_struct Neutron);

bool Is_Fission (neutron_struct Neutron);

bool After_250 (neutron_struct Neutron);

bool After_500 (neutron_struct Neutron);

bool After_750 (neutron_struct Neutron);

bool After_1000 (neutron_struct Neutron);

bool Left_Sphere (neutron_struct Neutron);

bool Entered_Sphere (neutron_struct Neutron);

bool U238_Reaction (neutron_struct Neutron);

bool Forward_Scattering (neutron_struct Neutron);

bool In_Solution (neutron_struct Neutron);

bool In_Shell (neutron_struct Neutron);

bool In_Reflector (neutron_struct Neutron);

#endif // CONDITIONAL_FUNCTIONS_H_INCLUDED
