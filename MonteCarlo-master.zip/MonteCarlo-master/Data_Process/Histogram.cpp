#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include "Histogram.h"
#include "Gnuplot_Output.h"


void vector_histogram::Add (vector_histogram another) {

    if ( name != "" ) {

        if ( values.size() != 0 ) {
            if ( abscissa == another.abscissa ) {
                for (size_t i = 0; i < values.size(); i++) {

                        values[i] = values[i] + another.values[i];
                }

                norm += another.norm;
            }
        }

        else {
            abscissa = another.abscissa;
            values   = another.values;
            norm     = another.norm;
        }
    }

    else {
        abscissa = another.abscissa;
        values   = another.values;
        norm     = another.norm;
        path     = another.path;
        name     = another.name;
    }

}


void vector_histogram::Normalize() {

    if (norm != 0.0 && !normalized) {
        for (size_t i = 0; i < values.size(); i++) {
            values[i] /= norm;
        }
    }

    normalized = true;
}


void vector_histogram::TextOutput() {

    Normalize();

    std::string filename;
    filename = path + name + ".txt";

    gnuplot_plot_output(abscissa, values, filename);
}


void matrix_histogram::Add (matrix_histogram another) {

    if ( name != "" ) {

        if ( values.size() != 0 ) {
            if ( abscissa == another.abscissa && ordinate == another.ordinate ) {
                for (size_t i = 0; i < values.size(); i++) {
                    for (size_t j = 0; j < values[i].size(); j++) {

                        values[i][j] = values[i][j] + another.values[i][j];
                    }
                }

                norm += another.norm;
            }
        }

        else {
            abscissa = another.abscissa;
            ordinate = another.ordinate;
            values   = another.values;
            norm     = another.norm;
        }
    }

    else {
        abscissa = another.abscissa;
        ordinate = another.ordinate;
        values   = another.values;
        norm     = another.norm;
        path     = another.path;
        name     = another.name;
    }

}


void matrix_histogram::Normalize() {

    if (norm != 0.0 && !normalized) {
        for (size_t i = 0; i < values.size(); i++) {
            for (size_t j = 0; j < values[i].size(); j++) {
                values[i][j] /= norm;
            }
        }
    }

    normalized = true;
}


void matrix_histogram::TextOutput() {

    Normalize();

    std::string filename;
    filename = path + name + ".txt";

    gnuplot_splot_output(abscissa, ordinate, values, filename);
}
