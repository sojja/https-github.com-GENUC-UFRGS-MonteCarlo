#ifndef HISTOGRAM_H_INCLUDED
#define HISTOGRAM_H_INCLUDED

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include "Input.h"
#include "Output.h"
#include "Axes.h"
#include "Histogram_Calculator.h"
#include "Gnuplot_Output.h"


class histogram {
    public:

        std::string path;
        std::string name;

        double norm;

        bool normalized;


        histogram () {}

        histogram ( const std::string Path, const std::string Name, double Norm ) {
            path = Path;
            name = Name;
            norm = Norm;
            normalized = false;
        }

        virtual ~histogram () {}

        virtual void Normalize () =0;

        virtual void TextOutput () =0;

};


class vector_histogram : public histogram {
    public:

        std::vector <double> abscissa;
        std::vector <double> values;


        vector_histogram () {}

        vector_histogram ( const std::string Path,
                           const std::string Name,
                           std::vector <double> Abscissa,
                           std::vector <double> Values,
                           double Norm ) : histogram ( Path, Name, Norm ) {

            abscissa = Abscissa;
            values   = Values;
        }

        void Add (vector_histogram another);

        void Normalize();

        void TextOutput();
};


class matrix_histogram : public histogram {
    public:

        std::vector <double> abscissa;
        std::vector <double> ordinate;
        std::vector < std::vector <double> > values;


        matrix_histogram () {}

        matrix_histogram ( const std::string Path,
                           const std::string Name,
                           std::vector <double> Abscissa,
                           std::vector <double> Ordinate,
                           std::vector < std::vector <double> > Values,
                           double Norm ) : histogram ( Path, Name, Norm ) {

            abscissa = Abscissa;
            ordinate = Ordinate;
            values   = Values;
        }

        void Add (matrix_histogram another);

        void Normalize();

        void TextOutput();
};

#endif // HISTOGRAM_H_INCLUDED
