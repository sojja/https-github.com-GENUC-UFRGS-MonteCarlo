#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <functional>
#include <cctype>
#include <memory>
#include <cmath>
#include "Structs_header.h"
#include "Axes.h"
#include "Histogram_Calculator.h"
#include "Input.h"
#include "Output.h"
#include "Effective_Dose.h"
#include "Tracking_and_Interaction_header.h"


vector_histogram_calculator::vector_histogram_calculator(){}


vector_histogram_calculator::vector_histogram_calculator(std::string operation_mode,
                                                         axis & Abscissa,
                                                         std::vector <condition_call> conditions_vector) {

    m_sumation = 0.0;

    m_normalized       = false;
    m_flux             = false;
    m_sum_flux         = false;
    m_sum_flux_squared = false;
    m_particles        = false;
    m_dose             = false;
    m_linear           = false;

    std::transform(operation_mode.begin(), operation_mode.end(), operation_mode.begin(), std::ptr_fun<int, int>(std::toupper));
    if (operation_mode == "FLUX") {
        m_flux = true;
//        m_normalized = true;
    }
    else if (operation_mode == "DENSITY") {
//        m_normalized = true;
    }
    else if (operation_mode == "NUMBER") {
        m_normalized = true;
        m_particles  = true;
    }
    else if (operation_mode == "VALUE") {
        m_sum_flux   = true;
        m_normalized = true;
        m_particles  = true;
    }
    else if (operation_mode == "SQUARED") {
        m_sum_flux_squared = true;
        m_normalized       = true;
        m_particles        = true;
    }
    else if (operation_mode == "DOSE") {
        m_flux = true;
        m_dose = true;
    }
    else if (operation_mode == "RADIAL") {
        m_flux       = true;
        m_normalized = true;
    }

    m_abscissa = & Abscissa;

    m_conditions_vector = conditions_vector;

    m_histogram.resize(m_abscissa->Bins);
}


void vector_histogram_calculator::Increment (const double x_coordinate, const neutron_struct neutron) {

    if ( Combine_Conditions(m_conditions_vector, neutron) && m_abscissa->in_range(x_coordinate) ) {
        std::pair <unsigned int, double> x_pair;

        x_pair = m_abscissa->Bin_and_Norm(x_coordinate);

        double increment_value;

        double speed = ( std::sqrt( 2.0 * neutron.energy * (1.0 / 939.56537821) ) ) * 299792458.0;

        if (m_flux) increment_value = speed;// Neutron speed in [m/s]
        else if (m_sum_flux) increment_value = speed / x_pair.second;
        else if (m_sum_flux_squared) increment_value = std::pow( speed / x_pair.second, 2.0 );
        else if (m_linear) increment_value = speed / std::pow( radial_position(neutron.sos_position), 2.0 );
        else increment_value = 1.0;

        if (m_dose) increment_value *= eff_dose(neutron.energy);

        if ( !m_normalized && !m_dose ) m_sumation += increment_value;
        else if ( !m_normalized && m_dose ) m_sumation += increment_value / eff_dose(neutron.energy);
        else m_sumation = 0.0;

        if (m_particles) m_histogram[x_pair.first] += increment_value;
        else m_histogram[x_pair.first] += increment_value / x_pair.second;
    }

}


void vector_histogram_calculator::Renormalization(){
    if (!m_normalized){
        for (int i = 0; i < m_histogram.size(); i++){
            m_histogram[i] /= m_sumation;
        }

        m_normalized = true;

    }
}


void vector_histogram_calculator::Renormalization(double value){
    if (!m_normalized){
        for (int i = 0; i < m_histogram.size(); i++){
            m_histogram[i] /= (m_sumation * value);
        }

    m_normalized = true;

    }
}


std::vector <double> vector_histogram_calculator::Histogram(){
    return m_histogram;
}


double vector_histogram_calculator::Norm() {
    return m_sumation;
}




matrix_histogram_calculator::matrix_histogram_calculator(){}


matrix_histogram_calculator::matrix_histogram_calculator(std::string operation_mode,
                                                         axis & Abscissa,
                                                         axis & Ordinate,
                                                         std::vector <condition_call> conditions_vector) {

    m_sumation = 0.0;

    m_normalized   = false;
    m_flux         = false;
    m_flux_squared = false;
    m_dose         = false;

    std::transform(operation_mode.begin(), operation_mode.end(), operation_mode.begin(), std::ptr_fun<int, int>(std::toupper));
    if (operation_mode == "FLUX") {
        m_flux = true;
    }
    else if (operation_mode == "DENSITY") {
    }
    else if (operation_mode == "NUMBER") {
        m_normalized = true;
    }
    else if (operation_mode == "VALUE") {
        m_flux = true;
        m_normalized = true;
    }
    else if (operation_mode == "SQUARED") {
        m_flux_squared = true;
        m_normalized   = true;
    }
    else if (operation_mode == "DOSE") {
        m_flux = true;
        m_dose = true;
    }

    m_abscissa = & Abscissa;
    m_ordinate = & Ordinate;

    m_conditions_vector = conditions_vector;

    m_histogram.resize(m_abscissa->Bins);
    for (auto & line : m_histogram) line.resize(m_ordinate->Bins, 0.0);
}


void matrix_histogram_calculator::Increment (double x_coordinate, double y_coordinate, neutron_struct neutron) {

    if ( Combine_Conditions(m_conditions_vector, neutron) && m_abscissa->in_range(x_coordinate) && m_ordinate->in_range(y_coordinate) ) {
        std::pair <unsigned int, double> x_pair;
        std::pair <unsigned int, double> y_pair;

        x_pair = m_abscissa->Bin_and_Norm(x_coordinate);
        y_pair = m_ordinate->Bin_and_Norm(y_coordinate);

        double increment_value;

        if (m_flux) increment_value = ( std::sqrt( 2.0 * neutron.energy * (1.0 / 939.56537821) ) ) * 299792458.0;// Neutron speed in [m/s]
        if (m_flux) increment_value = ( std::sqrt( 2.0 * neutron.energy * (1.0 / 939.56537821) ) ) * 299792458.0;
        else increment_value = 1.0;

        if (m_dose) increment_value *= eff_dose(neutron.energy);

        if ( !m_normalized && !m_dose ) m_sumation += increment_value;
        else if ( !m_normalized && m_dose ) m_sumation += increment_value / eff_dose(neutron.energy);
        else m_sumation = 0.0;

        m_histogram[x_pair.first][y_pair.first] += increment_value / (x_pair.second * y_pair.second);
    }

}


void matrix_histogram_calculator::Renormalization(){
    if (!m_normalized){
        for (int i = 0; i < m_histogram.size(); i++){
            for (int j = 0; j < m_histogram[i].size(); j++){
                m_histogram[i][j] /= m_sumation;
            }
        }

    m_normalized = true;

    }
}


void matrix_histogram_calculator::Renormalization(double value){
    if (!m_normalized){
        for (int i = 0; i < m_histogram.size(); i++){
            for (int j = 0; j < m_histogram[i].size(); j++){
                m_histogram[i][j] /= (m_sumation * value);
            }
        }

    m_normalized = true;

    }
}


std::vector < std::vector <double> > matrix_histogram_calculator::Histogram() {
    return m_histogram;
}


double matrix_histogram_calculator::Norm() {
    return m_sumation;
}
