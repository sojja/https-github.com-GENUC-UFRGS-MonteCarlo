#ifndef HISTOGRAM_CALCULATOR_H_INCLUDED
#define HISTOGRAM_CALCULATOR_H_INCLUDED

#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
#include <functional>
#include <cctype>
#include <memory>
#include "Structs_header.h"
#include "Axes.h"
#include "Conditional_Functions.h"


class vector_histogram_calculator{
    public:

        double m_sumation;

        bool m_normalized;
        bool m_flux;
        bool m_sum_flux;
        bool m_sum_flux_squared;
        bool m_particles;
        bool m_dose;
        bool m_linear;

        axis * m_abscissa;

        std::vector <condition_call> m_conditions_vector;

        std::vector <double> m_histogram;


    public:

        vector_histogram_calculator();

        vector_histogram_calculator(std::string operation_mode,
                                    axis & Abscissa,
                                    std::vector <condition_call> conditions_vector);


        void Increment (double x_coordinate, neutron_struct neutron);


        void Renormalization();

        void Renormalization(double value);

        std::vector <double> Histogram();

        double Norm();
};


class matrix_histogram_calculator{
    protected:

        double m_sumation;

        bool m_normalized;
        bool m_flux;
        bool m_flux_squared;
        bool m_dose;

        axis * m_abscissa;
        axis * m_ordinate;

        std::vector <condition_call> m_conditions_vector;

        std::vector < std::vector <double> > m_histogram;


    public:

        matrix_histogram_calculator();

        matrix_histogram_calculator(std::string operation_mode,
                                    axis & Abscissa,
                                    axis & Ordinate,
                                    std::vector <condition_call> conditions_vector);


        void Increment (double x_coordinate, double y_coordinate, neutron_struct neutron);


        void Renormalization();

        void Renormalization(double value);


        std::vector < std::vector <double> > Histogram();

        double Norm();
};

#endif // HISTOGRAM_CALCULATOR_H_INCLUDED
