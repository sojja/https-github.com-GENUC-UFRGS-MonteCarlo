#include <cmath>

double eff_dose(double energy){

    if (energy <= 1.0E-9) return 2.40;
    else if (energy <= 1.0E-8) return 2.89;
    else if (energy <= 2.5E-8) return 3.30;
    else if (energy <= 1.0E-7) return 4.13;
    else if (energy <= 2.0E-7) return 4.59;
    else if (energy <= 5.0E-7) return 5.20;
    else if (energy <= 1.0E-6) return 5.63;
    else if (energy <= 2.0E-6) return 5.96;
    else if (energy <= 5.0E-6) return 6.28;
    else if (energy <= 1.0E-5) return 6.44;
    else if (energy <= 1.0E-5) return 6.51;
    else if (energy <= 5.0E-5) return 6.51;
    else if (energy <= 1.0E-4) return 6.45;
    else if (energy <= 2.0E-4) return 6.32;
    else if (energy <= 5.0E-4) return 6.14;
    else if (energy <= 1.0E-3) return 6.04;
    else if (energy <= 2.0E-3) return 6.05;
    else if (energy <= 5.0E-3) return 6.52;
    else if (energy <= 0.01) return 7.70;
    else if (energy <= 0.02) return 10.2;
    else if (energy <= 0.03) return 12.7;
    else if (energy <= 0.05) return 17.3;
    else if (energy <= 0.07) return 21.5;
    else if (energy <= 0.10) return 27.2;
    else if (energy <= 0.15) return 35.2;
    else if (energy <= 0.2) return 42.4;
    else if (energy <= 0.3) return 54.7;
    else if (energy <= 0.5) return 75.0;
    else if (energy <= 0.7) return 92.8;
    else if (energy <= 0.9) return 108;
    else if (energy <= 1.0) return 116;
    else if (energy <= 1.2) return 130;
    else if (energy <= 2) return 178;
    else if (energy <= 3) return 220;
    else if (energy <= 4) return 250;
    else if (energy <= 5) return 272;
    else if (energy <= 6) return 282;
    else if (energy <= 7) return 290;
    else if (energy <= 8) return 297;
    else if (energy <= 9) return 303;
    else if (energy <= 10) return 309;
    else if (energy <= 12) return 322;
    else if (energy <= 14) return 333;
    else if (energy <= 15) return 338;
    else if (energy <= 16) return 342;
    else if (energy <= 18) return 345;
    else if (energy <= 20) return 343;
    else if (energy <= 30) return 356;

}
