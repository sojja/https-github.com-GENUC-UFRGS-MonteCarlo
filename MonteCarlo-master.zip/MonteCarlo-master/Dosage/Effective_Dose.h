double eff_dose(double energy);
