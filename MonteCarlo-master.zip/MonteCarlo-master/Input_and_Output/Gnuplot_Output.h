#ifndef GNUPLOT_OUTPUT_H_INCLUDED
#define GNUPLOT_OUTPUT_H_INCLUDED

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Gnuplot_Output.h"

template <typename data_type> void gnuplot_plot_output (const std::vector <data_type>& Vector, const std::string filename) {

    unsigned int i;

    std::ofstream out_file;

    out_file.open(filename);

    for(i = 0; i < Vector.size(); i++){
        out_file << i << "\t" << Vector[i] << "\n";
    }// End for(i = 0; i < Vector.size(); i++).

    out_file.close();
}


template <typename data_type1, typename data_type2> void gnuplot_plot_output (const std::vector <data_type1>& Vector1,
                                                                              const std::vector <data_type2>& Vector2,
                                                                              const std::string filename) {

    if( Vector1.size() != Vector2.size() ){ std::cout << "output_vectors_to_graph_text_file: Vectors of different dimensions." << std::endl; }
    else{// Vector1.size() == Vector2.size()
        unsigned int i;

        std::ofstream out_file;

        out_file.open(filename);

        for(i = 0; i < Vector1.size(); i++){
            out_file << Vector1[i] << "\t" << Vector2[i] << "\n";
        }// End for(i = 0; i < Vector1.size(); i++).

        out_file.close();
    }
}


template <typename data_type1, typename data_type2, typename data_type3>
    void gnuplot_splot_output (const std::vector <data_type1>& Vector1, const std::vector <data_type2>& Vector2,
                               const std::vector < std::vector <data_type3> >& Matrix, const std::string filename) {

    if( ( Matrix.size() != Vector1.size() ) && ( Matrix[0].size() != Vector2.size() ) ){
        std::cout << "output_vectors_to_histogram_text_file: Matrix and vectors of different dimensions." << std::endl;
    }
    else{// ( Matrix.size() == Vector1.size() ) && ( Matrix[0].size() == Vector2.size() )
        unsigned int i, j;

        std::ofstream out_file;

        out_file.open(filename);

        for(i = 0; i < Vector1.size(); i++){
            for(j = 0; j < Vector2.size(); j++){
                out_file << Vector1[i] << "\t" << Vector2[j] << "\t" << Matrix[i][j] << "\n";
            }// End for(j = 0; j < Vector2.size(); j++).
            out_file << "\n";
        }// End for(i = 0; i < Vector1.size(); i++).

        out_file.close();
    }
}


#endif // GNUPLOT_OUTPUT_H_INCLUDED
