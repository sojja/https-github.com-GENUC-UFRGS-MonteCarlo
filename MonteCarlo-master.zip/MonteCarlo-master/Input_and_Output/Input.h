#ifndef INPUT_H_INCLUDED
#define INPUT_H_INCLUDED

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

//#include "multithread_logger.h"

template <typename data_type> class InputMatrix{
    private:

        std::ifstream File;

        std::string filename;

    public:

        std::vector < std::vector <data_type> > DataMatrix;

        InputMatrix(){}

        InputMatrix(const std::string name){
            filename = name;
        }


        void Filename(const std::string name){
            filename = name;
        }


        void BinaryInput(){
            unsigned int i;
            unsigned int number_of_lines;
            std::vector <unsigned int> columns_per_line(DataMatrix.size());

            File.open(filename, std::ios::binary);
            if(!File.good()){std::cout << "Warning: BAD FILE - " << filename << std::endl;}

            File.read(reinterpret_cast<char*>(&number_of_lines), sizeof(unsigned int));

                columns_per_line.resize(number_of_lines);
                DataMatrix.resize(number_of_lines);

            File.read(reinterpret_cast<char*>(&columns_per_line[0]), columns_per_line.size()*sizeof(unsigned int));

                for(i = 0; i < DataMatrix.size(); i++){DataMatrix[i].resize(columns_per_line[i]);}

            for(i = 0; i < DataMatrix.size(); i++){
                File.read(reinterpret_cast<char*>(&DataMatrix[i][0]), DataMatrix[i].size()*sizeof(data_type));
            }

            File.close();
        }

        void BinaryInput(const std::string name){
            unsigned int i;
            unsigned int number_of_lines;
            std::vector <unsigned int> columns_per_line(DataMatrix.size());

            filename = name;

            File.open(filename, std::ios::binary);
            if(!File.good()){std::cout << "Warning: BAD FILE - " << filename << std::endl;}

            File.read(reinterpret_cast<char*>(&number_of_lines), sizeof(unsigned int));

                columns_per_line.resize(number_of_lines);
                DataMatrix.resize(number_of_lines);

            File.read(reinterpret_cast<char*>(&columns_per_line[0]), columns_per_line.size()*sizeof(unsigned int));

                for(i = 0; i < DataMatrix.size(); i++){DataMatrix[i].resize(columns_per_line[i]);}

            for(i = 0; i < DataMatrix.size(); i++){
                File.read(reinterpret_cast<char*>(&DataMatrix[i][0]), DataMatrix[i].size()*sizeof(data_type));
            }

            File.close();
        }


        void Clear(){
            unsigned int i;
            for(i = 0; i < DataMatrix.size(); i++){
                DataMatrix[i].clear();
            }
            DataMatrix.clear();
        }
};


template <typename data_type> class InputVector{
    private:

        InputMatrix <data_type> input_matrix;

        unsigned int retrieval_counter;

        bool all_input_retrieved;

    public:

        InputVector(){
            retrieval_counter = 0;
            all_input_retrieved = false;
        }

        InputVector(const std::string name){
            input_matrix.Filename(name);
            retrieval_counter = 0;
            all_input_retrieved = false;
        }

//        ~InputVector(){
//            if(all_input_retrieved){
//                std::stringstream msg;
//                msg << "Vector of dimension = " << input_matrix.DataMatrix[0].size()
//                    << " and size = " << input_matrix.DataMatrix[0].size() * sizeof(data_type) << " bytes read."
//                Logger.to_file( "Log_Files/Input_Vector_Log.txt", std::this_thread::get_id(), msg.str() );
//            }
//        }


        void Filename(const std::string name){
            input_matrix.Filename(name);
        }


        void BinaryInput(){
            input_matrix.BinaryInput();
            if(input_matrix.DataMatrix.size() != 1){
                std::cout << "Warning: InputVector size is larger than 1." << std::endl;
                input_matrix.DataMatrix.clear();
                /// This must be treated as an error.
            }
            all_input_retrieved = false;
        }

        void BinaryInput(const std::string name){
            input_matrix.BinaryInput(name);
            if(input_matrix.DataMatrix.size() != 1){
                std::cout << "Warning: InputVector size is larger than 1." << std::endl;
                input_matrix.DataMatrix.clear();
                /// This must be treated as an error.
            }
            all_input_retrieved = false;
        }


        unsigned int Size_of_Vector(){
            return input_matrix.DataMatrix[0].size();
        }


        void Retrieve(data_type& destination){
            /*data_type temp; -> I must discover why this is here, or delete it. */

            if(!all_input_retrieved){
                destination = input_matrix.DataMatrix[0][retrieval_counter];
                retrieval_counter++;
                if(retrieval_counter >= input_matrix.DataMatrix[0].size()){
                    all_input_retrieved = true;
                }
            }
        }


        void Clear(){
            input_matrix.Clear();
        }


        bool DataFullyRetrieved(){
            return all_input_retrieved;
        }
};

#endif // INPUT_H_INCLUDED
