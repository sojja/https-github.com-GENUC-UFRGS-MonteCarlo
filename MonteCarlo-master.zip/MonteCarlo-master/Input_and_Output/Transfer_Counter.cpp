#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Transfer_Counter.h"


Transfer_Counter::Transfer_Counter ( unsigned int VectorSize ) {
    Trasfer_3_2.assign(VectorSize, 0);
    Trasfer_3_1.assign(VectorSize, 0);
    Trasfer_2_1.assign(VectorSize, 0);
}


Transfer_Counter::Transfer_Counter ( unsigned int VectorSize, const std::stringstream& name ) {
    Trasfer_3_2.assign(VectorSize, 0);
    Trasfer_3_1.assign(VectorSize, 0);
    Trasfer_2_1.assign(VectorSize, 0);
    filename.str(name.str());
}


void Transfer_Counter::Filename (const std::stringstream& name ) {
    filename.str(name.str());
}


void Transfer_Counter::BinaryOutput () {
    unsigned int number_of_steps;
    number_of_steps = Trasfer_3_2.size();

    std::ofstream File;
    File.open(filename.str(), std::ios::binary);
    if(!File.good()){std::cout << "Warning: BAD FILE - " << filename.str() << std::endl;}

    File.write( reinterpret_cast<const char*>(&Trasfer_3_2[0]), number_of_steps * sizeof(unsigned int) );
    File.write( reinterpret_cast<const char*>(&Trasfer_3_1[0]), number_of_steps * sizeof(unsigned int) );
    File.write( reinterpret_cast<const char*>(&Trasfer_2_1[0]), number_of_steps * sizeof(unsigned int) );

    File.close();
}


void Transfer_Counter:: BinaryInput () {
    unsigned int number_of_steps;
    number_of_steps = Trasfer_3_2.size();

    std::ifstream File;
    File.open(filename.str(), std::ios::binary);
    if(!File.good()){std::cout << "Warning: BAD FILE - " << filename.str() << std::endl;}

    File.read( reinterpret_cast<char*>(&Trasfer_3_2[0]), number_of_steps * sizeof(unsigned int) );
    File.read( reinterpret_cast<char*>(&Trasfer_3_1[0]), number_of_steps * sizeof(unsigned int) );
    File.read( reinterpret_cast<char*>(&Trasfer_2_1[0]), number_of_steps * sizeof(unsigned int) );

    File.close();
}


void Transfer_Counter::BinaryInput ( const std::stringstream& name ){
    unsigned int number_of_steps;
    number_of_steps = Trasfer_3_2.size();

    filename.str(name.str());

    std::ifstream File;
    File.open(filename.str(), std::ios::binary);
    if(!File.good()){std::cout << "Warning: BAD FILE - " << filename.str() << std::endl;}

    File.read( reinterpret_cast<char*>(&Trasfer_3_2[0]), number_of_steps * sizeof(unsigned int) );
    File.read( reinterpret_cast<char*>(&Trasfer_3_1[0]), number_of_steps * sizeof(unsigned int) );
    File.read( reinterpret_cast<char*>(&Trasfer_2_1[0]), number_of_steps * sizeof(unsigned int) );

    File.close();
}
