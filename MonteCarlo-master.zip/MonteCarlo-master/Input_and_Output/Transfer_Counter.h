#ifndef TRANSFER_COUNTER_H_INCLUDED
#define TRANSFER_COUNTER_H_INCLUDED

#include <sstream>
#include <vector>

class Transfer_Counter{
    private:

        std::stringstream filename;

    public:

        std::vector <unsigned int> Trasfer_3_2;
        std::vector <unsigned int> Trasfer_3_1;
        std::vector <unsigned int> Trasfer_2_1;


        Transfer_Counter ( unsigned int VectorSize );

        Transfer_Counter ( unsigned int VectorSize, const std::stringstream& name );

        void Filename ( const std::stringstream& name );

        void BinaryOutput ();

        void BinaryInput ();

        void BinaryInput ( const std::stringstream& name );
};

#endif // TRANSFER_COUNTER_H_INCLUDED
