#include <algorithm>
#include <cmath>
#include "Simulation.h"

simulation_limits Min_and_Max (simulation_limits first, simulation_limits second) {

    simulation_limits result;

    result.min_step = std::min(first.min_step, second.min_step);
    result.max_step = std::max(first.max_step, second.max_step);

    result.max_generation = std::max(first.max_generation, second.max_generation);

    result.min_energy = std::min(first.min_energy, second.min_energy);
    result.max_energy = std::max(first.max_energy, second.max_energy);

    result.min_step_length = std::min(first.min_step_length, second.min_step_length);
    result.max_step_length = std::max(first.max_step_length, second.max_step_length);

    result.min_time.step = std::min(first.min_time.step, second.min_time.step);
    result.max_time.step = std::max(first.max_time.step, second.max_time.step);

    result.min_time.life = std::min(first.min_time.life, second.min_time.life);
    result.max_time.life = std::max(first.max_time.life, second.max_time.life);

    result.min_time.chain = std::min(first.min_time.chain, second.min_time.chain);
    result.max_time.chain = std::max(first.max_time.chain, second.max_time.chain);

	return result;
}


double floating_point_floor (double number, int floating_decimals) {

    double result;

    result  = std::floor( number / std::pow( 10.0, std::floor( std::log10(number) - floating_decimals ) ) )
             * std::pow( 10.0, std::floor( std::log10(number) - floating_decimals ) );

    return result;
}


double floating_point_ceil (double number, int floating_decimals) {

    double result;

    result  = std::ceil( number / std::pow( 10.0, std::floor( std::log10(number) - floating_decimals ) ) )
             * std::pow( 10.0, std::floor( std::log10(number) - floating_decimals ) );

    return result;
}
