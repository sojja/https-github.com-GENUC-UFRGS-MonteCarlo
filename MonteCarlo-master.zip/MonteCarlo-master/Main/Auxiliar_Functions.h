#ifndef AUXILIAR_FUNCTIONS_H_INCLUDED
#define AUXILIAR_FUNCTIONS_H_INCLUDED

#include <vector>
#include "Simulation.h"

simulation_limits Min_and_Max (simulation_limits first, simulation_limits second);

double floating_point_floor (double number, int floating_decimals);

double floating_point_ceil (double number, int floating_decimals);

double FWHM(double energy);

std::vector <double> convoluted_flux (std::vector <double> abscissa, std::vector <double> delta, std::vector <double> values);

std::vector <double> normalize (const std::vector <double> values, const std::vector <double> delta);

#endif // AUXILIAR_FUNCTIONS_H_INCLUDED
