#include <cmath>
#include <vector>

double FWHM(double energy) {

    double E = energy;

//    if (energy < 0.5) return 0.002 * std::sqrt( E + 10000 * std::pow(E, 2) );
//    else return 0.125 * std::sqrt( E );
    return 0.002 * std::pow( ( E + 10000 * std::pow(E, 2) ), 0.25);
}


std::vector <double> convoluted_flux (std::vector <double> abscissa, std::vector <double> delta, std::vector <double> values) {

    std::vector <double> result ( abscissa.size() );

    double A;

    double a, b, c, d, e, f, g, h, soma;

    for ( unsigned int i = 0; i < abscissa.size(); i++ ) {
        result[i] = 0;

//        A = FWHM( abscissa[i] ) / ( 2.0 * std::sqrt( std::log(2.0) ) );

        for ( unsigned int j = 0; j < abscissa.size(); j++ ) {
            A = FWHM( abscissa[i] ) / ( 2.0 * std::sqrt( std::log(2.0) ) );
            a = values[j];
            b = abscissa[i];
            c = abscissa[j];
            d = std::abs(b - c);
            e = d / A;
            f = std::pow( e, 2 );
            g = std::exp( -1.0 * f );
            h = delta[j];
            soma = a * g * h;
            result[i] += soma;
//            result[i] += values[j] * std::pow( std::exp( -( abscissa[i] - abscissa[j] ) / A ), 2.0 ) * delta[j];
        }
    }

    return result;
}


std::vector <double> normalize (const std::vector <double> values, const std::vector <double> delta) {

    std::vector <double> result ( values.size() );

    double sum = 0.0;

    for ( unsigned int i = 0; i < values.size(); i++ ) {
        sum += values[i] * delta[i];
    }

    for ( unsigned int i = 0; i < values.size(); i++ ) {
        result[i] = values[i] / sum;
    }

    return result;
}
