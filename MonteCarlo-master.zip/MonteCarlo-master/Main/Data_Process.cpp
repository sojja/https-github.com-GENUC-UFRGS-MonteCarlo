#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include <memory>
#include <utility>
#include <map>
#include <iomanip>
#include <string>
#include <memory>
#include "Structs_header.h"
#include "Input.h"
#include "Axes.h"
#include "Histogram_Calculator.h"
#include "Histogram.h"
#include "Data_Process.h"
#include "Tracking_and_Interaction_header.h"



data_process_return data_process ( unsigned int interval_start,
                                   unsigned int interval_size,
                                   unsigned int execution_number,
                                   rectangular_geometry_struct& Geometry,
                                   simulation_limits Limits ) {


    /* declaring folder output path. */
    std::string simulation_type = "";

    std::string path = "../Files" + simulation_type + "/Processed_Data_Results/";
    std::string flux_path    = path + "Flux_Results/";
    std::string density_path = path + "Density_Results/";
    std::string number_path  = path + "Number_Results/";
    std::string dose_path    = path + "Dose_Results/";

    /* Declaring variables to define the iterations parameters. */
    unsigned int step, local_step;
    unsigned int neutron_number;

    /* Declaring return class. */
    data_process_return Result;

    /* Declaring auxilar neutron_struct. */
    neutron_struct Neutron;


    /* Declaring vectors of conditions. */
    std::vector <condition_call> no_condition;
    std::vector <condition_call> inSolution;
    std::vector <condition_call> inShell;
    std::vector <condition_call> inReflector;
    std::vector <condition_call> after250;
    std::vector <condition_call> after500;
    std::vector <condition_call> after750;
    std::vector <condition_call> after1000;
    std::vector <condition_call> is_thermal;
    std::vector <condition_call> is_intermediate;
    std::vector <condition_call> is_fission;

    inSolution .push_back(In_Solution);
    inSolution .push_back(After_750);

    inShell    .push_back(In_Shell);
    inShell    .push_back(After_750);

    inReflector.push_back(In_Reflector);
    inReflector.push_back(After_750);

    after250   .push_back(After_250);
    after500   .push_back(After_500);
    after750   .push_back(After_750);
    after1000  .push_back(After_1000);

    is_thermal     .push_back(Is_Thermal);
    is_thermal     .push_back(After_750);
    is_intermediate.push_back(Is_Intermediate);
    is_intermediate.push_back(After_750);
    is_fission     .push_back(Is_Fission);
    is_fission     .push_back(After_750);


    /* Declaring axes. */
    lin_axis mc_step ( (Limits.max_step - Limits.min_step), Limits.min_step, Limits.max_step );

    log_axis energy ( 100, Limits.min_energy, Limits.max_energy );

    lin_axis length ( 250, 0, Limits.max_step_length );// [m]

    lin_axis position_R ( 900, 0, 45 );

    lin_axis alpha ( 100, 0.0, 2.0 * M_PI );
    lin_axis beta  ( 100, -M_PI_2, M_PI_2 );

    log_axis step_time  ( 250, Limits.min_time.step, Limits.max_time.step );
    log_axis life_time  ( 250, Limits.min_time.life, Limits.max_time.life );
    log_axis chain_time ( 500, Limits.min_time.chain, Limits.max_time.chain );

    lin_axis lin_chain_time ( 500, Limits.min_time.chain, Limits.max_time.chain );
//
//    lin_axis distribution ( 3, 1, 4 );
//
    lin_axis generation (Limits.max_generation, 0, Limits.max_generation );


    /* Declaring histogram calculator. */
    vector_histogram_calculator N_by_step ("NUMBER", mc_step, no_condition);
//    vector_histogram_calculator thermal_by_step      ("NUMBER", mc_step, is_thermal);
//    vector_histogram_calculator intermediate_by_step ("NUMBER", mc_step, is_intermediate);
//    vector_histogram_calculator fast_by_step         ("NUMBER", mc_step, is_fission);

    vector_histogram_calculator fission_by_step    ("NUMBER", mc_step, no_condition);
    vector_histogram_calculator scattering_by_step ("NUMBER", mc_step, no_condition);
    vector_histogram_calculator capture_by_step    ("NUMBER", mc_step, no_condition);
    vector_histogram_calculator escape_by_step     ("NUMBER", mc_step, no_condition);
    vector_histogram_calculator newN_by_step       ("NUMBER", mc_step, no_condition);

    vector_histogram_calculator step_length ("DENSITY", length, no_condition);

    vector_histogram_calculator fission_step_length    ("DENSITY", length, no_condition);
    vector_histogram_calculator scattering_step_length ("DENSITY", length, no_condition);
    vector_histogram_calculator capture_step_length    ("DENSITY", length, no_condition);
    vector_histogram_calculator escape_step_length     ("DENSITY", length, no_condition);

    vector_histogram_calculator flux_by_energy ("FLUX", energy, after750);
    vector_histogram_calculator N_by_energy  ("NUMBER", energy, after750);
    vector_histogram_calculator d_by_energy  ("DENSITY", energy, after750);
    vector_histogram_calculator flux_by_energy_with_escape ("FLUX", energy, after750);
    vector_histogram_calculator thermal_by_energy      ("NUMBER", energy, is_thermal);
    vector_histogram_calculator intermediate_by_energy ("NUMBER", energy, is_intermediate);
    vector_histogram_calculator fast_by_energy         ("NUMBER", energy, is_fission);

    vector_histogram_calculator solution_flux_by_energy  ("FLUX", energy, inSolution);
    vector_histogram_calculator shell_flux_by_energy     ("FLUX", energy, inShell);
    vector_histogram_calculator reflector_flux_by_energy ("FLUX", energy, inReflector);
    vector_histogram_calculator escape_flux_by_energy    ("FLUX", energy, after750);

    vector_histogram_calculator radial_flux_250  ("RADIAL", position_R, after250);
    vector_histogram_calculator radial_flux_500  ("RADIAL", position_R, after500);
    vector_histogram_calculator radial_flux_750  ("RADIAL", position_R, after750);
    vector_histogram_calculator radial_flux_1000 ("RADIAL", position_R, after1000);

    vector_histogram_calculator radial_number_250  ("NUMBER", position_R, after250);
    vector_histogram_calculator radial_number_500  ("NUMBER", position_R, after500);
    vector_histogram_calculator radial_number_750  ("NUMBER", position_R, after750);
    vector_histogram_calculator radial_number_1000 ("NUMBER", position_R, after1000);

    vector_histogram_calculator Fissions_by_generation ("NUMBER", generation, no_condition);
    vector_histogram_calculator Captures_by_generation ("NUMBER", generation, no_condition);
    vector_histogram_calculator Escapes_by_generation  ("NUMBER", generation, no_condition);
    vector_histogram_calculator Births_by_generation   ("NUMBER", generation, no_condition);

    matrix_histogram_calculator Dens_by_R      ("DENSITY", position_R, energy, no_condition);
    matrix_histogram_calculator Flux_by_R      ("FLUX", position_R, energy, no_condition);

    vector_histogram_calculator alpha_density ("DENSITY", alpha, no_condition);
    vector_histogram_calculator beta_density  ("DENSITY", beta, no_condition);

    vector_histogram_calculator alpha_flux ("FLUX", alpha, no_condition);
    vector_histogram_calculator beta_flux  ("FLUX", beta, no_condition);

    vector_histogram_calculator Initial_Flux     ("FLUX", energy, no_condition);
    vector_histogram_calculator Initial_Alpha    ("DENSITY", alpha, no_condition);
    vector_histogram_calculator Initial_Beta     ("DENSITY", beta, no_condition);

    matrix_histogram_calculator density_by_chain_time_by_step ("DENSITY", mc_step, chain_time, no_condition);

    matrix_histogram_calculator spectrum_by_time_lin ("FLUX", lin_chain_time, energy, no_condition);
    matrix_histogram_calculator spectrum_by_time_log ("FLUX", chain_time, energy, no_condition);
    matrix_histogram_calculator density_by_time_lin  ("DENSITY", lin_chain_time, energy, no_condition);
    matrix_histogram_calculator density_by_time_log  ("DENSITY", chain_time, energy, no_condition);

    /* Defining files to be read. */
    std::stringstream initial_filename;

    std::stringstream fission_filename;
    std::stringstream scattering_filename;
    std::stringstream capture_filename;
    std::stringstream escape_filename;
    std::stringstream new_neutrons_filename;
//    std::stringstream thermalisation_filename;
//    std::stringstream transfer_filename;

    initial_filename        << "Bin_Files/Checkpoint_Files/"               << execution_number << "_0.bin";

    fission_filename        << "Bin_Files/Data_Output_Files/Fission/"      << execution_number << "_" << interval_start << ".bin";
    scattering_filename     << "Bin_Files/Data_Output_Files/Scattering/"   << execution_number << "_" << interval_start << ".bin";
    capture_filename        << "Bin_Files/Data_Output_Files/Capture/"      << execution_number << "_" << interval_start << ".bin";
    escape_filename         << "Bin_Files/Data_Output_Files/Escape/"       << execution_number << "_" << interval_start << ".bin";
    new_neutrons_filename   << "Bin_Files/Data_Output_Files/New_Neutrons/" << execution_number << "_" << interval_start << ".bin";
//    thermalisation_filename << "Bin_Files/Data_Output_Files/Thermalisation/" << execution_number << "_" << interval_start << ".bin";
//    transfer_filename  << "Bin_Files/Data_Output_Files/Transfer/"   << execution_number << "_" << interval_start << ".bin";

    /* Declaring input classes. */
    InputMatrix <neutron_struct> Initial_Input;

    InputMatrix <fission_struct> Fission_Input;
    InputMatrix <neutron_struct> Scattering_Input;
    InputMatrix <neutron_struct> Capture_Input;
    InputMatrix <neutron_struct> Escape_Input;
    InputMatrix <neutron_struct> New_Neutrons_Input;
//    InputMatrix <neutron_struct> Thermalisation_Input;
//    Transfer_Counter Transfer_Input(interval_size);

    /* Loading data. */
    Initial_Input       .BinaryInput ( initial_filename.str() );

    Fission_Input       .BinaryInput ( fission_filename.str() );
    Scattering_Input    .BinaryInput ( scattering_filename.str() );
    Capture_Input       .BinaryInput ( capture_filename.str() );
    Escape_Input        .BinaryInput ( escape_filename.str() );
    New_Neutrons_Input  .BinaryInput ( new_neutrons_filename.str() );
//    Thermalisation_Input.BinaryInput ( thermalisation_filename.str() );
//    Tranfer_Input       .BinaryInput ( transfer_filename.str() );

    /* Declaring auxiliary counting variables. */
    unsigned int total_new_neutrons = 0;
    unsigned int total_escapes      = 0;
    unsigned int total_fissions     = 0;
    unsigned int total_captures     = 0;
    unsigned int total_scatterings  = 0;

    for ( neutron_struct & neutron : Initial_Input.DataMatrix[0] ){
        Initial_Flux    .Increment(neutron.energy, neutron);
        Initial_Alpha   .Increment(neutron.direction.alpha, neutron);
        Initial_Beta    .Increment(neutron.direction.beta, neutron);
    }


    /* Counting data and assigning the result to counting vectors. */
    for(local_step = 0; local_step < interval_size; local_step++){// InputMatrix objects only store interval_size steps.

        step = local_step + interval_start;// the Counting vectors are valid for all simulation steps.


        /* Assessing escapes. */
        for(neutron_number = 0; neutron_number < Escape_Input.DataMatrix[local_step].size(); neutron_number++){
            total_escapes += 1;
            Neutron = Escape_Input.DataMatrix[local_step][neutron_number];

            Escapes_by_generation.Increment(Neutron.generation, Neutron);

            escape_by_step.Increment(step, Neutron);

            escape_flux_by_energy.Increment(Neutron.energy, Neutron);

            flux_by_energy_with_escape.Increment(Neutron.energy, Neutron);

            step_length.Increment(Neutron.step_length, Neutron);
            escape_step_length.Increment(Neutron.step_length, Neutron);
//            N_by_step.Increment(step, Neutron);

//            flux_by_energy.Increment(Neutron.energy, Neutron);
//            N_by_energy.Increment(Neutron.energy, Neutron);
//            d_by_energy.Increment(Neutron.energy, Neutron);

        }// End for(neutron_number = 0; neutron_number < Escape_Input.DataMatrix[local_step].size(); neutron_number++).


        /* Assessing captures. */
        for(neutron_number = 0; neutron_number < Capture_Input.DataMatrix[local_step].size(); neutron_number++){
            total_captures += 1;
            Neutron = Capture_Input.DataMatrix[local_step][neutron_number];

            Captures_by_generation.Increment(Neutron.generation, Neutron);

            capture_by_step.Increment(step, Neutron);

            step_length.Increment(Neutron.step_length, Neutron);
            capture_step_length.Increment(Neutron.step_length, Neutron);
//            N_by_step.Increment(step, Neutron);

//            flux_by_energy.Increment(Neutron.energy, Neutron);
//            N_by_energy.Increment(Neutron.energy, Neutron);
//            d_by_energy.Increment(Neutron.energy, Neutron);

        }// End for(neutron_number = 0; neutron_number < Capture_Input.DataMatrix[local_step].size(); neutron_number++).


        /* Assessing fissions. */
        for(neutron_number = 0; neutron_number < Fission_Input.DataMatrix[local_step].size(); neutron_number++){
            total_fissions += 1;
            Neutron  = Fission_Input.DataMatrix[local_step][neutron_number].neutron;

            Fissions_by_generation.Increment(Neutron.generation, Neutron);

            fission_by_step.Increment(step, Neutron);

            step_length.Increment(Neutron.step_length, Neutron);
            fission_step_length.Increment(Neutron.step_length, Neutron);
//            N_by_step.Increment(step, Neutron);

//            flux_by_energy.Increment(Neutron.energy, Neutron);
//            N_by_energy.Increment(Neutron.energy, Neutron);
//            d_by_energy.Increment(Neutron.energy, Neutron);
        }// End for(neutron_number = 0; neutron_number < Fission_Input.DataMatrix[local_step].size(); i++).


        /* Assessing new neutrons. */
        for(neutron_number = 0; neutron_number < New_Neutrons_Input.DataMatrix[local_step].size(); neutron_number++){
            total_new_neutrons += 1;
            Neutron  = New_Neutrons_Input.DataMatrix[local_step][neutron_number];

            Births_by_generation.Increment(Neutron.generation, Neutron);

            newN_by_step.Increment(step, Neutron);

            N_by_step.Increment(step, Neutron);
//            thermal_by_step     .Increment(step, Neutron);
//            intermediate_by_step.Increment(step, Neutron);
//            fast_by_step        .Increment(step, Neutron);

            flux_by_energy.Increment(Neutron.energy, Neutron);
            N_by_energy.Increment(Neutron.energy, Neutron);
            d_by_energy.Increment(Neutron.energy, Neutron);

            thermal_by_energy     .Increment(Neutron.energy, Neutron);
            intermediate_by_energy.Increment(Neutron.energy, Neutron);
            fast_by_energy        .Increment(Neutron.energy, Neutron);

            flux_by_energy_with_escape.Increment(Neutron.energy, Neutron);

            solution_flux_by_energy .Increment(Neutron.energy, Neutron);
            shell_flux_by_energy    .Increment(Neutron.energy, Neutron);
            reflector_flux_by_energy.Increment(Neutron.energy, Neutron);

            radial_flux_250 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_flux_500 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_flux_750 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_flux_1000.Increment(radial_position(Neutron.sos_position), Neutron);

            radial_number_250 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_number_500 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_number_750 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_number_1000.Increment(radial_position(Neutron.sos_position), Neutron);

            Dens_by_R.Increment(radial_position(Neutron.sos_position), Neutron.energy, Neutron);

            alpha_density.Increment(Neutron.direction.alpha, Neutron);
            beta_density .Increment(Neutron.direction.beta, Neutron);

            density_by_chain_time_by_step.Increment(step, Neutron.time.chain, Neutron);

            spectrum_by_time_lin.Increment(Neutron.time.chain, Neutron.energy, Neutron);
            spectrum_by_time_log.Increment(Neutron.time.chain, Neutron.energy, Neutron);
            density_by_time_lin.Increment(Neutron.time.chain, Neutron.energy, Neutron);
            density_by_time_log.Increment(Neutron.time.chain, Neutron.energy, Neutron);
        }// End for(neutron_number = 0; neutron_number < New_Neutrons_Input.DataMatrix[local_step].size(); neutron_number++).


        /* Assessing scatterings */
        for(neutron_number = 0; neutron_number < Scattering_Input.DataMatrix[local_step].size(); neutron_number++){
            total_scatterings += 1;
            Neutron  = Scattering_Input.DataMatrix[local_step][neutron_number];

            scattering_by_step.Increment(step, Neutron);

            N_by_step.Increment(step, Neutron);
//            thermal_by_step     .Increment(step, Neutron);
//            intermediate_by_step.Increment(step, Neutron);
//            fast_by_step        .Increment(step, Neutron);

            flux_by_energy.Increment(Neutron.energy, Neutron);
            N_by_energy.Increment(Neutron.energy, Neutron);
            d_by_energy.Increment(Neutron.energy, Neutron);

            flux_by_energy_with_escape.Increment(Neutron.energy, Neutron);

            thermal_by_energy     .Increment(Neutron.energy, Neutron);
            intermediate_by_energy.Increment(Neutron.energy, Neutron);
            fast_by_energy        .Increment(Neutron.energy, Neutron);

            step_length.Increment(Neutron.step_length, Neutron);
            scattering_step_length.Increment(Neutron.step_length, Neutron);

            solution_flux_by_energy .Increment(Neutron.energy, Neutron);
            shell_flux_by_energy    .Increment(Neutron.energy, Neutron);
            reflector_flux_by_energy.Increment(Neutron.energy, Neutron);

            radial_flux_250 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_flux_500 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_flux_750 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_flux_1000.Increment(radial_position(Neutron.sos_position), Neutron);

            radial_number_250 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_number_500 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_number_750 .Increment(radial_position(Neutron.sos_position), Neutron);
            radial_number_1000.Increment(radial_position(Neutron.sos_position), Neutron);

            Dens_by_R     .Increment(radial_position(Neutron.sos_position), Neutron.energy, Neutron);

            alpha_density.Increment(Neutron.direction.alpha, Neutron);
            beta_density .Increment(Neutron.direction.beta, Neutron);

            alpha_flux.Increment(Neutron.direction.alpha, Neutron);
            beta_flux .Increment(Neutron.direction.beta, Neutron);

            density_by_chain_time_by_step.Increment(step, Neutron.time.chain, Neutron);

            spectrum_by_time_lin.Increment(Neutron.time.chain, Neutron.energy, Neutron);
            spectrum_by_time_log.Increment(Neutron.time.chain, Neutron.energy, Neutron);
            density_by_time_lin.Increment(Neutron.time.chain, Neutron.energy, Neutron);
            density_by_time_log.Increment(Neutron.time.chain, Neutron.energy, Neutron);
        }// End for(neutron_number = 0; neutron_number < Scattering_Input.DataMatrix[local_step].size(); neutron_number++).

//        /* Assessing transfers. */
//        Number_of_Trasfers_3_2[step] += Tranfer_Input.Trasfer_3_2[local_step];
//        Number_of_Trasfers_3_1[step] += Tranfer_Input.Trasfer_3_1[local_step];
//        Number_of_Trasfers_2_1[step] += Tranfer_Input.Trasfer_2_1[local_step];
//        /* Thermalisation histogram. */
//        //if( Number_of_Thermalisations[step] != (Number_of_Trasfers_3_1[step] + Number_of_Trasfers_2_1[step]) ){ std::cout << "Number_of_Thermalisations vector inconsistent.\n"; }
//        for(neutron_number = 0; neutron_number < Thermalisation_Input.DataMatrix[local_step].size(); neutron_number++){
//        }// End for(neutron_number = 0; neutron_number < Thermalisation_Input.DataMatrix[local_step].size(); neutron_number++).

    }// End for(local_step = 0; local_step < interval_size; local_step++).


    Result.VectorHist["Fission_by_Step"] = vector_histogram ( number_path, "Fission_by_Step",
                                                              mc_step.LHS_values(),
                                                              fission_by_step.Histogram(), fission_by_step.Norm() );

    Result.VectorHist["Scattering_by_Step"] = vector_histogram ( number_path, "Scattering_by_Step",
                                                                 mc_step.LHS_values(),
                                                                 scattering_by_step.Histogram(), scattering_by_step.Norm() );

    Result.VectorHist["Capture_by_Step"] = vector_histogram ( number_path, "Capture_by_Step",
                                                              mc_step.LHS_values(),
                                                              capture_by_step.Histogram(), capture_by_step.Norm() );

    Result.VectorHist["Escape_by_Step"] = vector_histogram ( number_path, "Escape_by_Step",
                                                             mc_step.LHS_values(),
                                                             escape_by_step.Histogram(), escape_by_step.Norm() );


    Result.VectorHist["Step_Length"] = vector_histogram ( density_path, "Step_Length",
                                                          length.Mean_values(),
                                                          step_length.Histogram(), step_length.Norm() );

    Result.VectorHist["Capture_Step_Length"] = vector_histogram ( density_path, "Capture_Step_Length",
                                                                  length.Mean_values(),
                                                                  capture_step_length.Histogram(), capture_step_length.Norm() );

    Result.VectorHist["Fission_Step_Length"] = vector_histogram ( density_path, "Fission_Step_Length",
                                                                  length.Mean_values(),
                                                                  fission_step_length.Histogram(), fission_step_length.Norm() );

    Result.VectorHist["Escape_Step_Length"] = vector_histogram ( density_path, "Escape_Step_Length",
                                                                 length.Mean_values(),
                                                                 escape_step_length.Histogram(), escape_step_length.Norm() );

    Result.VectorHist["Scattering_Step_Length"] = vector_histogram ( density_path, "Scattering_Step_Length",
                                                                     length.Mean_values(),
                                                                     scattering_step_length.Histogram(), scattering_step_length.Norm() );



    Result.VectorHist["New_neutrons_by_Step"] = vector_histogram ( number_path, "New_neutrons_by_Step",
                                                                   mc_step.LHS_values(),
                                                                   newN_by_step.Histogram(), newN_by_step.Norm() );

    Result.VectorHist["Neutron_by_Step"] = vector_histogram ( number_path, "Neutron_by_Step",
                                                              mc_step.LHS_values(),
                                                              N_by_step.Histogram(), N_by_step.Norm() );

    Result.VectorHist["Flux_by_Energy"] = vector_histogram ( flux_path, "Flux_by_Energy",
                                                             energy.Mean_values(),
                                                             flux_by_energy.Histogram(), flux_by_energy.Norm() );

    Result.VectorHist["Thermal_by_energy"] = vector_histogram ( number_path, "Thermal_by_energy",
                                                                energy.Mean_values(),
                                                                thermal_by_energy.Histogram(), thermal_by_energy.Norm() );

    Result.VectorHist["Intermediate_by_energy"] = vector_histogram ( number_path, "Intermediate_by_energy",
                                                                     energy.Mean_values(),
                                                                     intermediate_by_energy.Histogram(), intermediate_by_energy.Norm() );

    Result.VectorHist["Fast_by_energy"] = vector_histogram ( number_path, "Fast_by_energy",
                                                             energy.Mean_values(),
                                                             fast_by_energy.Histogram(), fast_by_energy.Norm() );

//    Result.VectorHist["Thermal_by_Step"] = vector_histogram ( number_path, "Therm_by_Step",
//                                                              mc_step.LHS_values(),
//                                                              thermal_by_step.Histogram(), thermal_by_step.Norm() );
//
//    Result.VectorHist["Intermediate_by_Step"] = vector_histogram ( number_path, "Intermediate_by_Step",
//                                                                   mc_step.LHS_values(),
//                                                                   intermediate_by_step.Histogram(), intermediate_by_step.Norm() );
//
//    Result.VectorHist["Fast_by_Step"] = vector_histogram ( number_path, "Fast_by_Step",
//                                                           mc_step.LHS_values(),
//                                                           fast_by_step.Histogram(), fast_by_step.Norm() );

    Result.VectorHist["Neutron_by_energy"] = vector_histogram ( number_path, "Neutron_by_energy",
                                                                energy.Mean_values(),
                                                                N_by_energy.Histogram(), N_by_energy.Norm() );


    Result.VectorHist["Flux_by_Energy_with_Escape"] = vector_histogram ( flux_path, "Flux_by_Energy_with_Escape",
                                                             energy.Mean_values(),
                                                             flux_by_energy_with_escape.Histogram(), flux_by_energy.Norm() );


    Result.VectorHist["Solution_Flux_by_Energy"] = vector_histogram ( flux_path, "Solution_Flux_by_Energy",
                                                             energy.Mean_values(),
                                                             solution_flux_by_energy.Histogram(), flux_by_energy.Norm() );

    Result.VectorHist["Shell_Flux_by_Energy"] = vector_histogram ( flux_path, "Shell_Flux_by_Energy",
                                                             energy.Mean_values(),
                                                             shell_flux_by_energy.Histogram(), flux_by_energy.Norm() );

    Result.VectorHist["Reflector_Flux_by_Energy"] = vector_histogram ( flux_path, "Reflector_Flux_by_Energy",
                                                             energy.Mean_values(),
                                                             reflector_flux_by_energy.Histogram(), flux_by_energy.Norm() );

    Result.VectorHist["Escape_Flux_by_Energy"] = vector_histogram ( flux_path, "Escape_Flux_by_Energy",
                                                             energy.Mean_values(),
                                                             escape_flux_by_energy.Histogram(), flux_by_energy.Norm() );



    Result.VectorHist["Radial_Flux_250"] = vector_histogram ( flux_path, "Radial_Flux_250",
                                                              position_R.Mean_values(),
                                                              radial_flux_250.Histogram(), radial_flux_250.Norm() );

    Result.VectorHist["Radial_Flux_500"] = vector_histogram ( flux_path, "Radial_Flux_500",
                                                              position_R.Mean_values(),
                                                              radial_flux_500.Histogram(), radial_flux_500.Norm() );

    Result.VectorHist["Radial_Flux_750"] = vector_histogram ( flux_path, "Radial_Flux_750",
                                                              position_R.Mean_values(),
                                                              radial_flux_750.Histogram(), radial_flux_750.Norm() );

    Result.VectorHist["Radial_Flux_1000"] = vector_histogram ( flux_path, "Radial_Flux_1000",
                                                              position_R.Mean_values(),
                                                              radial_flux_1000.Histogram(), radial_flux_1000.Norm() );

    Result.VectorHist["Radial_Number_250"] = vector_histogram ( flux_path, "Radial_Number_250",
                                                                position_R.Mean_values(),
                                                                radial_number_250.Histogram(), radial_number_250.Norm() );

    Result.VectorHist["Radial_Number_500"] = vector_histogram ( flux_path, "Radial_Number_500",
                                                                position_R.Mean_values(),
                                                                radial_number_500.Histogram(), radial_number_500.Norm() );

    Result.VectorHist["Radial_Number_750"] = vector_histogram ( flux_path, "Radial_Number_750",
                                                                position_R.Mean_values(),
                                                                radial_number_750.Histogram(), radial_number_750.Norm() );

    Result.VectorHist["Radial_Number_1000"] = vector_histogram ( flux_path, "Radial_Number_1000",
                                                                position_R.Mean_values(),
                                                                radial_number_1000.Histogram(), radial_number_1000.Norm() );



    Result.VectorHist["K_Eff"] = vector_histogram ( number_path, "K_Eff",
                                                    generation.LHS_values(),
                                                    Fissions_by_generation.Histogram(), Fissions_by_generation.Norm() );

    Result.VectorHist["Fissions_by_generation"] = vector_histogram ( number_path, "Fissions_by_generation",
                                                                     generation.LHS_values(),
                                                                     Fissions_by_generation.Histogram(), Fissions_by_generation.Norm() );

    Result.VectorHist["Captures_by_generation"] = vector_histogram ( number_path, "Captures_by_generation",
                                                                     generation.LHS_values(),
                                                                     Captures_by_generation.Histogram(), Captures_by_generation.Norm() );

    Result.VectorHist["Escapes_by_generation"] = vector_histogram ( number_path, "Escapes_by_generation",
                                                                    generation.LHS_values(),
                                                                    Escapes_by_generation.Histogram(), Escapes_by_generation.Norm() );

    Result.VectorHist["Births_by_generation"] = vector_histogram ( number_path, "Births_by_generation",
                                                                   generation.LHS_values(),
                                                                   Births_by_generation.Histogram(), Births_by_generation.Norm() );

    Result.VectorHist["Unaccounted_by_generation"] = vector_histogram ( number_path, "Unaccounted_by_generation",
                                                                        generation.LHS_values(),
                                                                        Births_by_generation.Histogram(), Births_by_generation.Norm() );



    Result.MatrixHist["Dens_by_R"] = matrix_histogram ( density_path, "Dens_by_R",
                                                        position_R.Mean_values(), energy.Mean_values(),
                                                        Dens_by_R.Histogram(), Dens_by_R.Norm() );

//    Result.MatrixHist["Initial_Position"] = matrix_histogram ( density_path, "Initial_Position",
//                                                               position_x.Mean_values(), position_y.Mean_values(),
//                                                               Initial_Position.Histogram(), Initial_Position.Norm() );

    Result.VectorHist["Initial_Flux"] = vector_histogram ( flux_path, "Initial_Flux",
                                                           energy.Mean_values(),
                                                           Initial_Flux.Histogram(), Initial_Flux.Norm() );

    Result.VectorHist["Initial_Alpha"] = vector_histogram ( density_path, "Initial_Alpha",
                                                            alpha.Mean_values(),
                                                            Initial_Alpha.Histogram(), Initial_Alpha.Norm() );

    Result.VectorHist["Initial_Beta"] = vector_histogram ( density_path, "Initial_Beta",
                                                           beta.Mean_values(),
                                                           Initial_Beta.Histogram(), Initial_Beta.Norm() );

    Result.VectorHist["Alpha_Dens"] = vector_histogram ( density_path, "Alpha_Dens",
                                                         alpha.Mean_values(),
                                                         alpha_density.Histogram(), alpha_density.Norm() );

    Result.VectorHist["Beta_Dens"] = vector_histogram ( density_path, "Beta_Dens",
                                                        beta.Mean_values(),
                                                        beta_density.Histogram(), beta_density.Norm() );

    Result.VectorHist["Alpha_Flux"] = vector_histogram ( flux_path, "Alpha_Flux",
                                                         alpha.Mean_values(),
                                                         alpha_flux.Histogram(), alpha_flux.Norm() );

    Result.VectorHist["Beta_Flux"] = vector_histogram ( flux_path, "Beta_Flux",
                                                        beta.Mean_values(),
                                                        beta_flux.Histogram(), beta_flux.Norm() );

    Result.MatrixHist["D_step_chainT_log"] = matrix_histogram ( density_path, "D_step_chainT_log",
                                                                mc_step.LHS_values(), chain_time.Mean_values(),
                                                                density_by_chain_time_by_step.Histogram(), density_by_chain_time_by_step.Norm() );

    Result.MatrixHist["Spectrum_by_time_lin"] = matrix_histogram ( flux_path, "Spectrum_by_time_lin",
                                                                   lin_chain_time.Mean_values(), energy.Mean_values(),
                                                                   spectrum_by_time_lin.Histogram(), spectrum_by_time_lin.Norm() );

    Result.MatrixHist["Spectrum_by_time_log"] = matrix_histogram ( flux_path, "Spectrum_by_time_log",
                                                                   chain_time.Mean_values(), energy.Mean_values(),
                                                                   spectrum_by_time_log.Histogram(), spectrum_by_time_log.Norm() );

    Result.MatrixHist["Dens_by_time_lin"] = matrix_histogram ( density_path, "Dens_by_time_lin",
                                                               lin_chain_time.Mean_values(), energy.Mean_values(),
                                                               density_by_time_lin.Histogram(), density_by_time_lin.Norm() );

    Result.MatrixHist["Dens_by_time_log"] = matrix_histogram ( density_path, "Dens_by_time_log",
                                                               chain_time.Mean_values(), energy.Mean_values(),
                                                               density_by_time_log.Histogram(), density_by_time_log.Norm() );

    std::stringstream msg;
    msg.str("");
    msg << std::setfill(' ');
    msg << "        Initial neutrons: "   << std::setw(12) << Escape_Input    .DataMatrix[0].size()
                                                            + Capture_Input   .DataMatrix[0].size()
                                                            + Fission_Input   .DataMatrix[0].size()
                                                            + Scattering_Input.DataMatrix[0].size() << "\n";
    msg << "        Final neutrons: "     << std::setw(14) << Scattering_Input  .DataMatrix[interval_size - 1].size()
                                                            + New_Neutrons_Input.DataMatrix[interval_size - 1].size() << "\n";
    msg << "        Total histories: "    << std::setw(13) << Escape_Input    .DataMatrix[0].size()
                                                            + Capture_Input   .DataMatrix[0].size()
                                                            + Fission_Input   .DataMatrix[0].size()
                                                            + Scattering_Input.DataMatrix[0].size()
                                                            + total_new_neutrons << "\n";
    msg << "        Total escapes: "      << std::setw(15) << total_escapes      << "\n";
    msg << "        Total captures: "     << std::setw(14) << total_captures     << "\n";
    msg << "        Total fissions: "     << std::setw(14) << total_fissions     << "\n";
    msg << "        Total new neutrons: " << std::setw(10) << total_new_neutrons << "\n";
    msg << "        Total scatterings: "  << std::setw(11) << total_scatterings  << std::endl;
    Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

    return Result;
}
