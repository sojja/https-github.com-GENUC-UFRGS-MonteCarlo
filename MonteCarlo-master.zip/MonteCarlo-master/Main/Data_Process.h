#ifndef DATA_PROCESS_H_INCLUDED
#define DATA_PROCESS_H_INCLUDED

#include "Structs_header.h"
#include "Simulation.h"
#include "Histogram.h"


class data_process_parameters {

    public:

        unsigned int execution_number;

        unsigned int interval_size;
        unsigned int number_of_intervals;

        rectangular_geometry_struct geometry;

        simulation_limits limits;


        data_process_parameters ( unsigned int Execution_number,
                                  unsigned int Interval_size,
                                  unsigned int Number_of_intervals,
                                  rectangular_geometry_struct Geometry,
                                  simulation_limits Limits ) {

            execution_number    = Execution_number;
            interval_size       = Interval_size;
            number_of_intervals = Number_of_intervals;
            geometry            = Geometry;
            limits              = Limits;
        }
};


class data_process_return {
    public:
        std::map <std::string, vector_histogram> VectorHist;
        std::map <std::string, matrix_histogram> MatrixHist;

        void TextOutput() {
            for (auto element : VectorHist) {
                element.second.TextOutput();
            }
            for (auto element : MatrixHist) {
                element.second.TextOutput();
            }
        }
};


data_process_return data_process ( unsigned int interval_start,
                                   unsigned int interval_size,
                                   unsigned int execution_number,
                                   rectangular_geometry_struct& Geometry,
                                   simulation_limits Limits );


data_process_return thread_data_process ( data_process_parameters Parameters );


#endif // DATA_PROCESS_H_INCLUDED
