#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include "Output.h"
#include "Structs_header.h"
#include "multithread_MT64.h"

void inital_neutrons_file_builder( unsigned int number_of_neutrons,
                                   unsigned int execution_number,
                                   rectangular_geometry_struct& Geometry,
                                   unsigned long long seed ){

    unsigned int i;
    double energy;
    double distribution_value;
    double test_value;
    double max_value = 0.359;// Maximum value of the fission energy PDF.

    std::stringstream filename;
    filename << "Bin_Files/Checkpoint_Files/" << execution_number << "_0.bin";

    OutputVector <neutron_struct> Initial_Neutrons( filename.str() );

    multithread_mt64 mt64(seed);

    neutron_struct dummy_Neutron;

    dummy_Neutron.distribution                   = 3;
    dummy_Neutron.step                           = 0;
    dummy_Neutron.local_step                     = 0;
    dummy_Neutron.generation                     = 0;
    dummy_Neutron.eos_position.x                 = 0;
    dummy_Neutron.eos_position.y                 = 0;
    dummy_Neutron.eos_position.z                 = 0;
    dummy_Neutron.birth.step                     = 0;
    dummy_Neutron.time.chain                     = 0;
    dummy_Neutron.time.life                      = 0;
    dummy_Neutron.time.step                      = 0;
    dummy_Neutron.step_life                      = 0;
    dummy_Neutron.last_scattering_before_thermal = 0;
    dummy_Neutron.isotope_of_last_interaction    = 0;
    dummy_Neutron.Absorbed                       = false;
    dummy_Neutron.Escaped                        = false;

    i = 0;

    double placeholder_A, placeholder_B, placeholder_R;

    while(i < number_of_neutrons){

        energy = 20.0 * mt64.genRand_real3();// Energy in the range (0, 20)MeV.
        distribution_value = 0.453 *  std::exp(-1.036 * energy) * std::sinh( std::sqrt(2.29 * energy) );
        test_value = max_value * mt64.genRand_real3();

        if(test_value <= distribution_value){

            placeholder_A = 2.0 * M_PI * mt64.genRand_real2();
            placeholder_B = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;
            placeholder_R = mt64.genRand_real2() * Geometry.X1;

            dummy_Neutron.energy           = energy;//0.10;
            dummy_Neutron.sos_position.x   = placeholder_R * std::cos(placeholder_A) * std::cos(placeholder_B);//0;// (2.0 * mt64.genRand_real3() -1.0) * Geometry.X1;
            dummy_Neutron.sos_position.y   = placeholder_R * std::sin(placeholder_A) * std::cos(placeholder_B);//0;// (2.0 * mt64.genRand_real3() -1.0) * Geometry.Y1;
            dummy_Neutron.sos_position.z   = placeholder_R * std::sin(placeholder_B);//0;// (2.0 * mt64.genRand_real3() -1.0) * Geometry.Z;
            dummy_Neutron.direction.alpha  = 2.0 * M_PI * mt64.genRand_real2();
            dummy_Neutron.direction.beta   = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;
            dummy_Neutron.birth.energy     = dummy_Neutron.energy;
            dummy_Neutron.birth.position.x = dummy_Neutron.sos_position.x;
            dummy_Neutron.birth.position.y = dummy_Neutron.sos_position.y;
            dummy_Neutron.birth.position.z = dummy_Neutron.sos_position.z;

            Initial_Neutrons.Add(dummy_Neutron);
            i++;
        }
    }

    Initial_Neutrons.BinaryOutput();
    Initial_Neutrons.Clear();

}
