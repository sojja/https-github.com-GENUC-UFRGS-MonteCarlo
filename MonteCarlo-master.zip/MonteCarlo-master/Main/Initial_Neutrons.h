#ifndef INITIAL_NEUTRONS_H_INCLUDED
#define INITIAL_NEUTRONS_H_INCLUDED

#include "Structs_header.h"

void inital_neutrons_file_builder( unsigned int number_of_neutrons,
                                   unsigned int execution_number,
                                   rectangular_geometry_struct& Geometry,
                                   unsigned long long seed );

#endif // INITIAL_NEUTRONS_H_INCLUDED
