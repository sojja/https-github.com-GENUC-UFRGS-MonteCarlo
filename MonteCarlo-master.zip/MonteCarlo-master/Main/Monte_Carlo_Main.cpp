#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <thread>
#include <cmath>
#include "Initial_Neutrons.h"
#include "Structs_header.h"
#include "processing_pool.h"
#include "multithread_logger.h"
#include "Simulation.h"
#include "Data_Process.h"
#include "Output.h"
#include "Input.h"
#include "Auxiliar_Functions.h"
//#include "Element.h"

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */


multi_logger Logger("Log_Files/Terminal.txt");

std::string log_filename;

int main(){

    /* Boolean variables to define if to program runs the simulation and/or data processing. */
    bool run_simulation, run_data_process;
    run_simulation   = false;
    run_data_process = true;

    /* Number of threads. */
    int n_threads = 4;

    /* Variables that define both the simulation and the data processing. */
    unsigned int interval_size        = 50;
    unsigned int number_of_intervals  = 60;
    unsigned int number_of_executions = 10;

    unsigned int initial_neutrons = 2500;

    bool thermalizationModel = false;

    /* Declaring geometry. */
    rectangular_geometry_struct Geometry;// [cm]
    Geometry.X1 = 500;
    Geometry.X2 = 9999;
    Geometry.X3 = 9999;
    Geometry.Y1 = 500;
    Geometry.Y2 = 9999;
    Geometry.Y3 = 9999;
    Geometry.Z  = 500;
    Geometry.R1 = 9999;
    Geometry.R2 = 9999;
    Geometry.R3 = 9999;
    Geometry.R4 = 9999;
    Geometry.R5 = 9999;
    Geometry.R6 = 9999;

    /* Filename that belongs to both simulation and data process. */
    std::string simulation_return_filename = "Bin_Files/Simulation_Return_Files/Returns.bin";

    /* Message container */
    std::stringstream msg;

    if ( run_simulation ) {

        /* Intervals summary file name */
        std::stringstream sl_filename;
        std::time_t s_t = std::chrono::system_clock::to_time_t( std::chrono::system_clock::now() );
        std::tm *s_ptm  = std::localtime(&s_t);
        sl_filename << "Log_Files/Simulation_Interval_Summary_" << std::put_time(s_ptm,"%F_%T") << ".txt";

        log_filename = sl_filename.str();


        msg << std::setfill(' ');
        msg << "Number of neutrons:"     << std::setw(14) << initial_neutrons * number_of_executions << "  |  Number of steps:"     << std::setw(14)
            << interval_size * number_of_intervals << "\n";
        msg << "Number of execution:"    << std::setw(13) << number_of_executions                    << "  |  Number of intervals:" << std::setw(10)
            << number_of_intervals  << "\n";
        msg << "Neutrons per execution:" << std::setw(10) << initial_neutrons                        << "  |  Steps per interval:"  << std::setw(11)
            << interval_size  << "\n\n" << std::endl;

        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );


        auto simulation_chrono_start = std::chrono::system_clock::now();

        std::vector <simulation_parameters> SimulationParameters;

        for (unsigned int execution_number = 0; execution_number < number_of_executions; execution_number++) {
            SimulationParameters.push_back( simulation_parameters( execution_number
                                                                 , interval_size
                                                                 , number_of_intervals
                                                                 , initial_neutrons
                                                                 , Geometry
                                                                 , thermalizationModel
                                                                 )
                                          );
        }

        std::vector <simulation_return> SimulationReturns;


        return_pool <simulation_return, simulation_parameters> Simulation_Pool( SimulationParameters, n_threads, thread_simulation );

        Simulation_Pool.Run();

        SimulationReturns = Simulation_Pool.Returns();


        OutputVector <simulation_return> ReturnsOutput;
        ReturnsOutput.Assign( SimulationReturns );
        ReturnsOutput.BinaryOutput( simulation_return_filename );


        auto simulation_chrono_end = std::chrono::system_clock::now();
        msg.str("");
        msg << "Simulation execution time: "
            << std::chrono::duration <double> (simulation_chrono_end - simulation_chrono_start).count()
            << "s" << std::endl;
        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

        msg.str("");
        msg << "Simulation finished. Simulation execution time: "
            << std::chrono::duration <double> (simulation_chrono_end - simulation_chrono_start).count()
            << "s" << std::endl;
        Logger.to_terminal_store( std::this_thread::get_id(), msg.str() );
    }// End if(run_simulation).

    if ( run_data_process ) {

        /* Intervals summary file name */
        std::stringstream dpl_filename;
        std::time_t dp_t = std::chrono::system_clock::to_time_t( std::chrono::system_clock::now() );
        std::tm *dp_ptm  = std::localtime(&dp_t);
        dpl_filename << "Log_Files/Data_Process_Interval_Summary_" << std::put_time(dp_ptm,"%F_%T") << ".txt";

        log_filename = dpl_filename.str();


        simulation_return SimulationReturn, TmpRet;

        InputVector <simulation_return> ReturnInput;
        ReturnInput.BinaryInput( simulation_return_filename );

        while ( !ReturnInput.DataFullyRetrieved() ) {
            ReturnInput.Retrieve( TmpRet );
            SimulationReturn.limits = Min_and_Max( SimulationReturn.limits, TmpRet.limits );
        }

        simulation_limits Limits;

        Limits.min_step        = SimulationReturn.limits.min_step;
        Limits.max_step        = SimulationReturn.limits.max_step;
        Limits.max_generation  = SimulationReturn.limits.max_generation;
        Limits.min_energy      = floating_point_floor( SimulationReturn.limits.min_energy, 3 );
        Limits.min_step_length = floating_point_floor( SimulationReturn.limits.min_step_length, 3 );
        Limits.min_time.step   = floating_point_floor( SimulationReturn.limits.min_time.step, 3 );
        Limits.min_time.life   = floating_point_floor( SimulationReturn.limits.min_time.life, 3 );
        Limits.min_time.chain  = floating_point_floor( SimulationReturn.limits.min_time.chain, 3 );
        Limits.max_energy      = floating_point_ceil( SimulationReturn.limits.max_energy, 3 );
        Limits.max_step_length = floating_point_ceil( SimulationReturn.limits.max_step_length, 3 );
        Limits.max_time.step   = floating_point_ceil( SimulationReturn.limits.max_time.step, 3 );
        Limits.max_time.life   = floating_point_ceil( SimulationReturn.limits.max_time.life, 3 );
        Limits.max_time.chain  = floating_point_ceil( SimulationReturn.limits.max_time.chain, 3 );


        msg.str("");
        msg << "Energy Limits: [" << Limits.min_energy << ", " << Limits.max_energy << "]" << std::endl;
        Logger.to_file("../Limits.txt", std::this_thread::get_id(), msg.str() );

        auto data_process_chrono_start = std::chrono::system_clock::now();

        std::vector <data_process_parameters> DataProcessParameters;

//        std::vector <unsigned int> selected_executions { 0
//                                                       , 1
//                                                       , 2
//                                                       , 3
//                                                       , 4
//                                                       , 5
//                                                       , 6
//                                                       , 10
//                                                       };
        for (unsigned int execution_number = 0; execution_number < number_of_executions; execution_number++) {
//        for (unsigned int execution_number : selected_executions) {
            DataProcessParameters.push_back( data_process_parameters( execution_number,
                                                                      interval_size,
                                                                      number_of_intervals,
                                                                      Geometry,
                                                                      Limits ) );
        }

        std::vector <data_process_return> DataProcessReturns;


        return_pool <data_process_return, data_process_parameters> Data_Process_Pool( DataProcessParameters, n_threads, thread_data_process );

        Data_Process_Pool.Run();

        DataProcessReturns = Data_Process_Pool.Returns();


        data_process_return DataProcRet;


        for (unsigned int execution_number = 0; execution_number < number_of_executions; execution_number++) {
            for (auto matrix_element : DataProcessReturns[execution_number].MatrixHist) {
                if ( execution_number == 0 ) {
                    DataProcRet.MatrixHist[ matrix_element.first ] = matrix_element.second;
                }
                else {
                    DataProcRet.MatrixHist[ matrix_element.first ].Add( matrix_element.second );
                }
            }

            for (auto vector_element : DataProcessReturns[execution_number].VectorHist) {
                if ( execution_number == 0 ) {
                    DataProcRet.VectorHist[ vector_element.first ] = vector_element.second;
                }
                else {
                    DataProcRet.VectorHist[ vector_element.first ].Add( vector_element.second );
                }
            }
        }



        /* Some vectors/matrices can be reworked according to other vectors or matrices. */
        std::vector <double> K_Eff;
        K_Eff.push_back(1.0);
        for (size_t i = 1; i < DataProcRet.VectorHist["Fissions_by_generation"].values.size(); i++) {
            K_Eff.push_back( DataProcRet.VectorHist["Fissions_by_generation"].values[i] / DataProcRet.VectorHist["Fissions_by_generation"].values[i-1] );
        }
        DataProcRet.VectorHist["K_Eff"].values = K_Eff;

        std::vector <double> Unaccounted_by_generation;
        for (size_t i = 0; i < DataProcRet.VectorHist["Births_by_generation"].values.size(); i++) {
            Unaccounted_by_generation.push_back( DataProcRet.VectorHist["Births_by_generation"].values[i]
                                               - DataProcRet.VectorHist["Fissions_by_generation"].values[i]
                                               - DataProcRet.VectorHist["Captures_by_generation"].values[i]
                                               - DataProcRet.VectorHist["Escapes_by_generation"].values[i] );
        }
        DataProcRet.VectorHist["Unaccounted_by_generation"].values = Unaccounted_by_generation;

        for (size_t i = 0; i < DataProcRet.MatrixHist["D_step_chainT"].values.size(); i++) {
            for (size_t j = 0; j < DataProcRet.MatrixHist["D_step_chainT"].values[i].size(); j++) {
                DataProcRet.MatrixHist["D_step_chainT"].values[i][j] /= DataProcRet.VectorHist["Neutron_by_Step"].values[i];
                DataProcRet.MatrixHist["D_step_chainT"].values[0][j] = 1;
                DataProcRet.MatrixHist["D_step_chainT"].values[i][0] = 1;
            }
        }

        DataProcRet.TextOutput();


        /* Simulation and data assessment parameters are saved for the Boltzmann equation evaluation. */
        std::vector < std::vector <double> > distribution_probability(3);

        distribution_probability[0] = DataProcRet.VectorHist["Thermal_by_energy"].values;
        distribution_probability[1] = DataProcRet.VectorHist["Intermediate_by_energy"].values;
        distribution_probability[2] = DataProcRet.VectorHist["Fast_by_energy"].values;

        OutputMatrix <double> Boltzmann_Distribution_Probability ("../Files/Boltzmann_Equation_Input/Distribution_Probability.bin");
        Boltzmann_Distribution_Probability.Assign(distribution_probability);
        Boltzmann_Distribution_Probability.BinaryOutput();

        OutputVector <rectangular_geometry_struct> Boltzmann_Geometry ("../Files/Boltzmann_Equation_Input/Geometry.bin");
        Boltzmann_Geometry.Add(Geometry);
        Boltzmann_Geometry.BinaryOutput();

        OutputVector <simulation_limits> Boltzmann_Limits ("../Files/Boltzmann_Equation_Input/Limits.bin");
        Boltzmann_Limits.Add(Limits);
        Boltzmann_Limits.BinaryOutput();


        auto data_process_chrono_end = std::chrono::system_clock::now();
        msg.str("");
        msg << "Data processing time: "
            << std::chrono::duration <double> (data_process_chrono_end - data_process_chrono_start).count()
            << "s" << std::endl;
        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

        msg.str("");
        msg << "Data processing finished. Data processing time: "
            << std::chrono::duration <double> (data_process_chrono_end - data_process_chrono_start).count()
            << "s" << std::endl;
        Logger.to_terminal_store( std::this_thread::get_id(), msg.str() );

    }

    return 0;
}
