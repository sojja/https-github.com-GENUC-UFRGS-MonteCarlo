#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <thread>
#include <iomanip>
#include <algorithm>
#include "Structs_header.h"
#include "Properties_Structs_header.h"
#include "Tracking_and_Interaction_header.h"
#include "Cross_Section_Functions_header.h"
#include "Fission_Functions_header.h"
#include "Fission_Buffer.h"
#include "Probability_Distributions_header.h"
#include "Input.h"
#include "Output.h"
#include "Transfer_Counter.h"
#include "multithread_logger.h"
#include "multithread_MT64.h"
#include "Simulation.h"
#include "Nuclide.h"
#include "Molecule.h"
#include "Element.h"
#include "scattering.h"
#include "particles.hpp"
#include "transformations.hpp"

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */


simulation_return simulation( unsigned int interval_start
                            , unsigned int interval_size
                            , unsigned int execution_number
                            , rectangular_geometry_struct & Geometry
                            , unsigned seed
                            , bool thermalizationModel
                            ){


    nuclide H1 (nuclide_id (1, 1), 1.00782503224,
                          std::map <std::string, neutron_interaction> {
                              {"Scattering", H_scattering_CS},
                              {"Capture", H_capture_CS}
                          } );

//    nuclide C12 (nuclide_id (6, 12), 12,
//                           std::map <std::string, neutron_interaction> {
//                               {"Scattering", C12_scattering_CS},
//                               {"Capture", C12_capture_CS}
//                           } );

    nuclide O16 (nuclide_id (8, 16), 15.99491461960,
                           std::map <std::string, neutron_interaction> {
                               {"Scattering", O_scattering_CS},
                               {"Capture", O_capture_CS}
                           } );

    nuclide F19 (nuclide_id (9, 19), 18.9984031629,
                           std::map <std::string, neutron_interaction> {
                               {"Scattering", F19_scattering_CS},
                               {"Capture", F19_capture_CS}
                           } );
//    nuclide Mg24 (nuclide_id (12, 24), 23.985041697,
//                            std::map <std::string, neutron_interaction> {
//                                {"Scattering", Mg24_scattering_CS},
//                                {"Capture", Mg24_capture_CS}
//                            } );

    nuclide Al27 (nuclide_id (13, 27), 26.98153841,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Al27_scattering_CS},
                                {"Capture", Al27_capture_CS}
                            } );

    nuclide Si28 (nuclide_id (14, 28), 27.9769265350,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Si28_scattering_CS},
                                {"Capture", Si28_capture_CS}
                            } );

    nuclide Si29 (nuclide_id (14, 29), 28.9764946653,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Si29_scattering_CS},
                                {"Capture", Si29_capture_CS}
                            } );

    nuclide Si30 (nuclide_id (14, 30), 29.973770137,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Si30_scattering_CS},
                                {"Capture", Si30_capture_CS}
                            } );

//    nuclide P31 (nuclide_id (15, 31), 30.9737619986,
//                           std::map <std::string, neutron_interaction> {
//                               {"Scattering", P31_scattering_CS},
//                               {"Capture", P31_capture_CS}
//                           } );
//
//    nuclide S32 (nuclide_id (16, 32), 31.9720711744,
//                           std::map <std::string, neutron_interaction> {
//                               {"Scattering", S32_scattering_CS},
//                               {"Capture", S32_capture_CS}
//                           } );
//
//    nuclide Ca40 (nuclide_id (20, 40), 39.96259098,
//                            std::map <std::string, neutron_interaction> {
//                                {"Scattering", Ca40_scattering_CS},
//                                {"Capture", Ca40_capture_CS}
//                            } );
//
//    nuclide Cr52 (nuclide_id (24, 52), 51.9405075,
//                            std::map <std::string, neutron_interaction> {
//                                {"Scattering", Cr52_scattering_CS},
//                                {"Capture", Cr52_capture_CS}
//                            } );

    nuclide Mn55 (nuclide_id (25, 55), 54.9380451,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Cr52_scattering_CS},
                                {"Capture", Cr52_capture_CS}
                            } );

//    nuclide Fe56 (nuclide_id (26, 56), 55.9349363,
//                            std::map <std::string, neutron_interaction> {
//                                {"Scattering", Mn55_scattering_CS},
//                                {"Capture", Mn55_capture_CS}
//                            } );

//    nuclide Ni58 (nuclide_id (28, 58), 57.9353429,
//                            std::map <std::string, neutron_interaction> {
//                                {"Scattering", Ni58_scattering_CS},
//                                {"Capture", Ni58_capture_CS}
//                            } );

    nuclide Cu63 (nuclide_id (29, 63), 62.9295975,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Cu63_scattering_CS},
                                {"Capture", Cu63_capture_CS}
                            } );

    nuclide Cu65 (nuclide_id (29, 65), 64.9277895,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Cu65_scattering_CS},
                                {"Capture", Cu65_capture_CS}
                            } );

    nuclide Zn64 (nuclide_id (30, 64), 63.929142,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Zn64_scattering_CS},
                                {"Capture", Zn64_capture_CS}
                            } );

    nuclide Zn66 (nuclide_id (30, 66), 65.9260334,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Zn66_scattering_CS},
                                {"Capture", Zn66_capture_CS}
                            } );

    nuclide Zn67 (nuclide_id (30, 67), 66.9271273,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Zn67_scattering_CS},
                                {"Capture", Zn67_capture_CS}
                            } );

    nuclide Zn68 (nuclide_id (30, 68), 67.9248442,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Zn68_scattering_CS},
                                {"Capture", Zn68_capture_CS}
                            } );

    nuclide Zn70 (nuclide_id (30, 70), 69.9253193,
                            std::map <std::string, neutron_interaction> {
                                {"Scattering", Zn70_scattering_CS},
                                {"Capture", Zn70_capture_CS}
                            } );

//    nuclide Ba138 (nuclide_id (56, 138),  	137.9052472,
//                             std::map <std::string, neutron_interaction> {
//                                {"Scattering", Ba138_scattering_CS},
//                                {"Capture", Ba138_capture_CS}
//                             } );

    nuclide U234 (nuclide_id (92, 234), 234.0409521,
                             std::map <std::string, neutron_interaction> {
                                {"Scattering", U234_scattering_CS},
                                {"Capture", U234_capture_CS},
                                {"Fission", U234_fission_CS}
                             } );

    nuclide U235 (nuclide_id (92, 235), 235.0439299,
                             std::map <std::string, neutron_interaction> {
                                {"Scattering", U235_scattering_CS},
                                {"Capture", U235_capture_CS},
                                {"Fission", U235_fission_CS}
                             } );

    nuclide U236 (nuclide_id (92, 236), 236.045568,
                             std::map <std::string, neutron_interaction> {
                                {"Scattering", U236_scattering_CS},
                                {"Capture", U236_capture_CS},
                                {"Fission", U236_fission_CS}
                             } );

    nuclide U238 (nuclide_id (92, 238), 238.0507882,
                             std::map <std::string, neutron_interaction> {
                                {"Scattering", U238_scattering_CS},
                                {"Capture", U238_capture_CS},
                                {"Fission", U238_fission_CS}
                             } );

    element H (std::map <nuclide_id, isotope_abundance> {
                         { nuclide_id (1, 1), isotope_abundance (H1, 1.0)}
                         } );

//    element C (std::map <nuclide_id, isotope_abundance> {
//                         {nuclide_id (6, 12), isotope_abundance (C12, 1.0)}
//                         } );

    element O (std::map <nuclide_id, isotope_abundance> {
                         {nuclide_id (8, 16), isotope_abundance (O16, 1.0)}
                         } );

    element F (std::map <nuclide_id, isotope_abundance> {
                         {nuclide_id (9, 19), isotope_abundance (F19, 1.0)}
                         } );

//    element Mg (std::map <nuclide_id, isotope_abundance> {
//                          { nuclide_id (12, 24), isotope_abundance (Mg24, 1.0)}
//                          } );

    element Al (std::map <nuclide_id, isotope_abundance> {
                          { nuclide_id (13, 27), isotope_abundance (Al27, 1.0)}
                          } );

    element Si (std::map <nuclide_id, isotope_abundance> {
                          {nuclide_id (14, 28), isotope_abundance (Si28, 0.92223)},
                          {nuclide_id (14, 28), isotope_abundance (Si29, 0.04685)},
                          {nuclide_id (14, 28), isotope_abundance (Si30, 0.03092)}
                          } );

//    element P (std::map <nuclide_id, isotope_abundance> {
//                         { nuclide_id (15, 31), isotope_abundance (P31, 1.0)}
//                         } );
//
//    element S (std::map <nuclide_id, isotope_abundance> {
//                         { nuclide_id (16, 32), isotope_abundance (S32, 1.0)}
//                         } );
//
//    element Ca (std::map <nuclide_id, isotope_abundance> {
//                          {nuclide_id (20, 40), isotope_abundance (Ca40, 1.0)}
//                          } );
//
//    element Cr (std::map <nuclide_id, isotope_abundance> {
//                          { nuclide_id (24, 52), isotope_abundance (Cr52, 1.0)}
//                          } );

    element Mn (std::map <nuclide_id, isotope_abundance> {
                          { nuclide_id (25, 55), isotope_abundance (Mn55, 1.0)}
                          } );

//    element Fe (std::map <nuclide_id, isotope_abundance> {
//                          { nuclide_id (26, 56), isotope_abundance (Fe56, 1.0)}
//                          } );
//
//    element Ni (std::map <nuclide_id, isotope_abundance> {
//                          { nuclide_id (28, 58), isotope_abundance (Ni58, 1.0)}
//                          } );

    element Cu (std::map <nuclide_id, isotope_abundance> {
                          { nuclide_id (29, 63), isotope_abundance (Cu63, 0.6915)},
                          { nuclide_id (29, 65), isotope_abundance (Cu65, 0.3085)}
                          } );

    element Zn (std::map <nuclide_id, isotope_abundance> {
                          { nuclide_id (30, 64), isotope_abundance (Zn64, 0.4917)},
                          { nuclide_id (30, 66), isotope_abundance (Zn66, 0.2773)},
                          { nuclide_id (30, 67), isotope_abundance (Zn67, 0.0404)},
                          { nuclide_id (30, 68), isotope_abundance (Zn68, 0.1845)},
                          { nuclide_id (30, 70), isotope_abundance (Zn70, 0.0061)}
                          } );

//    element Ba (std::map <nuclide_id, isotope_abundance> {
//                          {nuclide_id (56, 138), isotope_abundance (Ba138, 1.0)}
//                          } );

//    element U (std::map <nuclide_id, isotope_abundance> {
//                          { nuclide_id (92, 234), isotope_abundance (U234, 0.0098)},
//                          { nuclide_id (92, 235), isotope_abundance (U235, 0.9318)},
//                          { nuclide_id (92, 236), isotope_abundance (U236, 0.0050)},
//                          { nuclide_id (92, 238), isotope_abundance (U238, 0.0534)}
//                          } );

    element U (std::map <nuclide_id, isotope_abundance> {
                          { nuclide_id (92, 235), isotope_abundance (U235, 0.00895)},
                          { nuclide_id (92, 238), isotope_abundance (U238, 0.99105)}
                          } );

//    std::stringstream text;
//    text.precision(10);
//    text << "Al element mass: " << Al.Element_Mass << "\n";
//    text << "Si element mass: " << Si.Element_Mass << "\n";
//    text << "Cu element mass: " << Cu.Element_Mass << "\n";
//    text << "Mn element mass: " << Mn.Element_Mass << "\n";
//    text << "Zn element mass: " << Zn.Element_Mass << "\n";
//    Logger.to_file("Aluminum_E_Masses.txt", std::this_thread::get_id(), text.str());

    molecule UO2F2 (0.028504580361245, std::vector < std::pair <double, element> > { {1, U},
                                                                                     {2, O},
                                                                                     {2, F} } );

    molecule UO2 (10.5, std::vector < std::pair <double, element> > { {1, U},
                                                                      {2, O} } );

    molecule H2O (0.997992426865824, std::vector < std::pair <double, element> > { {2, H},
                                                                                   {1, O} } );

    molecule H2O_Reflector (0.99705, std::vector < std::pair <double, element> > { {2, H},
                                                                                   {1, O} } );

    molecule Aluminum_eq_molecule (2.71, std::vector < std::pair <double, element> > { {0.990012258611548, Al},
                                                                                       {0.008475258947688, Si},
                                                                                       {0.000851965796962, Cu},
                                                                                       {0.000246312771309, Mn},
                                                                                       {0.000414203872493, Zn} } );


//    std::stringstream molecule_X_section;
//    molecule_X_section << Concrete_equivalent_molecule.Total_Macroscopic_Cross_Section(1.0) << std::endl;
//    Logger.to_file("Molecule_capture_Cross_Section.txt", std::this_thread::get_id(), molecule_X_section.str());

    const double Temperature = 298.15;// [K]

    unsigned short int region_number;


    region Region_Solution (std::vector <std::pair <molecule, double> > { {UO2, 0.28},
                                                                          {H2O, 0.72} } );
//    region Region_Aluminum_Sphere (std::vector <std::pair <molecule, double> > { {Aluminum_eq_molecule, 1.0} } );
//    region Region_Reflector (std::vector <std::pair <molecule, double> > { {H2O_Reflector, 1.0} } );
//    region Region_Vacuum;
    region Region_Temp;

//    std::stringstream molecule_X_section;
//    molecule_X_section << Region_Temp.Total_Macroscopic_Cross_Section(1) << std::endl;
//    for (auto Iso : Fe.Isotopes ){ molecule_X_section << Iso.second.Mass_Percentage << "\t" << Iso.second.Nuclide.Atomic_Mass; }
//    molecule_X_section << Region1.Total_Macroscopic_Cross_Section(1)  << "\t" << (1.0 / Region1.Total_Macroscopic_Cross_Section(1)) << std::endl;
//    Logger.to_file("Molecule_capture_Cross_Section.txt", std::this_thread::get_id(), molecule_X_section.str());
//    region_properties_struct Region_1(Region1_Water_Proportion, Enrichment);
//    region_properties_struct Region_Temp;

    interaction Interaction;

//    cross_sections_struct Cross_Sections;

    /* Creating file structure paths. */
    std::stringstream input_energy_fission_filename;
    std::stringstream input_checkpoint_filename;
    std::stringstream output_checkpoint_filename;
    std::stringstream fission_filename;
    std::stringstream scattering_filename;
    std::stringstream capture_filename;
    std::stringstream escape_filename;
    std::stringstream thermalisation_filename;
    std::stringstream new_neutrons_filename;
    std::stringstream transfer_counter_filename;

    input_energy_fission_filename << "Bin_Files/Fission_Distribution_Files/Fission_Energy_PDF_" << execution_number << ".bin";
    input_checkpoint_filename     << "Bin_Files/Checkpoint_Files/"                 << execution_number << "_" << interval_start  << ".bin";
    output_checkpoint_filename    << "Bin_Files/Checkpoint_Files/"                 << execution_number << "_" << (interval_start +  interval_size) << ".bin";
    fission_filename              << "Bin_Files/Data_Output_Files/Fission/"        << execution_number << "_" << interval_start  << ".bin";
    scattering_filename           << "Bin_Files/Data_Output_Files/Scattering/"     << execution_number << "_" << interval_start  << ".bin";
    capture_filename              << "Bin_Files/Data_Output_Files/Capture/"        << execution_number << "_" << interval_start  << ".bin";
    escape_filename               << "Bin_Files/Data_Output_Files/Escape/"         << execution_number << "_" << interval_start  << ".bin";
    thermalisation_filename       << "Bin_Files/Data_Output_Files/Thermalisation/" << execution_number << "_" << interval_start  << ".bin";
    new_neutrons_filename         << "Bin_Files/Data_Output_Files/New_Neutrons/"   << execution_number << "_" << interval_start  << ".bin";
    transfer_counter_filename     << "Bin_Files/Data_Output_Files/Transfer/"       << execution_number << "_" << interval_start  << ".bin";

    /* Storage classes: */
        /* Internal Buffer class for fission information storage. */
    FissionBuffer Fission_Buffer;

        /* Storage classes with input operations. */
    InputVector <double> Fission_Energy_Input_Vector( input_energy_fission_filename.str() );
    InputVector <neutron_struct> Checkpoint_Input_Vector( input_checkpoint_filename.str() );

        /* Storage classes with output operations. */
    OutputVector <neutron_struct> Checkpoint_Output_Vector( output_checkpoint_filename.str() );

    OutputMatrix <fission_struct> Fission_Output_Matrix( interval_size, fission_filename.str() );
    OutputMatrix <neutron_struct> Scattering_Output_Matrix( interval_size, scattering_filename.str() );
    OutputMatrix <neutron_struct> Capture_Output_Matrix( interval_size, capture_filename.str() );
    OutputMatrix <neutron_struct> Escape_Output_Matrix( interval_size, escape_filename.str() );
    OutputMatrix <neutron_struct> New_Neutrons_Output_Matrix( interval_size, new_neutrons_filename.str() );
    OutputMatrix <thermalisation_struct> Thermalisation_Output_Matrix( interval_size, thermalisation_filename.str() );

        /* Storage classes with input and output operations. */
    Transfer_Counter Counter(interval_size, transfer_counter_filename);

    /* Declaring counters. */
    unsigned int initial_neutrons;
    unsigned int final_neutrons     = 0;
    unsigned int total_histories    = 0;
    unsigned int total_escapes      = 0;
    unsigned int total_captures     = 0;
    unsigned int total_fissions     = 0;
    unsigned int total_new_neutrons = 0;
    unsigned int total_scatterings  = 0;
//    unsigned int H2O_scatterings    = 0;
//    unsigned int UO2_scatterings    = 0;

    /* Declaring auxiliary variables. */
    unsigned short int New_Neutrons;
    double Mass_Number;
    double RandomVar;

    /* Declaring auxiliary structures. */
    fission_struct Fission_Temp;
    thermalisation_struct Thermalisation_Temp;
    collision_struct Collision;
//    interaction_type_struct Interaction;
//    isotope_type_struct Isotope;

    /* declaring return structure. */
    simulation_return SimReturn;

    /* Declaring the neutron structure. */
    neutron_struct Neutron;

    /* Declaring additional boolean values. */
    // bool Absorbed = false;
    // bool Escaped  = false;
    //
    // This will be inserted in the neutron_struct for testing, but it can be removed for optimization purposes.
    //

    /* Declaring stringstream to store logger message. */
    std::stringstream msg;

    /* Declaring Mersenne Twister multithread class. */
    multithread_mt64 mt64(seed);

    /* Creating the binary file with fission distribution energies. */
    fission_distribution_file_builder( 50000, execution_number, mt64 );

    /* Loading fission and initial neutrons data. */
    Fission_Energy_Input_Vector.BinaryInput();
    Checkpoint_Input_Vector.BinaryInput();

    initial_neutrons = Checkpoint_Input_Vector.Size_of_Vector();

    /* Starting the simulation. */
    if(initial_neutrons > 0){
        while( !Checkpoint_Input_Vector.DataFullyRetrieved() || (Fission_Buffer.RemainingFissions() != 0) ){

            if(Fission_Buffer.RemainingFissions() > 0){// Neutron data comes from Fission_Buffer and Fission_Energy_Input_Vector.

                Fission_Buffer.FissionRetriever(Neutron);
                if(Fission_Energy_Input_Vector.DataFullyRetrieved()){
                    seed += 100;// The seed must be updated, so that the fission energies do not repeat themselves.
                    multithread_mt64 mt64(seed);

                    fission_distribution_file_builder( 50000, execution_number, mt64 );
                    Fission_Energy_Input_Vector.BinaryInput();

                    msg.str("");
                    msg << "In " << __FUNCTION__ << " new fission distribution file created.\n" << std::endl;
                    Logger.to_file( "Log_Files/New_Fission_Distribution_File.txt", std::this_thread::get_id(), msg.str() );
                }// End if(Fission_Energy_Input_Vector.DataFullyRetrieved()).
                Fission_Energy_Input_Vector.Retrieve(Neutron.energy);
                Neutron.birth.energy = Neutron.energy;

                New_Neutrons_Output_Matrix.Add( Neutron, (Neutron.local_step - 1) );

            }// End if(Fission_Buffer.RemainingFissions() > 0).

            else{// Neutron data comes from Checkpoint_Input_Vector. (Fission_Buffer.RemainingFissions() == 0).
                Checkpoint_Input_Vector.Retrieve(Neutron);
                Neutron.local_step = 0;// Neutron.local_step must be reseted.
            }// End else.

            while( !Neutron.Absorbed && !Neutron.Escaped ){
                if(Neutron.local_step < interval_size){// The neutron has not yet reached a Checkpoint.

                    /* In this block the microscopic and macroscopic cross sections are calculated. */
//                    microscopic_cross_section_function(Cross_Sections, Neutron.energy);
//                    macroscopic_cross_section_function(Region_1, Cross_Sections);
//                    macroscopic_cross_section_function(Region_2, Cross_Sections);
//                    macroscopic_cross_section_function(Region_3, Cross_Sections);

                    /* In this block the displacement is calculated.
                     * Here the following values are updated:
                     *     Neutron.position;
                     *     Neutron.time.step;
                     *     Neutron.time.life;
                     *     Neutron.time.chain;
                     *
                     * The value Neutron.step_life is also updated, but not Neutron.step, nor Neutron.local_step.
                     * It is considered that the Monte Carlo step has a starting and an ending point and,
                     *  although the step is the same, there is an interval between these limits.
                     */


                    double RandomEnergy = inv_CDF( mt64.genRand_real1() );
                    double RandomAlpha  = 2.0 * M_PI * mt64.genRand_real2();
                    double RandomBeta   = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;

                    displacement_function( Neutron,
                                           Geometry,
                                           Region_Solution.Total_Macroscopic_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta ), //Vacuum
                                           Region_Solution.Total_Macroscopic_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta ), //Steel
                                           Region_Solution.Total_Macroscopic_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta ), //Vacuum
//                                           Region_Copper_Sphere.Total_Macroscopic_Cross_Section( Neutron.energy ), //Copper
//                                           Region_Vacuum       .Total_Macroscopic_Cross_Section( Neutron.energy ), //Vacuum
//                                           Region_Iron_Sphere  .Total_Macroscopic_Cross_Section( Neutron.energy ), //Iron
                                           mt64 );
                    Neutron.step_life++;

                    Neutron.largest_R = std::max( radial_position(Neutron.eos_position), Neutron.largest_R );

                    /* After the displacement the limits are checked, the energy limits are rechecked on scattering
                     * and minimum life and chain limits are checked only at neutron history termination (escape, capture and fission).
                     */
                    SimReturn.limits.max_generation = std::max(Neutron.generation, SimReturn.limits.max_generation);

                    SimReturn.limits.min_energy = std::min(Neutron.energy, SimReturn.limits.min_energy);
                    SimReturn.limits.max_energy = std::max(Neutron.energy, SimReturn.limits.max_energy);

                    SimReturn.limits.min_step_length = std::min(Neutron.step_length, SimReturn.limits.min_step_length);
                    SimReturn.limits.max_step_length = std::max(Neutron.step_length, SimReturn.limits.max_step_length);

                    SimReturn.limits.min_time.step  = std::min(Neutron.time.step, SimReturn.limits.min_time.step);
                    SimReturn.limits.max_time.step  = std::max(Neutron.time.step, SimReturn.limits.max_time.step);

                    SimReturn.limits.min_time.life  = std::min(Neutron.time.life, SimReturn.limits.min_time.life);
                    SimReturn.limits.max_time.life  = std::max(Neutron.time.life, SimReturn.limits.max_time.life);

                    SimReturn.limits.min_time.chain = std::min(Neutron.time.chain, SimReturn.limits.min_time.chain);
                    SimReturn.limits.max_time.chain = std::max(Neutron.time.chain, SimReturn.limits.max_time.chain);


                    /* In this block the neutron's region at the end of the Monte Carlo step is analyzed.
                     * If the neutron remains inside the reactor's boundaries the region in which a reaction
                     *  takes place is defined. Otherwise the neutron is considered to have escaped the reactor.
                     */
                    region_number = check_region(Neutron.eos_position, Geometry);

                    if(region_number == 1){
                        Region_Temp = Region_Solution;
                    }// End if(region_number == 1).

                    else if(region_number == 2){
                        Region_Temp = Region_Solution;
                    }// End else if(region_number == 2).

                    else if(region_number == 3){
                        Region_Temp = Region_Solution;
                    }// End else if(region_number == 3).

//                    else if(region_number == 4){
//                        Region_Temp = Region_Copper_Sphere;
//                    }// End else if(region_number == 4).
//
//                    else if(region_number == 5){
//                        Region_Temp = Region_Vacuum;
//                    }// End else if(region_number == 5).
//
//                    else if(region_number == 6){
//                        Region_Temp = Region_Iron_Sphere;
//                    }// End else if(region_number == 6).

                    else{// The neutron has escaped, (region_number == 4).
                        /* Neutrons that escaped the reactor will have their simulation terminated
                         *  at the end of while( !Neutron.Absorbed && !Neutron.Escaped ).
                         */
                        Neutron.Escaped = true;
                        Escape_Output_Matrix.Add(Neutron, Neutron.local_step);
                        total_escapes++;

                        SimReturn.limits.min_time.life  = std::min(Neutron.time.life, SimReturn.limits.min_time.life);
                        SimReturn.limits.min_time.chain = std::min(Neutron.time.chain, SimReturn.limits.min_time.chain);
                    }// End else.

                    /* If the neutrons remains inside the reactor it will
                     *  partake in a reaction at the end of the Monte Carlo step.
                     */
                    if( !Neutron.Escaped ){
                        /* Firstly the reaction is chosen with the interaction_roulette() function. */
//                        interaction_roulette(Interaction, Isotope, Region_Temp, mt64);
                        Interaction = interaction_roulette( Region_Temp, Neutron, RandomEnergy, RandomAlpha, RandomBeta, mt64 );

                        /* The chosen interaction is then computed, and the OutputMatrix variables are updated. */
                            /* Definition of collision target. */
//                        if(Isotope.H){
//                            if(Neutron.energy > 1E-6){Mass_Number = 1.0;}
//                            else{Mass_Number = 2.0 * 1.0 + 16.0;}
//                        }// End if(Isotope.H).
//
//                        else if(Isotope.O_H2O){
//                            if(Neutron.energy > 1E-6){Mass_Number = 16.0;}
//                            else{Mass_Number = 2.0 * 1.0 + 16.0;}
//                        }// End if(Isotope.O_H2O).
//
//                        else if(Isotope.O_UO2_235){
//                            if(Neutron.energy > 1E-6){Mass_Number = 16.0;}
//                            else{Mass_Number = 235.04392 + 2.0 * 16.0;}
//                        }// End if(Isotope.O_UO2_235).
//
//                        else if(Isotope.O_UO2_238){
//                            if(Neutron.energy > 1E-6){Mass_Number = 16.0;}
//                            else{Mass_Number = 238.05078 + 2.0 * 16.0;}
//                        }// End if(Isotope.O_UO2_238).
//
//                        else if(Isotope.U_235){
//                            if(Neutron.energy > 1E-6){Mass_Number = 235.04392;}
//                            else{Mass_Number = 235.04392 + 2.0 * 16.0;}
//                        }// End if(Isotope.U_235).
//
//                        else{// (Isotope.U_238).
//                            if(Neutron.energy > 1E-6){Mass_Number = 238.05078;}
//                            else{Mass_Number = 238.05078 + 2.0 * 16.0;}
//                        }// End else.

                            /* Updating neutron data based on the collision target. */
                        Mass_Number = Interaction.Nuclide_Mass;
                        Neutron.isotope_of_last_interaction = Mass_Number;

                            /* Procedure of each interaction. */
                        if(Interaction.Reaction == "Capture"){
                            Neutron.Absorbed = true;
                            Capture_Output_Matrix.Add(Neutron, Neutron.local_step);
                            total_captures++;

                            SimReturn.limits.min_time.life  = std::min(Neutron.time.life, SimReturn.limits.min_time.life);
                            SimReturn.limits.min_time.chain = std::min(Neutron.time.chain, SimReturn.limits.min_time.chain);
                        }// End if(Interaction.capture).

                        else if(Interaction.Reaction == "Fission"){
                            New_Neutrons = new_neutrons(mt64);

                            Fission_Temp.multiplicity = New_Neutrons;
                            Fission_Temp.neutron      = Neutron;

                            Fission_Buffer.FissionStorer(Neutron, New_Neutrons, mt64);

                            Neutron.Absorbed = true;
                            Fission_Output_Matrix.Add(Fission_Temp, Neutron.local_step);
                            total_fissions++;
                            total_new_neutrons += New_Neutrons;

                            SimReturn.limits.min_time.life  = std::min(Neutron.time.life, SimReturn.limits.min_time.life);
                            SimReturn.limits.min_time.chain = std::min(Neutron.time.chain, SimReturn.limits.min_time.chain);
                        }// End if(Interaction.fission).

                        else{// Interaction.scattering
                            Collision.theta = M_PI * mt64.genRand_real2();

                            if ( thermalizationModel ) {
                                CM_to_Lab_CoordSystem_function(Collision, Mass_Number);
                                new_direction(Neutron, Collision, mt64);

                                if(Neutron.distribution != 1){

                                    Thermalisation_Temp.energy_before_scattering = Neutron.energy;

                                    Neutron.energy *= (std::pow(Mass_Number, 2) + 1.0 + 2.0 * Mass_Number * std::cos(Collision.theta)) /
                                     std::pow(Mass_Number + 1.0, 2);

                                    RandomVar = mt64.genRand_real2();
                                    if(RandomVar >= CDF_MaxBoltz(Neutron.energy, Temperature)){// Neutron is considered thermal.
                                        if(Neutron.distribution == 3){Counter.Trasfer_3_1[Neutron.local_step]++;}
                                        else{Counter.Trasfer_2_1[Neutron.local_step]++;}

                                        Neutron.last_scattering_before_thermal = Mass_Number;

                                        Thermalisation_Temp.energy_after_scattering = Neutron.energy;
                                        Thermalisation_Temp.last_scattering_before_thermal = Neutron.last_scattering_before_thermal;
                                        Thermalisation_Output_Matrix.Add(Thermalisation_Temp, Neutron.local_step);

                                        Neutron.distribution = 1;
                                        Neutron.energy       = inv_CDF( mt64.genRand_real3() );
                                    }// End if(RandomVar >= CDF_MaxBoltz(Neutron.energy, Temperature)).

                                    else if(Neutron.distribution == 3){
                                        Counter.Trasfer_3_2[Neutron.local_step]++;

                                        Neutron.distribution = 2;
                                    }

                                }// End if(Neutron.distribution != 1).

                                else{// Neutron.distribution == 1
                                    Neutron.energy = inv_CDF( mt64.genRand_real3() );
                                }
                            }

                            else {// 3DModel

                                particle neutronP ( Neutron.energy, 1.0, {Neutron.direction.alpha, Neutron.direction.beta} );
                                particle targetP ( RandomEnergy, Mass_Number, {RandomAlpha, RandomBeta} );
//                                double RandomEnergy = inv_CDF( mt64.genRand_real1() );
//                                double RandomAlpha  = 2.0 * M_PI * mt64.genRand_real2();
//                                double RandomBeta   = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;

                                scattering(neutronP, targetP, Collision.theta);

                                Neutron.energy = neutronP.Energy;

                                RandomVar = mt64.genRand_real2();
                                if(RandomVar >= CDF_MaxBoltz(Neutron.energy, Temperature)){// Neutron is considered thermal.
                                    Neutron.distribution = 1;
                                }
                                else {
                                    Neutron.distribution = 2;
                                }
                            }

                            Scattering_Output_Matrix.Add(Neutron, Neutron.local_step);
                            total_scatterings++;
//                            if(Neutron.isotope_of_last_interaction <= 20.0){H2O_scatterings++;}
//                            else{UO2_scatterings++;}

                            SimReturn.limits.min_energy = std::min(Neutron.energy, SimReturn.limits.min_energy);
                            SimReturn.limits.max_energy = std::max(Neutron.energy, SimReturn.limits.max_energy);
                        }// End else.

                        /* Lastly the number of the Monte Carlo step is updated.
                         * Neutrons that were scattered will continue at the beginning of while( !Neutron.Absorbed && !Neutron.Escaped ).
                         * Neutrons that were absorbed will have their simulation terminated
                         *  at the end of while( !Neutron.Absorbed && !Neutron.Escaped ).
                         */
                        Neutron.local_step++;
                        Neutron.step++;

                        /* Lastly the position of the neutron is updated, so that it begins the next step at the final position of the previous. */
                        Neutron.sos_position = Neutron.eos_position;
                    }// End if( !Neutron.Escaped ).
                }// End if(Neutron.local_step < interval_size).

                else{// Neutron.local_step == interval_size, the neutron is added to the Checkpoint_Output_Vector.
                    Checkpoint_Output_Vector.Add(Neutron);
                    final_neutrons++;
                    break;// Out of while( !Neutron.Absorbed && !Neutron.Escaped ).
                }// End else.
            }// End while( !Neutron.Absorbed && !Neutron.Escaped ).

            total_histories++;
        }//End while( !Checkpoint_Input_Vector.DataFullyRetrieved() || (Fission_Buffer.RemainingFissions() != 0) ).
    }// End if(initial_neutrons > 0).

    /* At the end of this function all output classes will write their data to their files. */
    Checkpoint_Output_Vector.BinaryOutput();

    Fission_Output_Matrix.BinaryOutput();
    Scattering_Output_Matrix.BinaryOutput();
    Capture_Output_Matrix.BinaryOutput();
    Escape_Output_Matrix.BinaryOutput();
    Thermalisation_Output_Matrix.BinaryOutput();
    New_Neutrons_Output_Matrix.BinaryOutput();

    Counter.BinaryOutput();

    msg.str("");
    msg << std::setfill(' ');
    msg << "        Initial neutrons: "   << std::setw(12) << initial_neutrons   << "\n";
    msg << "        Final neutrons: "     << std::setw(14) << final_neutrons     << "\n";
    msg << "        Total histories: "    << std::setw(13) << total_histories    << "\n";
    msg << "        Total escapes: "      << std::setw(15) << total_escapes      << "\n";
    msg << "        Total captures: "     << std::setw(14) << total_captures     << "\n";
    msg << "        Total fissions: "     << std::setw(14) << total_fissions     << "\n";
    msg << "        Total new neutrons: " << std::setw(10) << total_new_neutrons << "\n";
    msg << "        Total scatterings: "  << std::setw(11) << total_scatterings  << std::endl;
    Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );
//    std::cout << "          H2O scatterings: "  << std::setw(11) << H2O_scatterings   << std::endl;
//    std::cout << "          UO2 scatterings: "  << std::setw(11) << UO2_scatterings   << std::endl;

    return SimReturn;
}
