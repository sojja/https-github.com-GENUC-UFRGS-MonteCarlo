#ifndef SIMULATION_H_INCLUDED
#define SIMULATION_H_INCLUDED

#include <limits>
#include "Structs_header.h"

class simulation_parameters {

    public:

        unsigned int execution_number;

        unsigned int interval_size;
        unsigned int number_of_intervals;

        unsigned int initial_neutrons;

        rectangular_geometry_struct geometry;

        bool thermalizationModel;


        simulation_parameters ( unsigned int Execution_number
                              , unsigned int Interval_size
                              , unsigned int Number_of_intervals
                              , unsigned int Initial_neutrons
                              , rectangular_geometry_struct Geometry
                              , bool        Model
                              ) {

            execution_number    = Execution_number;
            interval_size       = Interval_size;
            number_of_intervals = Number_of_intervals;
            initial_neutrons    = Initial_neutrons;
            geometry            = Geometry;
            thermalizationModel = Model;
        }
};


class simulation_limits {

    public:


        unsigned int max_step;
        unsigned int min_step;

        time_struct max_time;
        time_struct min_time;

        double max_step_length;
        double min_step_length;

        double max_energy;
        double min_energy;

        unsigned int max_generation;

        simulation_limits(){
            max_step = 0;
            min_step = std::numeric_limits <unsigned int>::infinity();

            max_step_length = 0.0;
            min_step_length = std::numeric_limits <double>::infinity();

            max_generation = 0;

            max_energy = 0.0;
            min_energy = std::numeric_limits <double>::infinity();

            min_time.step  = std::numeric_limits <double>::infinity();
            min_time.life  = std::numeric_limits <double>::infinity();
            min_time.chain = std::numeric_limits <double>::infinity();
        }
};


class simulation_return {

    public:

        simulation_limits limits;

};


simulation_return simulation( unsigned int interval_start
                            , unsigned int interval_size
                            , unsigned int execution_number
                            , rectangular_geometry_struct & Geometry
                            , unsigned seed
                            , bool thermalizationModel
                            );


simulation_return thread_simulation ( simulation_parameters Parameters );

#endif // SIMULATION_H_INCLUDED
