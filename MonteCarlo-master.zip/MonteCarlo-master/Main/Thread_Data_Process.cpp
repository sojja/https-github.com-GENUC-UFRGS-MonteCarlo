#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <thread>
#include "Structs_header.h"
#include "multithread_logger.h"
#include "Data_Process.h"


data_process_return thread_data_process(data_process_parameters Parameters){

    /* Variables to store the simulation limits. */
    data_process_return DataProcRet;
    data_process_return DataProcessReturns;

    /* Variables that define both the simulation and the data processing. */
    unsigned int interval_number;
    unsigned int interval_start;

    /* Message container */
    std::stringstream msg;

    auto execution_chrono_start = std::chrono::system_clock::now();// Start execution_clock.

    msg.str("");
    msg << "Execution: " << Parameters.execution_number << std::endl;
    Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

    for(interval_number = 0; interval_number < Parameters.number_of_intervals; interval_number++){

        auto interval_chrono_start = std::chrono::system_clock::now();// Start of interval_clock.

        interval_start = interval_number * Parameters.interval_size;

        msg.str("");
        msg << std::setfill('-');
        msg << std::setw(50) << "\n";
        msg << "\n";
        msg << "    Execution: "     << Parameters.execution_number << ", Interval: " << interval_number << std::endl;
        //std::cout << "    Interval: "  << interval_number  << " ( seed = " << seed << " )" << std::endl;
        msg << "    Initial step : " << interval_number       * Parameters.interval_size
            << ", Final step: "      << (interval_number + 1) * Parameters.interval_size - 1 << "\n" << std::endl;
        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );


        DataProcessReturns = data_process( interval_start,
                                           Parameters.interval_size,
                                           Parameters.execution_number,
                                           Parameters.geometry,
                                           Parameters.limits );

        for (auto matrix_element : DataProcessReturns.MatrixHist) {
            DataProcRet.MatrixHist[ matrix_element.first ].Add( matrix_element.second );
        }

        for (auto vector_element : DataProcessReturns.VectorHist) {
            DataProcRet.VectorHist[ vector_element.first ].Add( vector_element.second );
        }


        auto interval_chrono_end = std::chrono::system_clock::now();// Stoppage of interval_clock.

        msg.str("");
        msg << "\n    Interval processing time: "
            << std::chrono::duration <double> (interval_chrono_end - interval_chrono_start).count()
            << "s\n" << std::endl;
        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

        msg.str("");
        msg << std::setfill(' ');
        msg << "< Data process " << std::setw(4) << Parameters.execution_number
            << " > Interval: "   << std::setw(4) << interval_number + 1 << "/" << Parameters.number_of_intervals
            << "    "            << std::chrono::duration <double> (interval_chrono_end - interval_chrono_start).count() << "s";
        Logger.to_terminal_tmp( std::this_thread::get_id(), msg.str() );

    }// End for(interval_number = 0; interval_number < number_of_intervals; interval_number++).

    auto execution_chrono_end = std::chrono::system_clock::now();

    msg.str("");
    msg << "Data processing time: "
        << std::chrono::duration <double> (execution_chrono_end - execution_chrono_start).count()
        << "s\n" << std::endl;
    msg << std::setfill('*');
    msg << std::setw(50) << "\n" << std::endl;
    Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

    msg.str("");
    msg << std::setfill(' ');
    msg << "< Data process " << std::setw(4) << Parameters.execution_number
        << " > Completed.    " << std::chrono::duration <double> (execution_chrono_end - execution_chrono_start).count() << "s";
    Logger.to_terminal_store( std::this_thread::get_id(), msg.str() );

    return DataProcRet;
}
