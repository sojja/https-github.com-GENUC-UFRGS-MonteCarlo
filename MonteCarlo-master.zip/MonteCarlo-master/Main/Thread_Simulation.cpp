#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <thread>
#include "Structs_header.h"
#include "multithread_logger.h"
#include "Simulation.h"
#include "Initial_Neutrons.h"
#include "Auxiliar_Functions.h"


simulation_return thread_simulation(simulation_parameters Parameters){

    unsigned seed;

    /* Variables to store the simulation limits. */
    simulation_return SimRet;
    std::vector <simulation_return> SimulationReturns(Parameters.number_of_intervals);

    SimRet.limits.min_step = 0;
    SimRet.limits.max_step = Parameters.number_of_intervals * Parameters.interval_size;

    /* Variables that define both the simulation and the data processing. */
    unsigned int interval_number;
    unsigned int interval_start;

    /* Message container */
    std::stringstream msg;

    auto execution_chrono_start = std::chrono::system_clock::now();// Start execution_clock.

    seed = (unsigned) Parameters.execution_number;
    seed += 50000000;

    inital_neutrons_file_builder(Parameters.initial_neutrons, Parameters.execution_number, Parameters.geometry, seed);

    msg.str("");
    msg << "Execution: " << Parameters.execution_number << " ( seed = " << seed << " )" << std::endl;
    Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

    for(interval_number = 0; interval_number < Parameters.number_of_intervals; interval_number++){

        auto interval_chrono_start = std::chrono::system_clock::now();// Start of interval_clock.

        interval_start = interval_number * Parameters.interval_size;
        seed           = 1000 * interval_number + 1 * Parameters.execution_number;
        seed += 50000000;

        msg.str("");
        msg << std::setfill('-');
        msg << std::setw(50) << "\n";
        msg << "\n";
        msg << "    Execution: "     << Parameters.execution_number << ", Interval: " << interval_number  << " ( seed = " << seed << " )" << std::endl;
        //std::cout << "    Interval: "  << interval_number  << " ( seed = " << seed << " )" << std::endl;
        msg << "    Initial step : " << interval_number       * Parameters.interval_size
            << ", Final step: "      << (interval_number + 1) * Parameters.interval_size - 1 << "\n" << std::endl;
        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );


        SimulationReturns[interval_number] = simulation( interval_start
                                                       , Parameters.interval_size
                                                       , Parameters.execution_number
                                                       , Parameters.geometry
                                                       , seed
                                                       , Parameters.thermalizationModel);


        SimRet.limits = Min_and_Max( SimRet.limits, SimulationReturns[interval_number].limits );

        auto interval_chrono_end = std::chrono::system_clock::now();// Stoppage of interval_clock.

        msg.str("");
        msg << "\n    Interval processing time: "
            << std::chrono::duration <double> (interval_chrono_end - interval_chrono_start).count()
            << "s\n" << std::endl;
        Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

        msg.str("");
        msg << std::setfill(' ');
        msg << "< Execution "  << std::setw(4) << Parameters.execution_number
            << " > Interval: " << std::setw(4) << interval_number + 1 << "/" << Parameters.number_of_intervals
            << "    "          << std::chrono::duration <double> (interval_chrono_end - interval_chrono_start).count() << "s";
        Logger.to_terminal_tmp( std::this_thread::get_id(), msg.str() );

        msg.str("");
        msg << "    Execution " << Parameters.execution_number << ", Interval " << interval_number << ":\n"
            << "        Maximum generation = " << SimulationReturns[interval_number].limits.max_generation << "\n"
            << "        Maximum energy     = " << SimulationReturns[interval_number].limits.max_energy     << "\n"
            << "        Minimum energy     = " << SimulationReturns[interval_number].limits.min_energy     << "\n"
            << "        Maximum step time  = " << SimulationReturns[interval_number].limits.max_time.step  << "\n"
            << "        Minimum step time  = " << SimulationReturns[interval_number].limits.min_time.step  << "\n"
            << "        Maximum life time  = " << SimulationReturns[interval_number].limits.max_time.life  << "\n"
            << "        Minimum life time  = " << SimulationReturns[interval_number].limits.min_time.life  << "\n"
            << "        Maximum chain time = " << SimulationReturns[interval_number].limits.max_time.chain << "\n"
            << "        Minimum chain time = " << SimulationReturns[interval_number].limits.min_time.chain << "\n" << std::endl;
        Logger.to_file( "Log_Files/Limits.txt", std::this_thread::get_id(), msg.str() );
    }// End for(interval_number = 0; interval_number < number_of_intervals; interval_number++).

    auto execution_chrono_end = std::chrono::system_clock::now();

    msg.str("");
    msg << "Execution processing time: "
        << std::chrono::duration <double> (execution_chrono_end - execution_chrono_start).count()
        << "s\n" << std::endl;
    msg << std::setfill('*');
    msg << std::setw(50) << "\n" << std::endl;
    Logger.to_file( log_filename, std::this_thread::get_id(), msg.str() );

    msg.str("");
    msg << std::setfill(' ');
    msg << "< Execution " << std::setw(4) << Parameters.execution_number
        << " > Completed.    " << std::chrono::duration <double> (execution_chrono_end - execution_chrono_start).count() << "s";
    Logger.to_terminal_store( std::this_thread::get_id(), msg.str() );

    msg.str("");
    msg << "Execution " << Parameters.execution_number << ":\n"
        << "    Maximum generation = " << SimRet.limits.max_generation << "\n"
        << "    Maximum energy     = " << SimRet.limits.max_energy     << "\n"
        << "    Minimum energy     = " << SimRet.limits.min_energy     << "\n"
        << "    Maximum step time  = " << SimRet.limits.max_time.step  << "\n"
        << "    Minimum step time  = " << SimRet.limits.min_time.step  << "\n"
        << "    Maximum life time  = " << SimRet.limits.max_time.life  << "\n"
        << "    Minimum life time  = " << SimRet.limits.min_time.life  << "\n"
        << "    Maximum chain time = " << SimRet.limits.max_time.chain << "\n"
        << "    Minimum chain time = " << SimRet.limits.min_time.chain << "\n" << std::endl;
    msg << std::setfill('*');
    msg << std::setw(50) << "\n";
    Logger.to_file( "Log_Files/Limits.txt", std::this_thread::get_id(), msg.str() );


    return SimRet;
}
