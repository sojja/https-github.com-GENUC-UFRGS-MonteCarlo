#ifndef MULTITHREAD_MT64_H_INCLUDED
#define MULTITHREAD_MT64_H_INCLUDED

#include <random>

class multithread_mt64{
    private:

        std::mt19937_64 m_generator;

    public:

        multithread_mt64 (unsigned seed) : m_generator(seed) {}

        double genRand_real1();

        double genRand_real2();

        double genRand_real3();
};

#endif // MULTITHREAD_MT64_H_INCLUDED
