#include "multithread_logger.h"

void multi_logger::clear_terminal(){
    std::cout << "\033[2J\033[1;1H";
}


multi_logger::multi_logger(std::string terminal_to_file_filename) {
    m_save_terminal_filename = terminal_to_file_filename;
}


multi_logger::~multi_logger() {
    save_terminal();
    save_file();
}


void multi_logger::to_terminal_tmp(std::thread::id thread_id, std::string message) {

    m_mtx.lock();

    m_tmp_msg[thread_id] = message;

    clear_terminal();

    std::cout << m_terminal_stored_msg;
    for (auto & element : m_tmp_msg) {
        std::cout << "Thread #" << element.first << ": " << element.second << std::endl;
    }

    m_mtx.unlock();
}


void multi_logger::to_terminal_store(std::thread::id thread_id, std::string message) {

    m_mtx.lock();

    std::stringstream ss;

    ss << "Thread #" << thread_id << ": " << message << std::endl;

    m_terminal_stored_msg += ss.str();

    m_tmp_msg.erase (thread_id);

    clear_terminal();
    std::cout << m_terminal_stored_msg;
    for (auto & element : m_tmp_msg) {
        std::cout << "Thread #" << element.first << ": " << element.second << std::endl;
    }

    m_mtx.unlock();
}


void multi_logger::save_terminal() {
    std::ofstream ofs(m_save_terminal_filename);

    ofs << m_terminal_stored_msg;

    ofs.close();
}


void multi_logger::to_file(std::string filename, std::thread::id thread_id, std::string message){
    m_mtx.lock();

    m_file_stored_msg[filename][thread_id] += message;

    m_mtx.unlock();
}


void multi_logger::save_file(){
    for (auto & element : m_file_stored_msg) {
        std::ofstream ofs(element.first);

        for (auto & new_element : element.second) {
            ofs << "Thread #" << new_element.first << ":\n" << new_element.second << std::endl;
        }
        ofs.close();
    }
}
