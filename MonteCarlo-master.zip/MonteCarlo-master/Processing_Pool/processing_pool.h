#ifndef PROCESSING_POOL_H_INCLUDED
#define PROCESSING_POOL_H_INCLUDED

#include <future>
#include <thread>
#include <vector>

template<typename R> bool is_ready(std::future<R> const& f) { return f.wait_for(std::chrono::seconds(0)) == std::future_status::ready; }


template <typename f_args> class void_pool{

    private:
        typedef void (*f_pointer)(f_args);

        f_pointer m_func;

        std::vector <f_args> m_args;

        int m_cores;

        int m_execs;

        bool m_runFunc(f_args arg, int exec){
            m_func(arg);
            return true;
        }

    public:

        void_pool(std::vector <f_args> arguments, int cores, f_pointer func){
            m_args  = arguments;
            m_cores = cores;
            m_execs = arguments.size();
            m_func  = func;
        }

        virtual ~void_pool(){};

        void Run(){
            int completed_execs  = 0;
            int available_cores  = m_cores;

            int running_exec = 0;

            bool wait_return;

            std::vector < std::future <bool> > futures;

            while (completed_execs < m_execs) {
                wait_return = true;

                if ( (running_exec < m_execs) && (available_cores > 0) ) {
                    futures.push_back( std::async( &void_pool::m_runFunc, this, m_args[running_exec], running_exec) );

                    running_exec++;
                    available_cores--;
                }


                else{
                    while (wait_return) {
                        for ( int exec = 0; exec < futures.size(); exec++ ) { //< std::min(m_execs, m_cores) ) {
                            if ( is_ready( futures[exec] ) ) {
                                if ( futures[exec].get() ){
                                    completed_execs++;
                                    available_cores++;
                                    futures.erase(futures.begin() + exec);
                                    wait_return = false;
                                }
                            }
                        }
                    }
                }
            }
        }

};


template <typename f_return, typename f_args> class return_pool{

    private:
        typedef f_return (*f_pointer)(f_args);

        std::vector <f_return> m_returns;

        f_pointer m_func;

        std::vector <f_args> m_args;

        int m_cores;

        int m_execs;

        bool m_runFunc(f_args args, int exec){
            m_returns[exec] = m_func(args);
            return true;
        }

    public:

        return_pool(std::vector <f_args> arguments, int cores, f_pointer func){
            m_args = arguments;
            m_cores = cores;
            m_execs = arguments.size();
            m_func = func;
            m_returns.resize( arguments.size() );
        }

        ~return_pool(){};

        void Run(){
            int completed_execs  = 0;
            int available_cores  = m_cores;

            int running_exec = 0;

            bool wait_return;

            std::vector < std::future <bool> > futures;

            while (completed_execs < m_execs) {
                wait_return = true;

                if ( (running_exec < m_execs) && (available_cores > 0) ) {
                    futures.push_back( std::async( &return_pool::m_runFunc, this, m_args[running_exec], running_exec) );

                    running_exec++;
                    available_cores--;
                }


                else{
                    while (wait_return) {
                        for ( int exec = 0; exec < futures.size(); exec++ ) { //< std::min(m_execs, m_cores) ) {
                            if ( is_ready( futures[exec] ) ) {
                                if ( futures[exec].get() ){
                                    completed_execs++;
                                    available_cores++;
                                    futures.erase(futures.begin() + exec);
                                    wait_return = false;
                                }
                            }
                        }
                    }
                }
            }
        }


        std::vector <f_return> Returns() {
            return m_returns;
        }

};

#endif // PROCESSING_POOL_H_INCLUDED
