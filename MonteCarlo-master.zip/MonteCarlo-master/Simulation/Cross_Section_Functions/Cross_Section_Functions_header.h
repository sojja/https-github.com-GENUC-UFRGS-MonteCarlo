#ifndef CROSS_SECTION_FUNCTIONS_HEADER_H_INCLUDED
#define CROSS_SECTION_FUNCTIONS_HEADER_H_INCLUDED

double H_capture_CS(double E);

double H_scattering_CS(double E);

double O_capture_CS(double E);

double O_scattering_CS(double E);

double F19_capture_CS(double E);

double F19_scattering_CS(double E);

double U234_fission_CS(double E);

double U234_capture_CS(double E);

double U234_scattering_CS(double E);

double U235_fission_CS(double E);

double U235_capture_CS(double E);

double U235_scattering_CS(double E);

double U236_fission_CS(double E);

double U236_capture_CS(double E);

double U236_scattering_CS(double E);

double U238_fission_CS(double E);

double U238_capture_CS(double E);

double U238_scattering_CS(double E);

double C12_capture_CS(double E);

double C12_scattering_CS(double E);

double Mg24_capture_CS(double E);

double Mg24_scattering_CS(double E);

double Al27_capture_CS(double E);

double Al27_scattering_CS(double E);

double Si28_capture_CS(double E);

double Si28_scattering_CS(double E);

double Si29_capture_CS(double E);

double Si29_scattering_CS(double E);

double Si30_capture_CS(double E);

double Si30_scattering_CS(double E);

double P31_capture_CS(double E);

double P31_scattering_CS(double E);

double S32_capture_CS(double E);

double S32_scattering_CS(double E);

double Ca40_capture_CS(double E);

double Ca40_scattering_CS(double E);

double Cr52_capture_CS(double E);

double Cr52_scattering_CS(double E);

double Mn55_capture_CS(double E);

double Mn55_scattering_CS(double E);

double Fe56_capture_CS(double E);

double Fe56_scattering_CS(double E);

double Ni58_capture_CS(double E);

double Ni58_scattering_CS(double E);

double Cu63_capture_CS(double E);

double Cu63_scattering_CS(double E);

double Cu65_capture_CS(double E);

double Cu65_scattering_CS(double E);

double Zn64_capture_CS(double E);

double Zn64_scattering_CS(double E);

double Zn66_capture_CS(double E);

double Zn66_scattering_CS(double E);

double Zn67_capture_CS(double E);

double Zn67_scattering_CS(double E);

double Zn68_capture_CS(double E);

double Zn68_scattering_CS(double E);

double Zn70_capture_CS(double E);

double Zn70_scattering_CS(double E);

double Ba138_capture_CS(double E);

double Ba138_scattering_CS(double E);

#endif // CROSS_SECTION_FUNCTIONS_HEADER_H_INCLUDED
