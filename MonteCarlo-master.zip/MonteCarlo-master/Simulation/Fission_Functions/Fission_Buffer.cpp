#include <vector>
#include <cmath>
#include "Fission_Buffer.h"
#include "Structs_header.h"

#include <thread>
#include <sstream>
#include "multithread_logger.h"
#include "multithread_MT64.h"

        FissionBuffer::FissionBuffer(){
            next_storage_location   = 0;
            last_retrieval_location = 0;

            total_stored_fissions    = 0;
            total_retrieved_fissions = 0;
            remaining_fissions       = 0;

            FissionVector.resize(500);
        }

        FissionBuffer::FissionBuffer(unsigned int vector_size){
            next_storage_location   = 0;
            last_retrieval_location = 0;

            total_stored_fissions    = 0;
            total_retrieved_fissions = 0;
            remaining_fissions       = 0;

            FissionVector.resize(vector_size);
        }

        FissionBuffer::~FissionBuffer(){
            std::stringstream msg;
            msg << "Fission buffer deallocated:\n"
                << "    Total stored fissions: " << total_stored_fissions << "\n"
                << "    Elements:              " << FissionVector.size()  << "\n"
                << "    Bytes:                 " << FissionVector.size() * sizeof(fission_struct) << "\n"
                << std::endl;
            Logger.to_file( "Log_Files/Fission_Buffer.txt", std::this_thread::get_id(), msg.str() );
        }


        void FissionBuffer::FissionStorer( const neutron_struct & NeutronData,
                                           unsigned short int number_of_new_neutrons,
                                           multithread_mt64 & mt64 ){
            unsigned int i;
            unsigned int vector_size;
            vector_size = FissionVector.size();

            i = next_storage_location;

            if(FissionVector[i].multiplicity == 0){
                FissionVector[i].multiplicity = number_of_new_neutrons;
                FissionVector[i].neutron      = NeutronData;

                /* The information of the emitted neutrons is updated or reseted. This is done
                 *  in order to locate the neutrons' emissions at the start of the next step.
                 */
                FissionVector[i].neutron.generation++;
                FissionVector[i].neutron.step++;
                FissionVector[i].neutron.local_step++;
                FissionVector[i].neutron.energy                         = 0.0;
                FissionVector[i].neutron.distribution                   = 3;
                FissionVector[i].neutron.step_life                      = 0;
                FissionVector[i].neutron.time.life                      = 0.0;
                FissionVector[i].neutron.last_scattering_before_thermal = 0.0;
                FissionVector[i].neutron.isotope_of_last_interaction    = 0.0;
                FissionVector[i].neutron.sos_position                   = NeutronData.eos_position;
                FissionVector[i].neutron.eos_position.x                 = 0.0;
                FissionVector[i].neutron.eos_position.y                 = 0.0;
                FissionVector[i].neutron.eos_position.z                 = 0.0;
                FissionVector[i].neutron.birth.energy                   = 0.0;
                FissionVector[i].neutron.birth.position                 = NeutronData.eos_position;
                FissionVector[i].neutron.birth.step                     = NeutronData.step + 1;
                FissionVector[i].neutron.Absorbed                       = false;
                FissionVector[i].neutron.direction.alpha                = 2.0 * M_PI * mt64.genRand_real2();
                FissionVector[i].neutron.direction.beta                 = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;

                total_stored_fissions += number_of_new_neutrons;
                remaining_fissions    += number_of_new_neutrons;
            }

            else{
                FissionVector.resize(vector_size + 1000);

                next_storage_location = vector_size;
                i = next_storage_location;

                FissionVector[i].multiplicity   = number_of_new_neutrons;
                FissionVector[i].neutron        = NeutronData;

                /* The information of the emitted neutrons is updated or reseted. This is done
                 *  in order to locate the neutrons' emissions at the start of the next step.
                 */
                FissionVector[i].neutron.generation++;
                FissionVector[i].neutron.step++;
                FissionVector[i].neutron.local_step++;
                FissionVector[i].neutron.energy                         = 0.0;
                FissionVector[i].neutron.distribution                   = 3;
                FissionVector[i].neutron.step_life                      = 0;
                FissionVector[i].neutron.time.life                      = 0.0;
                FissionVector[i].neutron.last_scattering_before_thermal = 0.0;
                FissionVector[i].neutron.isotope_of_last_interaction    = 0.0;
                FissionVector[i].neutron.sos_position                   = NeutronData.eos_position;
                FissionVector[i].neutron.eos_position.x                 = 0.0;
                FissionVector[i].neutron.eos_position.y                 = 0.0;
                FissionVector[i].neutron.eos_position.z                 = 0.0;
                FissionVector[i].neutron.birth.energy                   = 0.0;
                FissionVector[i].neutron.birth.position                 = NeutronData.eos_position;
                FissionVector[i].neutron.birth.step                     = NeutronData.step + 1;
                FissionVector[i].neutron.Absorbed                       = false;
                FissionVector[i].neutron.direction.alpha                = 2.0 * M_PI * mt64.genRand_real2();
                FissionVector[i].neutron.direction.beta                 = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;

                total_stored_fissions += number_of_new_neutrons;
                remaining_fissions    += number_of_new_neutrons;
            }

            next_storage_location++;
            if(next_storage_location >= FissionVector.size()){next_storage_location = 0;}

        }


        void FissionBuffer::FissionRetriever(neutron_struct& NeutronData){
            if(remaining_fissions > 0){
                unsigned int i;
                unsigned int vector_size;
                vector_size = FissionVector.size();

                i = last_retrieval_location;

                while(FissionVector[i].multiplicity == 0){
                    i++;
                    if(i >= vector_size){i = 0;}
                }

                NeutronData = FissionVector[i].neutron;

                FissionVector[i].multiplicity--;
                total_retrieved_fissions++;
                remaining_fissions--;

                last_retrieval_location = i;
            }
        }


        unsigned int FissionBuffer::RemainingFissions(){
            return remaining_fissions;
        }
