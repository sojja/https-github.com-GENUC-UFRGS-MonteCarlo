#ifndef FISSION_BUFFER_H_INCLUDED
#define FISSION_BUFFER_H_INCLUDED

#include <vector>
#include "Structs_header.h"
#include "multithread_MT64.h"

class FissionBuffer{
    private:

        unsigned int next_storage_location;
        unsigned int last_retrieval_location;

        unsigned int total_stored_fissions;
        unsigned int total_retrieved_fissions;
        unsigned int remaining_fissions;

        std::vector <fission_struct> FissionVector;

    public:

        FissionBuffer();

        FissionBuffer(unsigned int vector_size);

        ~FissionBuffer();


        void FissionStorer( const neutron_struct & NeutronData,
                            unsigned short int number_of_new_neutrons,
                            multithread_mt64 & mt64 );


        void FissionRetriever(neutron_struct& NeutronData);


        unsigned int RemainingFissions();

};

#endif // FISSION_BUFFER_H_INCLUDED
