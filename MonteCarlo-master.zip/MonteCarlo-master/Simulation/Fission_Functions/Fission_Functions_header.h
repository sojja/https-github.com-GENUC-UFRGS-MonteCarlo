#ifndef FISSION_FUNCTIONS_HEADER_H_INCLUDED
#define FISSION_FUNCTIONS_HEADER_H_INCLUDED

#include "multithread_MT64.h"

unsigned short int new_neutrons( multithread_mt64 & mt64 );

#endif // NEW_NEUTRONS_HEADER_H_INCLUDED
