#include <vector>
#include "multithread_MT64.h"

/** \brief This function returns the number of neutrons created by fission.
 *
 * \return unsigned short int
 *
 * This function returns the number of neutrons created by fission. It uses the Mersenne Twister random number generator to
 *  create a discrete distribution in which the only two possible values are 2 or 3 new neutrons. The mean of this distribution
 *  is equal to 2.48 neutrons.
 */


unsigned short int new_neutrons( multithread_mt64 & mt64 ){
    double rnd_fission;

    rnd_fission = mt64.genRand_real2();

    if(rnd_fission < 0.52){ return 2; }
    else{ return 3; }
}
