#include <tuple>
#include <Eigen/Dense>
#include "transformations.hpp"


double E2S (double Energy, double Mass) {
    return ( std::sqrt( 2 * Energy / (Mass * 931.49410242) ) ) * 299792458;// Mass converted to MeV/c^2, c in m/s.
}


double S2E (double Speed, double Mass) {
    return std::pow( (Speed / 299792458), 2 ) * (Mass * 931.49410242) / 2;
}


Eigen::Vector2d E2V (double Energy, double Mass, double angle) {
    Eigen::Vector2d Velocity;

    double speed = ( std::sqrt( 2 * Energy / (Mass * 931.49410242) ) ) * 299792458;// Mass converted to MeV/c^2, c in m/s.

    Velocity(0) = speed * std::cos(angle);
    Velocity(1) = speed * std::sin(angle);

    return Velocity;
}


Eigen::Vector3d E2V (double Energy, double Mass, direction Direction) {
    Eigen::Vector3d Velocity;

    double speed = ( std::sqrt( 2 * Energy / (Mass * 931.49410242) ) ) * 299792458;// Mass converted to MeV/c^2, c in m/s.

    Velocity(0) = speed * std::cos(Direction.Alpha) * std::cos(Direction.Beta);
    Velocity(1) = speed * std::sin(Direction.Alpha) * std::cos(Direction.Beta);
    Velocity(2) = speed * std::sin(Direction.Beta);

    return Velocity;
}


std::pair <double, double> V2E (Eigen::Vector2d Velocity, double Mass) {
    double speed =  std::hypot( Velocity(0), Velocity(1) );

    double Energy = std::pow( (speed / 299792458), 2 ) * (Mass * 931.49410242) / 2;

    double angle = std::atan2( Velocity(1), Velocity(0) );
    if (angle < 0) { angle += 2.0 * M_PI; }

    return std::pair <double, double> (Energy, angle);
}


std::pair <double, direction> V2E (Eigen::Vector3d Velocity, double Mass) {
    double speed =  std::hypot( Velocity(0), Velocity(1), Velocity(2) );

    double Energy = std::pow( (speed / 299792458), 2 ) * (Mass * 931.49410242) / 2;

    direction Direction;
    Direction.Beta  = std::asin( Velocity(2) / speed );
    Direction.Alpha = std::atan2( Velocity(1), Velocity(0) );
    if (Direction.Alpha < 0) { Direction.Alpha += 2.0 * M_PI; }

    return std::pair <double, direction> (Energy, Direction);
}
