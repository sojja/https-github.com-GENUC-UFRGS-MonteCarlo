#ifndef PARTICLES_TRANSFORMATIONS_HPP
#define PARTICLES_TRANSFORMATIONS_HPP

struct direction{
    double Alpha;
    double Beta;

    direction () : Alpha {0}, Beta {0} {}

    direction (double Alpha, double Beta) : Alpha {Alpha}
                                          , Beta  {Beta}
                                          {}
};

double E2S (double Energy, double Mass);

double S2E (double Speed, double Mass);

Eigen::Vector2d E2V (double Energy, double Mass, double angle);

Eigen::Vector3d E2V (double Energy, double Mass, direction Direction);

std::pair <double, double> V2E (Eigen::Vector2d Velocity, double Mass);

std::pair <double, direction> V2E (Eigen::Vector3d Velocity, double Mass);

#endif // PARTICLES_TRANSFORMATIONS_HPP
