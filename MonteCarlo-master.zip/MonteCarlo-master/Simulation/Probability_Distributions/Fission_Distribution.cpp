#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include "Output.h"
#include "multithread_MT64.h"

void fission_distribution_file_builder( unsigned int number_of_neutrons, unsigned int execution_number, multithread_mt64 & mt64 ){

    unsigned int i;
    double energy;
    double distribution_value;
    double test_value;
    double max_value = 0.359;// Maximum value of the fission energy PDF.

    std::stringstream filename;
    filename << "Bin_Files/Fission_Distribution_Files/Fission_Energy_PDF_" << execution_number << ".bin";

    OutputVector <double> Fission_Distribution( filename.str() );

    i = 0;
    while(i < number_of_neutrons){

//        energy = 0.10;
        energy = 20.0 * mt64.genRand_real3();// Energy in the range (0, 20)MeV.
        distribution_value = 0.453 *  std::exp(-1.036 * energy) * std::sinh( std::sqrt(2.29 * energy) );
        test_value = max_value * mt64.genRand_real3();

        if(test_value <= distribution_value){
            Fission_Distribution.Add(energy);
            i++;
        }
    }

    Fission_Distribution.BinaryOutput();

}
