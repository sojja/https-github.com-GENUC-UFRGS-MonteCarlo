#include <cmath>

double CDF_MaxBoltz(double e, double t){

    double k_boltz = 8.6173E-11;//Mev/K
    double answer;
    double a, aa, ee, pi;

    ee = std::sqrt(e);
    a  = k_boltz * t;
    aa = std::sqrt(a);
    pi = std::sqrt(M_PI);

    answer = std::erf(ee/aa) - 2.0 / (pi*aa) * ee * std::exp(-e/a);

    return answer;
}
