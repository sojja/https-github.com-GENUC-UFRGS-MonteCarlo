#ifndef PROBABILITY_DISTRIBUTIONS_HEADER_H_INCLUDED
#define PROBABILITY_DISTRIBUTIONS_HEADER_H_INCLUDED

#include "multithread_MT64.h"

void fission_distribution_file_builder( unsigned int number_of_neutrons, unsigned int execution_number, multithread_mt64 & mt64 );

double inv_CDF(double f_E);

double CDF_MaxBoltz(double e, double t);

#endif // PROBABILITY_DISTRIBUTIONS_HEADER_H_INCLUDED
