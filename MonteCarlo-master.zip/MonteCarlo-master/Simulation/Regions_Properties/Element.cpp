#include <string>
#include <vector>
#include <map>
#include "Nuclide.h"
#include "Element.h"


double element::element_mass () {

    double mass;
    double all_isotopes = 0.0;

    for (auto isotope : Isotopes) {
        all_isotopes += isotope.second.Mass_Percentage / isotope.second.Nuclide.Atomic_Mass;
    }

    mass = 1.0 / all_isotopes;

    return mass;
}

element::element (std::map <nuclide_id, isotope_abundance> isotopes) {
    Isotopes = isotopes;

    Element_Mass = element_mass();
}


nuclide element::Isotope ( neutron_struct Neutron
                        , double         RandomEnergy
                        , double         RandomAlpha
                        , double         RandomBeta
                        , double random_number
                        ) {

    double superior_limit = 0.0;

    double all_isotopes = 0.0;

    for (auto isotope : Isotopes) {
        all_isotopes += isotope.second.Nuclide.Total_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta )
                      * isotope.second.Mass_Percentage
                      / isotope.second.Nuclide.Atomic_Mass;
    }

    for (auto isotope : Isotopes) {
        superior_limit += ( isotope.second.Nuclide.Total_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta )
                          * isotope.second.Mass_Percentage
                          / isotope.second.Nuclide.Atomic_Mass
                          ) / all_isotopes;
        if (random_number < superior_limit){
            return isotope.second.Nuclide;
        }
    }
}


std::vector <element_total_macroscopic_cross_section_parameters> element::Istopes_Total_Cross_Section ( neutron_struct Neutron
                                                                                                      , double         RandomEnergy
                                                                                                      , double         RandomAlpha
                                                                                                      , double         RandomBeta
                                                                                                      ) {

    std::vector <element_total_macroscopic_cross_section_parameters> Result;

    for (auto isotope : Isotopes) {
        Result.push_back( element_total_macroscopic_cross_section_parameters ( isotope.second.Mass_Percentage
                                                                             , isotope.second.Nuclide.Atomic_Mass
                                                                             , isotope.second.Nuclide.Total_Cross_Section ( Neutron
                                                                                                                          , RandomEnergy
                                                                                                                          , RandomAlpha
                                                                                                                          , RandomBeta
                                                                                                                          )
                                                                             )
                        );
    }

    return Result;
}
