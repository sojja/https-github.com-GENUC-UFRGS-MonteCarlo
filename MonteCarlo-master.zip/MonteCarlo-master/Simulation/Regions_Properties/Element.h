#ifndef ELEMENT_H_INCLUDED
#define ELEMENT_H_INCLUDED

#include <string>
#include <vector>
#include <map>
#include "Nuclide.h"
#include "Structs_header.h"


struct isotope_abundance {

    nuclide Nuclide;
    double Mass_Percentage;

    isotope_abundance () {}

    isotope_abundance (nuclide isotope, double mass_percentage) {
        Nuclide         = isotope;
        Mass_Percentage = mass_percentage;
    }
};

struct element_total_macroscopic_cross_section_parameters {

    double Mass_Percentage;
    double Atomic_Mass;
    double Total_Cross_Section;

    element_total_macroscopic_cross_section_parameters ( double mass_percentage,
                                                         double atomic_mass,
                                                         double total_cross_section ) {

        Mass_Percentage     = mass_percentage;
        Atomic_Mass         = atomic_mass;
        Total_Cross_Section = total_cross_section;

    }

};

class element{

    private:

        double element_mass (void);

    public:

        double Element_Mass;

        std::map <nuclide_id, isotope_abundance> Isotopes;

        element (std::map <nuclide_id, isotope_abundance> isotopes);

        nuclide Isotope ( neutron_struct Neutron
                        , double         RandomEnergy
                        , double         RandomAlpha
                        , double         RandomBeta
                        , double random_number
                        );

        std::vector <element_total_macroscopic_cross_section_parameters> Istopes_Total_Cross_Section ( neutron_struct Neutron
                                                                                                     , double         RandomEnergy
                                                                                                     , double         RandomAlpha
                                                                                                     , double         RandomBeta
                                                                                                     );

};

#endif // ELEMENT_H_INCLUDED
