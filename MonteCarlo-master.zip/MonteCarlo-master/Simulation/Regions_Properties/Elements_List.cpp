#include <map>
#include "Nuclide.h"
#include "Nuclides_List.h"
#include "Element.h"
#include "Elements_List.h"

void elements:: Init_ele() {

element elements::H (std::map <nuclide_id, isotope_abundance> {
                     { nuclide_id (1, 1), isotope_abundance (nuclides::H1, 1.0)}
                     } );

element elements::C (std::map <nuclide_id, isotope_abundance> {
                     {nuclide_id (6, 12), isotope_abundance (nuclides::C12, 1.0)}
                     } );

element elements::O (std::map <nuclide_id, isotope_abundance> {
                     {nuclide_id (8, 16), isotope_abundance (nuclides::O16, 1.0)}
                     } );

element elements::Mg (std::map <nuclide_id, isotope_abundance> {
                      { nuclide_id (12, 24), isotope_abundance (nuclides::Mg24, 1.0)}
                      } );

element elements::Al (std::map <nuclide_id, isotope_abundance> {
                      { nuclide_id (13, 27), isotope_abundance (nuclides::Al27, 1.0)}
                      } );

element elements::Si (std::map <nuclide_id, isotope_abundance> {
                      {nuclide_id (14, 28), isotope_abundance (nuclides::Si28, 1.0)}
                      } );

element elements::P (std::map <nuclide_id, isotope_abundance> {
                     { nuclide_id (15, 31), isotope_abundance (nuclides::P31, 1.0)}
                     } );

element elements::S (std::map <nuclide_id, isotope_abundance> {
                     { nuclide_id (16, 32), isotope_abundance (nuclides::S32, 1.0)}
                     } );

element elements::Ca (std::map <nuclide_id, isotope_abundance> {
                      {nuclide_id (20, 40), isotope_abundance (nuclides::Ca40, 1.0)}
                      } );

element elements::Cr (std::map <nuclide_id, isotope_abundance> {
                      { nuclide_id (24, 52), isotope_abundance (nuclides::Cr52, 1.0)}
                      } );

element elements::Mn (std::map <nuclide_id, isotope_abundance> {
                      { nuclide_id (25, 55), isotope_abundance (nuclides::Mn55, 1.0)}
                      } );

element elements::Fe (std::map <nuclide_id, isotope_abundance> {
                      { nuclide_id (26, 56), isotope_abundance (nuclides::Fe56, 1.0)}
                      } );

element elements::Ni (std::map <nuclide_id, isotope_abundance> {
                      { nuclide_id (28, 58), isotope_abundance (nuclides::Ni58, 1.0)}
                      } );

element elements::Ba (std::map <nuclide_id, isotope_abundance> {
                      {nuclide_id (56, 138), isotope_abundance (nuclides::Ba138, 1.0)}
                      } );

//element elements::U (std::map <nuclide_id, isotope_abundance> {
//                     {nuclide_id (82, 238), isotope_abundance (nuclides:: U238, 1.0)}
//                     } );
}
