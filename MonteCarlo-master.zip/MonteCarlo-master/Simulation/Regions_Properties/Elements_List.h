#ifndef ELEMENTS_LIST_H_INCLUDED
#define ELEMENTS_LIST_H_INCLUDED

#include "Element.h"

namespace elements {

    void Init_ele();
    
    extern element H;

    extern element C;

    extern element O;

    extern element Mg;

    extern element Al;

    extern element Si;

    extern element P;

    extern element S;

    extern element Ca;

    extern element Cr;

    extern element Mn;

    extern element Fe;

    extern element Ni;

    extern element Ba;

//    extern element U;

}

#endif // ELEMENTS_LIST_H_INCLUDED
