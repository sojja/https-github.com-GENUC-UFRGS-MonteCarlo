#include <vector>
#include <map>
#include "Element.h"
#include "Molecule.h"

molecule::molecule () {}


molecule::molecule (double molecular_density, std::vector < std::pair <double, element> > formula) {
    Molecular_Density = molecular_density;
    Formula           = formula;

    Molecular_Mass = 0.0;
    for (size_t i = 0; i < Formula.size(); i++) {
        Molecular_Mass += Formula[i].first * Formula[i].second.Element_Mass;
    }
}


double molecule::Total_Macroscopic_Cross_Section ( neutron_struct Neutron
                                                 , double         RandomEnergy
                                                 , double         RandomAlpha
                                                 , double         RandomBeta
                                                 ) {

    double molecule_macroscopic_cross_section = 0.0;

    for (size_t i = 0; i < Formula.size(); i++){

        std::vector <element_total_macroscopic_cross_section_parameters> Isotopes;

        Isotopes = Formula[i].second.Istopes_Total_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta );

        double multiplication_factor = Formula[i].first;

        double sum_molecule     = 0.0;
        double isotopes_product = 1.0;
        double sum_products     = 0.0;
        std::vector <double> partial_products;

        std::vector <double> atomic_densities;
        std::vector <double> isotopes_total_macro_cross_section;

        for (size_t j = 0; j < Formula.size(); j++) {
            if (i != j) {
                sum_molecule += Formula[j].first * Formula[j].second.Element_Mass;
            }
        }

        for (size_t j = 0; j < Isotopes.size(); j++) {
            isotopes_product *= Isotopes[j].Atomic_Mass;
        }

        for (size_t j = 0; j < Isotopes.size(); j++) {
            partial_products.push_back(isotopes_product * Isotopes[j].Mass_Percentage / Isotopes[j].Atomic_Mass);
            sum_products += partial_products[j];
        }

        for (size_t j = 0; j < Isotopes.size(); j++) {
            atomic_densities.push_back( (multiplication_factor * avogrado * partial_products[j] * Molecular_Density)
                                        / (multiplication_factor * isotopes_product + sum_molecule * sum_products) );

            isotopes_total_macro_cross_section.push_back( atomic_densities[j] * Isotopes[j].Total_Cross_Section );
            molecule_macroscopic_cross_section += isotopes_total_macro_cross_section[j];
        }
    }

    return molecule_macroscopic_cross_section;
}


element molecule::Element ( neutron_struct Neutron
                          , double         RandomEnergy
                          , double         RandomAlpha
                          , double         RandomBeta
                          , double random_number
                          ) {

    double molecule_macroscopic_cross_section = Total_Macroscopic_Cross_Section ( Neutron, RandomEnergy, RandomAlpha, RandomBeta );

    double superior_limit = 0.0;

    for (size_t i = 0; i < Formula.size(); i++){

        std::vector <element_total_macroscopic_cross_section_parameters> Isotopes;

        Isotopes = Formula[i].second.Istopes_Total_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta );

        double multiplication_factor = Formula[i].first;

        double sum_molecule     = 0.0;
        double isotopes_product = 1.0;
        double sum_products     = 0.0;
        std::vector <double> partial_products;

        std::vector <double> atomic_densities;
        std::vector <double> isotopes_total_macro_cross_section;

        for (size_t j = 0; j < Formula.size(); j++) {
            if (i != j) {
                sum_molecule += Formula[j].first * Formula[j].second.Element_Mass;
            }
        }

        for (size_t j = 0; j < Isotopes.size(); j++) {
            isotopes_product *= Isotopes[j].Atomic_Mass;
        }

        for (size_t j = 0; j < Isotopes.size(); j++) {
            partial_products.push_back(isotopes_product * Isotopes[j].Mass_Percentage / Isotopes[j].Atomic_Mass);
            sum_products += partial_products[j];
        }

        for (size_t j = 0; j < Isotopes.size(); j++) {
            atomic_densities.push_back( (multiplication_factor * avogrado * partial_products[j] * Molecular_Density)
                                        / (multiplication_factor * isotopes_product + sum_molecule * sum_products) );

            isotopes_total_macro_cross_section.push_back( atomic_densities[j] * Isotopes[j].Total_Cross_Section );
            superior_limit += isotopes_total_macro_cross_section[j] / molecule_macroscopic_cross_section;
        }

        if (random_number < superior_limit) {
            return Formula[i].second;
        }
    }
}
