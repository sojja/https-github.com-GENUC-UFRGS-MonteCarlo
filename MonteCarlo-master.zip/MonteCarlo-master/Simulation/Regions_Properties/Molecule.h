#ifndef MOLECULE_H_INCLUDED
#define MOLECULE_H_INCLUDED

#include <vector>
#include <map>
#include "Element.h"
#include "Structs_header.h"

class molecule {

    private:

        double avogrado = 6.02214076E23;

    public:

        double Molecular_Density;

        double Molecular_Mass;

        std::vector < std::pair <double, element> > Formula;

        molecule ();

        molecule (double molecular_density, std::vector < std::pair <double, element> > formula);

        double Total_Macroscopic_Cross_Section ( neutron_struct Neutron
                                               , double         RandomEnergy
                                               , double         RandomAlpha
                                               , double         RandomBeta
                                               );

        element Element ( neutron_struct Neutron
                        , double         RandomEnergy
                        , double         RandomAlpha
                        , double         RandomBeta
                        , double random_number
                        );

};

#endif // MOLECULE_H_INCLUDED
