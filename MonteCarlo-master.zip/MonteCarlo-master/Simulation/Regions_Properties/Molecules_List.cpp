#include <vector>
#include <map>
#include "Element.h"
#include "Elements_List.h"
#include "Molecule.h"
#include "Molecules_List.h"

molecules::Init_mol() {

molecule molecules::Concrete_equivalent_molecule (2.0, std::vector < std::pair <double, element> > { {0.0079 / 0.9936, elements::H},
                                                                                                     {0.5338 / 0.9936, elements::O},
                                                                                                     {0.0156 / 0.9936, elements::Al},
                                                                                                     {0.3856 / 0.9936, elements::Si},
                                                                                                     {0.0013 / 0.9936, elements::S},
                                                                                                     {0.0427 / 0.9936, elements::Ca},
                                                                                                     {0.0067 / 0.9936, elements::Fe} } );

molecule molecules::Ca_equivalent_molecule (2.0, std::vector < std::pair <double, element> > { {1.0, elements::Ca} } );

molecule molecules::CaU_equivalent_molecule (2.0, std::vector < std::pair <double, element> > { {1, elements::Ca},
                                                                                                {1, elements::Fe} } );

molecule molecules::HeavyweightConcrete_equivalent_molecule (2.6, std::vector < std::pair <double, element> > { {0.0062 / 0.9966, elements::H},
                                                                                                                {0.3165 / 0.9966, elements::O},
                                                                                                                {0.0069 / 0.9966, elements::Al},
                                                                                                                {0.0295 / 0.9966, elements::Si},
                                                                                                                {0.1063 / 0.9966, elements::S},
                                                                                                                {0.0389 / 0.9966, elements::Ca},
                                                                                                                {0.0411 / 0.9966, elements::Fe},
                                                                                                                {0.4512 / 0.9966, elements::Ba} } );

molecule molecules::Iron_eq_molecule (7.84, std::vector < std::pair <double, element> > { {1.0, elements::Fe} } );
molecule Copper_eq_molecule (8.90, std::vector < std::pair <double, element> > { {1.0, Cu} } );
}
