#ifndef MOLECULES_LIST_H_INCLUDED
#define MOLECULES_LIST_H_INCLUDED

#include "Molecule.h"


namespace molecules {

    void Init_mol();

    extern molecule Concrete_equivalent_molecule;

    extern molecule Ca_equivalent_molecule;

    extern molecule CaU_equivalent_molecule;

    extern molecule HeavyweightConcrete_equivalent_molecule;

    extern molecule Iron_eq_molecule;
 extern molecule Copper_eq_molecule;
}

#endif // MOLECULES_LIST_H_INCLUDED
