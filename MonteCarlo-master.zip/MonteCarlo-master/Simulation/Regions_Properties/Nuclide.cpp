#include <string>
#include <map>
#include "Cross_Section_Functions_header.h"
#include "Nuclide.h"

#include "collision.h"
#include "Probability_Distributions_header.h"


bool operator < (const nuclide_id & lhs, const nuclide_id & rhs){
    if (lhs.Proton_Number < rhs.Proton_Number) return true;
    else return lhs.Mass_Number < rhs.Mass_Number;
}


nuclide::nuclide () {}


nuclide::nuclide (nuclide_id id, double mass, std::map <std::string, neutron_interaction> interactions) {

    Identifier   = id;
    Atomic_Mass  = mass;
    Interactions = interactions;

}


double nuclide::Total_Cross_Section ( neutron_struct Neutron
                                    , double         RandomEnergy
                                    , double         RandomAlpha
                                    , double         RandomBeta
                                    ) {

    double total_cross_section = 0.0;

        particle neutronP ( Neutron.energy, 1.0, {Neutron.direction.alpha, Neutron.direction.beta} );
        particle targetP  ( RandomEnergy, this->Atomic_Mass, {RandomAlpha, RandomBeta} );

        double CollisionEnergy = collision_energy ( neutronP, targetP );

    for (auto interaction : Interactions) {

        total_cross_section += interaction.second(CollisionEnergy/*Energy*/) * 1E-24;
    }

    return total_cross_section;
}


std::string nuclide::Interaction ( neutron_struct Neutron
                                 , double         RandomEnergy
                                 , double         RandomAlpha
                                 , double         RandomBeta
                                 , double random_number
                                 ) {

    double total_cross_section = Total_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta );

    double superior_limit = 0.0;

        particle neutronP ( Neutron.energy, 1.0, {Neutron.direction.alpha, Neutron.direction.beta} );
        particle targetP  ( RandomEnergy, this->Atomic_Mass, {RandomAlpha, RandomBeta} );

        double CollisionEnergy = collision_energy ( neutronP, targetP );

    for (auto interaction : Interactions) {
        superior_limit += interaction.second(CollisionEnergy/*Energy*/) * 1E-24 / total_cross_section;
        if (random_number < superior_limit){
            return interaction.first;
        }
    }
}
