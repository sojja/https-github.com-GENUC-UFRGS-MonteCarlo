#ifndef NUCLIDE_H_INCLUDED
#define NUCLIDE_H_INCLUDED

#include <string>
#include <map>
#include "Structs_header.h"

typedef double (*neutron_interaction)(double);


struct nuclide_id {

    unsigned int Proton_Number;
    unsigned int Mass_Number;

    nuclide_id () {}

    nuclide_id (unsigned int Z, unsigned int A) {
        Proton_Number = Z;
        Mass_Number   = A;
    }

};

bool operator < (const nuclide_id & lhs, const nuclide_id & rhs);

class nuclide {

    public:

        nuclide_id Identifier;

        double Atomic_Mass;

        std::map <std::string, neutron_interaction> Interactions;

        nuclide ();

        nuclide (nuclide_id id, double mass, std::map <std::string, neutron_interaction> interactions);

        double Total_Cross_Section ( neutron_struct Neutron
                                   , double         RandomEnergy
                                   , double         RandomAlpha
                                   , double         RandomBeta
                                   );

        std::string Interaction ( neutron_struct Neutron
                                , double         RandomEnergy
                                , double         RandomAlpha
                                , double         RandomBeta
                                , double random_number
                                );
};

#endif // NUCLIDE_H_INCLUDED
