#include <map>
#include <string>
#include "Cross_Section_Functions_header.h"
#include "Nuclide.h"
#include "Nuclides_List.h"

void nuclides::Init_nuc(){
nuclide nuclides::H1 (nuclide_id (1, 1), 1.00782503224,
                      std::map <std::string, neutron_interaction> {
                          {"Scattering", H_scattering_CS},
                          {"Capture", H_capture_CS}
                      } );

nuclide nuclides::C12 (nuclide_id (6, 12), 12,
                       std::map <std::string, neutron_interaction> {
                           {"Scattering", C12_scattering_CS},
                           {"Capture", C12_capture_CS}
                       } );

nuclide nuclides::O16 (nuclide_id (8, 16), 15.99491461960,
                       std::map <std::string, neutron_interaction> {
                           {"Scattering", O_scattering_CS},
                           {"Capture", O_capture_CS}
                       } );

nuclide nuclides::Mg24 (nuclide_id (12, 24), 23.985041697,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Mg24_scattering_CS},
                            {"Capture", Mg24_capture_CS}
                        } );

nuclide nuclides::Al27 (nuclide_id (13, 27), 26.98153841,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Al27_scattering_CS},
                            {"Capture", Al27_capture_CS}
                        } );

nuclide nuclides::Si28 (nuclide_id (14, 28), 27.9769265350,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Si28_scattering_CS},
                            {"Capture", Si28_capture_CS}
                        } );

nuclide nuclides::P31 (nuclide_id (15, 31), 30.9737619986,
                       std::map <std::string, neutron_interaction> {
                           {"Scattering", P31_scattering_CS},
                           {"Capture", P31_capture_CS}
                       } );

nuclide nuclides::S32 (nuclide_id (16, 32), 31.9720711744,
                       std::map <std::string, neutron_interaction> {
                           {"Scattering", S32_scattering_CS},
                           {"Capture", S32_capture_CS}
                       } );

nuclide nuclides::Ca40 (nuclide_id (20, 40), 39.96259098,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Ca40_scattering_CS},
                            {"Capture", Ca40_capture_CS}
                        } );

nuclide nuclides::Cr52 (nuclide_id (24, 52), 51.9405075,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Cr52_scattering_CS},
                            {"Capture", Cr52_capture_CS}
                        } );

nuclide nuclides::Mn55 (nuclide_id (25, 55), 55.9349363,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Cr52_scattering_CS},
                            {"Capture", Cr52_capture_CS}
                        } );

nuclide nuclides::Fe56 (nuclide_id (26, 56), 54.9380451,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Mn55_scattering_CS},
                            {"Capture", Mn55_capture_CS}
                        } );

nuclide nuclides::Ni58 (nuclide_id (28, 58), 57.9353429,
                        std::map <std::string, neutron_interaction> {
                            {"Scattering", Ni58_scattering_CS},
                            {"Capture", Ni58_capture_CS}
                        } );

nuclide nuclides::Ba138 (nuclide_id (56, 138),  	137.9052472,
                         std::map <std::string, neutron_interaction> {
                            {"Scattering", Ba138_scattering_CS},
                            {"Capture", Ba138_capture_CS}
                         } );
}
