#ifndef NUCLIDES_LIST_H_INCLUDED
#define NUCLIDES_LIST_H_INCLUDED

#include "Nuclide.h"

namespace nuclides {

    void Init_nuc();

    extern nuclide H1;

    extern nuclide C12;

    extern nuclide O16;

    extern nuclide Mg24;

    extern nuclide Al27;

    extern nuclide Si28;

    extern nuclide P31;

    extern nuclide S32;

    extern nuclide Ca40;

    extern nuclide Cr52;

    extern nuclide Mn55;

    extern nuclide Fe56;

    extern nuclide Ni58;

    extern nuclide Ba138;

}

#endif // NUCLIDES_LIST_H_INCLUDED
