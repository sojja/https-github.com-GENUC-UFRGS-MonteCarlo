#include <vector>
#include <map>
#include "Molecule.h"
#include "Region.h"


region::region () {}


region::region (std::vector < std::pair <molecule, double> > molecules) {
    Molecules = molecules;

    for (auto & m_molecule : Molecules) {
        m_molecule.first.Molecular_Density *= m_molecule.second;
    }
}


double region::Total_Macroscopic_Cross_Section ( neutron_struct Neutron
                                               , double         RandomEnergy
                                               , double         RandomAlpha
                                               , double         RandomBeta
                                               ) {

    double total_macroscopic_cross_section = 0.0;

    for (auto m_molecule : Molecules) {
        total_macroscopic_cross_section += m_molecule.first.Total_Macroscopic_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta );
    }

    return total_macroscopic_cross_section;
}


molecule region::Molecule ( neutron_struct Neutron
                          , double         RandomEnergy
                          , double         RandomAlpha
                          , double         RandomBeta
                          , double random_number
                          ) {

    double total_cross_section = Total_Macroscopic_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta );

    double superior_limit = 0.0;

    for (auto m_molecule : Molecules) {
        superior_limit += m_molecule.first.Total_Macroscopic_Cross_Section( Neutron, RandomEnergy, RandomAlpha, RandomBeta ) / total_cross_section;

        if (random_number < superior_limit) {
            return m_molecule.first;
        }
    }
}
