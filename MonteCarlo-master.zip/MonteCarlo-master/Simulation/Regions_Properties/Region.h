#ifndef REGION_H_INCLUDED
#define REGION_H_INCLUDED

#include <vector>
#include <map>
#include "Molecule.h"
#include "Structs_header.h"

class region {

    public:

        std::vector < std::pair <molecule, double> > Molecules;

        region ();

        region (std::vector < std::pair <molecule, double> > molecules);

        double Total_Macroscopic_Cross_Section ( neutron_struct Neutron
                                               , double         RandomEnergy
                                               , double         RandomAlpha
                                               , double         RandomBeta
                                               );

        molecule Molecule ( neutron_struct Neutron
                          , double         RandomEnergy
                          , double         RandomAlpha
                          , double         RandomBeta
                          , double random_number
                          );

};

#endif // REGION_H_INCLUDED
