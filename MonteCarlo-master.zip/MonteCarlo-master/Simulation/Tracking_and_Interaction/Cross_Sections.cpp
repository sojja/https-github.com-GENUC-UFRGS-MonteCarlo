#include <cmath>
#include "Structs_header.h"
#include "Properties_Structs_header.h"
#include "Cross_Section_Functions_header.h"


void microscopic_cross_section_function(cross_sections_struct& Cross_Section, double Energy){

    /* 1E-24 is a conversion factor, for the cross section is given in barns. */
    Cross_Section.H_capture        = H_capture_CS(Energy)        * 1E-24;
    Cross_Section.H_scattering     = H_scattering_CS(Energy)     * 1E-24;

    Cross_Section.O_capture        = O_capture_CS(Energy)        * 1E-24;
    Cross_Section.O_scattering     = O_scattering_CS(Energy)     * 1E-24;

    Cross_Section.U_235_capture    = U235_capture_CS(Energy)    * 1E-24;
    Cross_Section.U_235_scattering = U235_scattering_CS(Energy) * 1E-24;
    Cross_Section.U_235_fission    = U235_fission_CS(Energy)    * 1E-24;

    Cross_Section.U_238_capture    = U238_capture_CS(Energy)    * 1E-24;
    Cross_Section.U_238_scattering = U238_scattering_CS(Energy) * 1E-24;
    Cross_Section.U_238_fission    = U238_fission_CS(Energy)    * 1E-24;


    Cross_Section.H_total     = Cross_Section.H_capture + Cross_Section.H_scattering;

    Cross_Section.O_total     = Cross_Section.O_capture + Cross_Section.O_scattering;

    Cross_Section.U_235_total = Cross_Section.U_235_capture + Cross_Section.U_235_scattering + Cross_Section.U_235_fission;

    Cross_Section.U_238_total = Cross_Section.U_238_capture + Cross_Section.U_238_scattering + Cross_Section.U_238_fission;

}


void macroscopic_cross_section_function(region_properties_struct& Region, const cross_sections_struct& Cross_Section){

    /* Macroscopic cross sections of isotopes. */
    Region.Macro_CS.U_235_capture    = Region.U_235.Atomic_Density      * Cross_Section.U_235_capture;
    Region.Macro_CS.U_235_fission    = Region.U_235.Atomic_Density      * Cross_Section.U_235_fission;
    Region.Macro_CS.U_235_scattering = Region.U_235.Atomic_Density      * Cross_Section.U_235_scattering;
    Region.Macro_CS.U_235_total      = Region.U_235.Atomic_Density      * Cross_Section.U_235_total;

    Region.Macro_CS.U_238_capture    = Region.U_238.Atomic_Density      * Cross_Section.U_238_capture;
    Region.Macro_CS.U_238_fission    = Region.U_238.Atomic_Density      * Cross_Section.U_238_fission;
    Region.Macro_CS.U_238_scattering = Region.U_238.Atomic_Density      * Cross_Section.U_238_scattering;
    Region.Macro_CS.U_238_total      = Region.U_238.Atomic_Density      * Cross_Section.U_238_total;

    Region.Macro_CS.U_capture        = Region.Macro_CS.U_235_capture    + Region.Macro_CS.U_238_capture;
    Region.Macro_CS.U_fission        = Region.Macro_CS.U_235_fission    + Region.Macro_CS.U_238_fission;
    Region.Macro_CS.U_scattering     = Region.Macro_CS.U_235_scattering + Region.Macro_CS.U_238_scattering;
    Region.Macro_CS.U_total          = Region.Macro_CS.U_235_total      + Region.Macro_CS.U_238_total;


    Region.Macro_CS.O_UO2_235_capture    = Region.O_UO2_235.Atomic_Density      * Cross_Section.O_capture;
    Region.Macro_CS.O_UO2_235_scattering = Region.O_UO2_235.Atomic_Density      * Cross_Section.O_scattering;
    Region.Macro_CS.O_UO2_235_total      = Region.O_UO2_235.Atomic_Density      * Cross_Section.O_total;

    Region.Macro_CS.O_UO2_238_capture    = Region.O_UO2_238.Atomic_Density      * Cross_Section.O_capture;
    Region.Macro_CS.O_UO2_238_scattering = Region.O_UO2_238.Atomic_Density      * Cross_Section.O_scattering;
    Region.Macro_CS.O_UO2_238_total      = Region.O_UO2_238.Atomic_Density      * Cross_Section.O_total;

    Region.Macro_CS.O_UO2_capture        = Region.Macro_CS.O_UO2_235_capture    + Region.Macro_CS.O_UO2_238_capture;
    Region.Macro_CS.O_UO2_scattering     = Region.Macro_CS.O_UO2_235_scattering + Region.Macro_CS.O_UO2_238_scattering;
    Region.Macro_CS.O_UO2_total          = Region.Macro_CS.O_UO2_235_total      + Region.Macro_CS.O_UO2_238_total;


    Region.Macro_CS.H_capture    = Region.H.Atomic_Density * Cross_Section.H_capture;
    Region.Macro_CS.H_scattering = Region.H.Atomic_Density * Cross_Section.H_scattering;
    Region.Macro_CS.H_total      = Region.H.Atomic_Density * Cross_Section.H_total;


    Region.Macro_CS.O_H2O_capture    = Region.O_H2O.Atomic_Density * Cross_Section.O_capture;
    Region.Macro_CS.O_H2O_scattering = Region.O_H2O.Atomic_Density * Cross_Section.O_scattering;
    Region.Macro_CS.O_H2O_total      = Region.O_H2O.Atomic_Density * Cross_Section.O_total;


    /* Macroscopic cross sections of molecules. */
    Region.Macro_CS.UO2_capture        = Region.Macro_CS.U_capture        + Region.Macro_CS.O_UO2_capture;
    Region.Macro_CS.UO2_fission        = Region.Macro_CS.U_fission;
    Region.Macro_CS.UO2_scattering     = Region.Macro_CS.U_scattering     + Region.Macro_CS.O_UO2_scattering;
    Region.Macro_CS.UO2_total          = Region.Macro_CS.U_total          + Region.Macro_CS.O_UO2_total;

    Region.Macro_CS.UO2_235_capture    = Region.Macro_CS.U_235_capture    + Region.Macro_CS.O_UO2_235_capture;
    Region.Macro_CS.UO2_235_fission    = Region.Macro_CS.U_235_fission;
    Region.Macro_CS.UO2_235_scattering = Region.Macro_CS.U_235_scattering + Region.Macro_CS.O_UO2_235_scattering;
    Region.Macro_CS.UO2_235_total      = Region.Macro_CS.U_235_total      + Region.Macro_CS.O_UO2_235_total;

    Region.Macro_CS.UO2_238_capture    = Region.Macro_CS.U_238_capture    + Region.Macro_CS.O_UO2_238_capture;
    Region.Macro_CS.UO2_238_fission    = Region.Macro_CS.U_238_fission;
    Region.Macro_CS.UO2_238_scattering = Region.Macro_CS.U_238_scattering + Region.Macro_CS.O_UO2_238_scattering;
    Region.Macro_CS.UO2_238_total      = Region.Macro_CS.U_238_total      + Region.Macro_CS.O_UO2_238_total;


    Region.Macro_CS.H2O_capture    = Region.Macro_CS.H_capture    + Region.Macro_CS.O_H2O_capture;
    Region.Macro_CS.H2O_scattering = Region.Macro_CS.H_scattering + Region.Macro_CS.O_H2O_scattering;
    Region.Macro_CS.H2O_total      = Region.Macro_CS.H_total      + Region.Macro_CS.O_H2O_total;


    /* Total mixture macroscopic cross sections. */
    Region.Mixture_Total_Macro_CS = Region.Macro_CS.UO2_total + Region.Macro_CS.H2O_total;

}
