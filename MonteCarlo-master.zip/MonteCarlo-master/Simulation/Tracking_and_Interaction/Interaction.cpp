#include "Structs_header.h"
#include "Properties_Structs_header.h"
#include "multithread_MT64.h"
#include "Nuclide.h"
#include "Element.h"
#include "Tracking_and_Interaction_header.h"

void interaction_roulette( interaction_type_struct & Interaction,
                           isotope_type_struct & Isotope,
                           const region_properties_struct & Region,
                           multithread_mt64 & mt64 ){

    Interaction.reset_bool_values();
    Isotope.reset_bool_values();

    double rnd_molecule;
    double rnd_isotope;
    double rnd_interaction;

    rnd_molecule    = mt64.genRand_real2();
    rnd_isotope     = mt64.genRand_real2();
    rnd_interaction = mt64.genRand_real2();

    if( rnd_molecule < (Region.Macro_CS.UO2_235_total / Region.Mixture_Total_Macro_CS) ){
    // interaction with UO2_235 molecule

        if( rnd_isotope < (Region.Macro_CS.U_235_total / Region.Macro_CS.UO2_235_total) ){
        // interaction with U_235 isotope
            Isotope.U_235 = true;

            if( rnd_interaction < ( Region.Macro_CS.U_235_capture / Region.Macro_CS.U_235_total) ){
            // capture in U_235
                Interaction.capture = true;
            }

            else if( rnd_interaction < ( (Region.Macro_CS.U_235_capture + Region.Macro_CS.U_235_fission) / Region.Macro_CS.U_235_total ) ){
            // fission in U_235
                Interaction.fission = true;
            }

            else{
            // scattering in U_235
                Interaction.scattering = true;
            }
        }// end of interaction with U_235 isotope IF

        else{
        // interaction with O_UO2_U235 isotope
        Isotope.O_UO2_235 = true;

            if( rnd_interaction < (Region.Macro_CS.O_UO2_235_capture / Region.Macro_CS.O_UO2_235_total) ){
            // capture in O_UO2_235
                Interaction.capture = true;
            }

            else{
            // scattering in O_UO2_235
                Interaction.scattering = true;
            }
        }// end of interaction with O_UO2_U235 isotope IF
    }// end of interaction with UO2_235 molecule IF


    else if( rnd_molecule < ( (Region.Macro_CS.UO2_235_total + Region.Macro_CS.UO2_238_total) / Region.Mixture_Total_Macro_CS) ){
    // interaction with UO2_238 molecule

        if( rnd_isotope < (Region.Macro_CS.U_238_total / Region.Macro_CS.UO2_238_total) ){
        // interaction with U_238 isotope
            Isotope.U_238 = true;

            if( rnd_interaction < ( Region.Macro_CS.U_238_capture / Region.Macro_CS.U_238_total) ){
            // capture in U_238
                Interaction.capture = true;
            }

            else if( rnd_interaction < ( (Region.Macro_CS.U_238_capture + Region.Macro_CS.U_238_fission) / Region.Macro_CS.U_238_total ) ){
            // fission in U_238
                Interaction.fission = true;
            }

            else{
            // scattering in U_238
                Interaction.scattering = true;
            }
        }// end of interaction with U_238 isotope IF

        else{
        //interaction with O_UO2_U238 isotope
        Isotope.O_UO2_238 = true;

            if( rnd_interaction < (Region.Macro_CS.O_UO2_238_capture / Region.Macro_CS.O_UO2_238_total) ){
            // capture in O_UO2_238
                Interaction.capture = true;
            }

            else{
            // scattering in O_UO2_238
                Interaction.scattering = true;
            }
        }// end of interaction with O_UO2_U238 isotope IF
    }// end of interaction with UO2_238 molecule IF


    else{
    // interaction with H2O molecule

        if( rnd_isotope < (Region.Macro_CS.H_total / Region.Macro_CS.H2O_total) ){
        // interaction with H isotope
            Isotope.H = true;

            if( rnd_interaction < (Region.Macro_CS.H_capture / Region.Macro_CS.H_total) ){
            // capture in H
                Interaction.capture = true;
            }

            else{
            // scattering in H
                Interaction.scattering = true;
            }
        }// end of interaction with H isotope IF

        else{
        //interaction with O_H2O isotope
            Isotope.O_H2O = true;

            if( rnd_interaction < (Region.Macro_CS.O_H2O_capture / Region.Macro_CS.O_H2O_total) ){
            // capture in O_H2O
                Interaction.capture = true;
            }

            else{
            // scattering in O_H2O
                Interaction.scattering = true;
            }
        }// end of interaction with O_H2O isotope IF
    }// end of interaction with H2O molecule IF
}


interaction interaction_roulette( region Region
                                , neutron_struct Neutron
                                , double         RandomEnergy
                                , double         RandomAlpha
                                , double         RandomBeta
                                , multithread_mt64 & mt64
                                ) {

    interaction Interaction;

    double rnd_molecule;
    double rnd_element;
    double rnd_isotope;
    double rnd_reaction;

    rnd_molecule    = mt64.genRand_real2();
    rnd_element     = mt64.genRand_real2();
    rnd_isotope     = mt64.genRand_real2();
    rnd_reaction    = mt64.genRand_real2();

    molecule Molecule    = Region  .Molecule   ( Neutron, RandomEnergy, RandomAlpha, RandomBeta, rnd_molecule );
    element  Element     = Molecule.Element    ( Neutron, RandomEnergy, RandomAlpha, RandomBeta, rnd_element  );
    nuclide  Nuclide     = Element .Isotope    ( Neutron, RandomEnergy, RandomAlpha, RandomBeta, rnd_isotope  );
    Interaction.Reaction = Nuclide .Interaction( Neutron, RandomEnergy, RandomAlpha, RandomBeta, rnd_reaction );

    Interaction.Nuclide_Mass  = Nuclide .Atomic_Mass;
    Interaction.Molecule_Mass = Molecule.Molecular_Mass;

    return Interaction;
}
