#include <cmath>
#include "Structs_header.h"
#include "multithread_MT64.h"

void new_direction( neutron_struct & Neutron, collision_struct & Collision, multithread_mt64 & mt64 ){

    double Phi;
    double f1, f2, f3;
    double new_alpha, new_beta;
    double aux;

    if(Collision.psi < 1E-5){
        new_alpha = Neutron.direction.alpha;
        new_beta  = Neutron.direction.beta;
    }

    else if(Collision.psi > (M_PI-1E-5)){
        new_alpha = Neutron.direction.alpha + M_PI;
        new_beta  = -Neutron.direction.beta;
    }

    else{
        Phi = 2.0 * M_PI * ( mt64.genRand_real1() );

        f1 = std::cos(Collision.psi) * std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta) +
         std::sin(Collision.psi) * (0.5 * std::cos(Phi) * 1.4142135623730951 * (((std::cos(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta + Collision.psi) - std::cos(Collision.psi) * std::cos(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta)) + std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta) *
         std::sin(Neutron.direction.beta + Collision.psi)) - std::sin(Neutron.direction.beta) * std::sin(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta + Collision.psi)) / std::sin(Collision.psi) - 0.5 * std::sin(Phi) * 1.4142135623730951 *
         (((-std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta + Collision.psi) + std::cos(Collision.psi) *
         std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta)) + std::sin(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta) * std::sin(Neutron.direction.beta + Collision.psi)) - std::sin(Neutron.direction.beta) *
         std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta + Collision.psi)) / std::sin(Collision.psi));

        f2 = std::cos(Collision.psi) * std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta) +
         std::sin(Collision.psi) * (-0.5 * std::cos(Phi) * 1.4142135623730951 * (((-std::sin(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta + Collision.psi) + std::cos(Collision.psi) * std::sin(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta)) - std::sin(Neutron.direction.beta) * std::cos(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta + Collision.psi)) + std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta) *
         std::sin(Neutron.direction.beta + Collision.psi)) / std::sin(Collision.psi) - 0.5 * std::sin(Phi) * 1.4142135623730951 *
         (((-std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta + Collision.psi) + std::cos(Collision.psi) *
         std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta)) + std::sin(Neutron.direction.beta) *
         std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta + Collision.psi)) - std::cos(Neutron.direction.alpha) *
         std::cos(Neutron.direction.beta) * std::sin(Neutron.direction.beta + Collision.psi)) / std::sin(Collision.psi));

        f3 = std::cos(Collision.psi) * std::sin(Neutron.direction.beta) + std::sin(Collision.psi) * (0.5 * std::cos(Phi) *
         1.4142135623730951 * (std::sin(Neutron.direction.beta + Collision.psi) - std::cos(Collision.psi) *
         std::sin(Neutron.direction.beta)) / std::sin(Collision.psi) + 0.5 * std::sin(Phi) * 1.4142135623730951 *
         (std::sin(Neutron.direction.beta + Collision.psi) - std::cos(Collision.psi) *
         std::sin(Neutron.direction.beta)) / std::sin(Collision.psi));

        new_beta = std::asin(f3);
        aux = f1 / std::cos(new_beta);
        if(aux >= 1){aux = 1;}
        else if(aux <= -1){aux = -1;}
        new_alpha = std::acos(aux);
        if(f2 < 0){new_alpha = 2 * M_PI - new_alpha;}

    }

    if( new_alpha >= (2.0 * M_PI) ){ new_alpha -= 2.0 * M_PI; }

    Neutron.direction.alpha = new_alpha;
    Neutron.direction.beta  = new_beta;
}


void CM_to_Lab_CoordSystem_function(collision_struct& Collision, double MassNumber){
    if(Collision.theta + 1.1E-8 >= M_PI){Collision.theta -= 1.1E-8;}

    Collision.psi = std::acos( (MassNumber * std::cos(Collision.theta) + 1.0) /
     std::sqrt(MassNumber * MassNumber + 2.0 * MassNumber * std::cos(Collision.theta) + 1.0) );
}
