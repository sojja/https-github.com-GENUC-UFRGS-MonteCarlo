#ifndef PROPERTIES_STRUCTS_HEADER_H_INCLUDED
#define PROPERTIES_STRUCTS_HEADER_H_INCLUDED

struct cross_sections_struct{
    double U_235_capture;
    double U_235_fission;
    double U_235_scattering;
    double U_235_total;
    double U_238_capture;
    double U_238_fission;
    double U_238_scattering;
    double U_238_total;
    double H_capture;
    double H_scattering;
    double H_total;
    double O_capture;
    double O_scattering;
    double O_total;

    cross_sections_struct(){
        U_235_capture    = 0.0;
        U_235_fission    = 0.0;
        U_235_scattering = 0.0;
        U_235_total      = 0.0;
        U_238_capture    = 0.0;
        U_238_fission    = 0.0;
        U_238_scattering = 0.0;
        U_238_total      = 0.0;
        H_capture        = 0.0;
        H_scattering     = 0.0;
        H_total          = 0.0;
        O_capture        = 0.0;
        O_scattering     = 0.0;
        O_total          = 0.0;
    }
};


struct macroscopic_cross_section_struct{
    double U_capture;
    double U_fission;
    double U_scattering;
    double U_total;
    double U_235_capture;
    double U_235_fission;
    double U_235_scattering;
    double U_235_total;
    double U_238_capture;
    double U_238_fission;
    double U_238_scattering;
    double U_238_total;

    double H_capture;
    double H_scattering;
    double H_total;

    double O_UO2_capture;
    double O_UO2_scattering;
    double O_UO2_total;
    double O_UO2_235_capture;
    double O_UO2_235_scattering;
    double O_UO2_235_total;
    double O_UO2_238_capture;
    double O_UO2_238_scattering;
    double O_UO2_238_total;

    double O_H2O_capture;
    double O_H2O_scattering;
    double O_H2O_total;


    double UO2_capture;
    double UO2_fission;
    double UO2_scattering;
    double UO2_total;
    double UO2_235_capture;
    double UO2_235_fission;
    double UO2_235_scattering;
    double UO2_235_total;
    double UO2_238_capture;
    double UO2_238_fission;
    double UO2_238_scattering;
    double UO2_238_total;
    double H2O_capture;
    double H2O_scattering;
    double H2O_total;

    macroscopic_cross_section_struct(){
        U_capture            = 0.0;
        U_fission            = 0.0;
        U_scattering         = 0.0;
        U_total              = 0.0;
        U_235_capture        = 0.0;
        U_235_fission        = 0.0;
        U_235_scattering     = 0.0;
        U_235_total          = 0.0;
        U_238_capture        = 0.0;
        U_238_fission        = 0.0;
        U_238_scattering     = 0.0;
        U_238_total          = 0.0;

        H_capture            = 0.0;
        H_scattering         = 0.0;
        H_total              = 0.0;

        O_UO2_capture        = 0.0;
        O_UO2_scattering     = 0.0;
        O_UO2_total          = 0.0;
        O_UO2_235_capture    = 0.0;
        O_UO2_235_scattering = 0.0;
        O_UO2_235_total      = 0.0;
        O_UO2_238_capture    = 0.0;
        O_UO2_238_scattering = 0.0;
        O_UO2_238_total      = 0.0;

        O_H2O_capture        = 0.0;
        O_H2O_scattering     = 0.0;
        O_H2O_total          = 0.0;


        UO2_capture          = 0.0;
        UO2_fission          = 0.0;
        UO2_scattering       = 0.0;
        UO2_total            = 0.0;
        UO2_235_capture      = 0.0;
        UO2_235_fission      = 0.0;
        UO2_235_scattering   = 0.0;
        UO2_235_total        = 0.0;
        UO2_238_capture      = 0.0;
        UO2_238_fission      = 0.0;
        UO2_238_scattering   = 0.0;
        UO2_238_total        = 0.0;
        H2O_capture          = 0.0;
        H2O_scattering       = 0.0;
        H2O_total            = 0.0;
    }
};


struct atomic_properties_struct{
    double Atomic_Mass;// g/mol
    double Atomic_Density;// atoms/cm^3

    atomic_properties_struct(){
        Atomic_Mass    = 0.0;
        Atomic_Density = 0.0;
    }
};


struct molecular_properties_struct{
    double Molecular_Mass;// g/mol
    double Molecular_Density;// molecules/cm^3

    molecular_properties_struct(){
        Molecular_Mass    = 0.0;
        Molecular_Density = 0.0;
    }
};


struct region_properties_struct{
    double Water_Volumetric_Proportion;
    double Enrichment;

    atomic_properties_struct U;
    atomic_properties_struct U_235;
    atomic_properties_struct U_238;

    atomic_properties_struct O_UO2;
    atomic_properties_struct O_UO2_235;
    atomic_properties_struct O_UO2_238;
    atomic_properties_struct O_H2O;

    atomic_properties_struct H;


    molecular_properties_struct UO2;
    molecular_properties_struct UO2_235;
    molecular_properties_struct UO2_238;
    molecular_properties_struct H2O;

    macroscopic_cross_section_struct Macro_CS;

    double Mixture_Total_Macro_CS;


    region_properties_struct(){
        Water_Volumetric_Proportion = 0.0;
        Enrichment                  = 0.0;

        Mixture_Total_Macro_CS      = 0.0;
    }


    region_properties_struct(double water_v_prop, double enrich){
        Mixture_Total_Macro_CS      = 0.0;
        Water_Volumetric_Proportion = water_v_prop;
        Enrichment                  = enrich;

        double U_Density;// g/cm^3
        double UO2_Density = 10.5;// g/cm^3
        double H2O_Density = 1.0;// g/cm^3
        double Avogrado_Number = 6.022E23;// atoms/mol


        /* Atomic and molecular masses definitions. */
        U_235.Atomic_Mass     = 235.04392;
        U_238.Atomic_Mass     = 238.05078;
        O_UO2.Atomic_Mass     = 16.0;
        O_UO2_235.Atomic_Mass = 16.0;
        O_UO2_238.Atomic_Mass = 16.0;
        O_H2O.Atomic_Mass     = 16.0;
        H.Atomic_Mass         = 1.0;

        U.Atomic_Mass         = 1.0 / ( (Enrichment / U_235.Atomic_Mass) + ( (1.0 - Enrichment) / U_238.Atomic_Mass ) );


        UO2.Molecular_Mass     = U.Atomic_Mass     + 2.0 * O_UO2.Atomic_Mass;
        UO2_235.Molecular_Mass = U_235.Atomic_Mass + 2.0 * O_UO2_235.Atomic_Mass;
        UO2_238.Molecular_Mass = U_238.Atomic_Mass + 2.0 * O_UO2_238.Atomic_Mass;
        H2O.Molecular_Mass     = 2.0 * H.Atomic_Mass + O_H2O.Atomic_Mass;

        /* U_235 and U_239 atomic densities definitions. */
        U_Density = UO2_Density * (U.Atomic_Mass / UO2.Molecular_Mass);

        U_235.Atomic_Density = Enrichment * U_Density * Avogrado_Number / U_235.Atomic_Mass;
        U_238.Atomic_Density = (1.0 - Enrichment) * U_Density * Avogrado_Number / U_238.Atomic_Mass;

        /* Molecular density of water. */
        H2O.Molecular_Density = H2O_Density * Avogrado_Number / H2O.Molecular_Mass;


        /* Correction of atomic and molecular densities for homogeneous mixture. */
        U_235.Atomic_Density *= (1 - Water_Volumetric_Proportion);
        U_238.Atomic_Density *= (1 - Water_Volumetric_Proportion);

        H2O.Molecular_Density *= Water_Volumetric_Proportion;


        /* Atomic and molecular densities derived from previous ones. */
        U.Atomic_Density = U_235.Atomic_Density + U_238.Atomic_Density;

        UO2.Molecular_Density     = U.Atomic_Density;
        UO2_235.Molecular_Density = U_235.Atomic_Density;
        UO2_238.Molecular_Density = U_238.Atomic_Density;

        O_UO2.Atomic_Density     = 2.0 * UO2.Molecular_Density;
        O_UO2_235.Atomic_Density = 2.0 * UO2_235.Molecular_Density;
        O_UO2_238.Atomic_Density = 2.0 * UO2_238.Molecular_Density;


        H.Atomic_Density     = 2.0 * H2O.Molecular_Density;
        O_H2O.Atomic_Density = H2O.Molecular_Density;
    }
};

#endif // PROPERTIES_STRUCTS_HEADER_H_INCLUDED
