#include <iostream>
#include <Eigen/Dense>
#include "transformations.hpp"
#include "particles.hpp"

double cm_energy ( particleInPlane neutron
                 , particleInPlane target
                 ) {

    Eigen::Vector2d CM;

    CM = (neutron.Mass * neutron.Velocity + target.Mass * target.Velocity) / (neutron.Mass + target.Mass);

    neutron.Velocity -= CM;
    target .Velocity -= CM;

    neutron.Energy = S2E(neutron.Velocity.norm(), neutron.Mass);
    target .Energy = S2E(target .Velocity.norm(), target .Mass);

    return neutron.Energy + target.Energy;
}


double collision_energy ( particle neutron
                        , particle target
                        ) {

    neutron.Velocity -= target.Velocity;
    std::tie(neutron.Energy, neutron.Direction) = V2E(neutron.Velocity, neutron.Mass);

    return neutron.Energy;
}
