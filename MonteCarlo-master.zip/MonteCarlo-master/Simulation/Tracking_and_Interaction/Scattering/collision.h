#ifndef COLLISION_H
#define COLLISION_H

#include "particles.hpp"


double cm_energy ( particleInPlane neutron
                 , particleInPlane target
                 );


double collision_energy ( particle neutron
                        , particle target
                        );

#endif // COLLISION_H
