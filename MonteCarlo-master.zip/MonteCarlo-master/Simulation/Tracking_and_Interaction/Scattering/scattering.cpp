#include <iostream>
#include <Eigen/Dense>
#include "transformations.hpp"
#include "particles.hpp"

void scattering_kernel ( particleInPlane & neutron
                       , particleInPlane & target
                       , double theta
                       ) {

    double neutron_energy, target_energy;
    Eigen::Vector2d CM, neutron_direction, target_direction;

    CM = (neutron.Mass * neutron.Velocity + target.Mass * target.Velocity) / (neutron.Mass + target.Mass);

    neutron.Velocity -= CM;
    target .Velocity -= CM;

    neutron.Energy = S2E(neutron.Velocity.norm(), neutron.Mass);
    target .Energy = S2E(target .Velocity.norm(), target .Mass);
    neutron.CollisionEnergy = neutron.Energy;
    target .CollisionEnergy = target .Energy;

    neutron_energy = ( neutron.Energy + target.Energy ) * target .Mass / (neutron.Mass + target.Mass);
    target_energy  = ( neutron.Energy + target.Energy ) * neutron.Mass / (neutron.Mass + target.Mass);

    Eigen::Rotation2Dd Rotation(theta);

    neutron_direction  = Rotation * neutron.Velocity;
    neutron_direction /= neutron_direction.norm();

    target_direction  = Rotation * target.Velocity;
    target_direction /= target_direction.norm();

    neutron.Velocity = ( E2S(neutron_energy, neutron.Mass) * neutron_direction ) + CM;
    target .Velocity = ( E2S(target_energy, target.Mass)   * target_direction  ) + CM;

    neutron.Energy = S2E(neutron.Velocity.norm(), neutron.Mass);
    target .Energy = S2E(target .Velocity.norm(), target .Mass);
}


void scattering ( particle & neutron
                , particle & target
                , double theta
                ) {

    Eigen::Vector3d plane, abscissa, ordinate;

    plane = neutron.Velocity.cross( target.Velocity );

//    std::cout << "  plane: [" << plane.transpose() << "];\n";

    ordinate = plane.cross( neutron.Velocity );
    abscissa = ordinate.cross( plane );

    ordinate /= ordinate.norm();
    abscissa /= abscissa.norm();

//    std::cout << "  abscissa: [" << abscissa.transpose() << "]; Norm = " << abscissa.norm() << "\n";
//    std::cout << "  ordinate: [" << ordinate.transpose() << "]; Norm = " << ordinate.norm() << "\n";

    Eigen::Vector2d neutron_projection, target_projection;
    neutron_projection << neutron.Velocity.dot( abscissa ), neutron.Velocity.dot( ordinate );
    target_projection  << target .Velocity.dot( abscissa ), target .Velocity.dot( ordinate );

//    std::cout << "  neutron_projection: [" << neutron_projection.transpose() << "]; Norm = " << neutron_projection.norm() << "\n";
//    std::cout << "  target_projection: [" << target_projection.transpose() << "]; Norm = " << target_projection.norm() << "\n";

    particleInPlane neutronInPlane (neutron_projection, neutron.Mass);
    particleInPlane targetInPlane  (target_projection, target.Mass);

//    std::cout << "  neutronInPlane: [" << neutronInPlane.Velocity.transpose() << "]; Norm = " << neutronInPlane.Velocity.norm() << "\n";
//    std::cout << "  targetInPlane: [" << targetInPlane.Velocity.transpose() << "]; Norm = " << targetInPlane.Velocity.norm() << "\n";

    scattering_kernel (neutronInPlane, targetInPlane, theta);

    neutron.Velocity = neutronInPlane.Velocity(0) * abscissa + neutronInPlane.Velocity(1) * ordinate;
    target .Velocity = targetInPlane .Velocity(0) * abscissa + targetInPlane .Velocity(1) * ordinate;

    neutron.CollisionEnergy = neutronInPlane.CollisionEnergy;
    target .CollisionEnergy = targetInPlane .CollisionEnergy;

    std::tie(neutron.Energy, neutron.Direction) = V2E(neutron.Velocity, neutron.Mass);
    std::tie(target .Energy, target .Direction) = V2E(target .Velocity, target .Mass);
}
