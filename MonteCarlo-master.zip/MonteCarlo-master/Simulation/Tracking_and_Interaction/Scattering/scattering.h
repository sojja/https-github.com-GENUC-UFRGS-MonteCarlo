#ifndef SCATTERING_H
#define SCATTERING_H

#include "particles.hpp"

void scattering_kernel ( particleInPlane & neutron
                       , particleInPlane & target
                       , double theta
                       );


void scattering ( particle & neutron
                , particle & target
                , double theta
                );

#endif // SCATTERING_H
