#ifndef STRUCTS_HEADER_H_INCLUDED
#define STRUCTS_HEADER_H_INCLUDED

#include <vector>

struct direction_struct{
    double alpha;
    double beta;

    direction_struct(){
        alpha = 0;
        beta  = 0;
    }
};


struct collision_struct{
    double theta;
    double psi;

    collision_struct(){
        theta = 0;
        psi   = 0;
    }
};


struct position_struct{
    double x;
    double y;
    double z;

    position_struct(){
        x = 0;
        y = 0;
        z = 0;
    }
};


struct time_struct{
    double step;
    double life;
    double chain;

    time_struct(){
        step  = 0;
        life  = 0;
        chain = 0;
    }
};


struct birth_struct{
    double energy;
    position_struct position;
    unsigned int step;

    birth_struct(){
        energy = 0;
        step   = 0;
    }
};


struct neutron_struct{
    double energy;
    unsigned short int distribution;
    unsigned int step;
    unsigned int local_step;
    unsigned int generation;
    position_struct sos_position;
    position_struct eos_position;
    direction_struct direction;
    birth_struct birth;
    time_struct time;
    unsigned int step_life;
    double step_length;
    double last_scattering_before_thermal;
    double isotope_of_last_interaction;
    double largest_R;
    bool Absorbed;
    bool Escaped;

    neutron_struct(){
        energy                         = 0;
        distribution                   = 0;
        step                           = 0;
        local_step                     = 0;
        generation                     = 0;
        step_life                      = 0;
        step_length                    = 0;
        last_scattering_before_thermal = 0;
        isotope_of_last_interaction    = 0;
        largest_R = 0;
        Absorbed = false;
        Escaped  = false;
    }
};


struct fission_struct{
    unsigned short int multiplicity;
    neutron_struct neutron;

    fission_struct(){
        multiplicity = 0;
    }
};


struct generation_struct{
    std::vector <unsigned int> opening;
    std::vector <unsigned int> closure;
    std::vector <unsigned int> fisson_closure;
    std::vector <unsigned int> total_steps;
    std::vector <unsigned int> fission_total_steps;

    generation_struct(unsigned int VectorSize){
        opening            .assign(VectorSize, 0);
        closure            .assign(VectorSize, 0);
        fisson_closure     .assign(VectorSize, 0);
        total_steps        .assign(VectorSize, 0);
        fission_total_steps.assign(VectorSize, 0);
    }
};


struct thermalisation_struct{
    double energy_before_scattering;
    double energy_after_scattering;
    double last_scattering_before_thermal;
};


struct rectangular_geometry_struct{
    double X1;
    double X2;
    double X3;
    double Y1;
    double Y2;
    double Y3;
    double Z;

    double R1;
    double R2;
    double R3;
    double R4;
    double R5;
    double R6;
};


struct region_total_macroscopic_cross_sections_struct{
    double Region1;
    double Region2;
    double Region3;
};


struct isotope_type_struct{
    bool U_235;
    bool U_238;
    bool O_UO2_235;
    bool O_UO2_238;
    bool H;
    bool O_H2O;

    isotope_type_struct(){
        U_235     = false;
        U_238     = false;
        O_UO2_235 = false;
        O_UO2_238 = false;
        H         = false;
        O_H2O     = false;
    }

    void reset_bool_values(){
        U_235     = false;
        U_238     = false;
        O_UO2_235 = false;
        O_UO2_238 = false;
        H         = false;
        O_H2O     = false;
    }
};


struct interaction_type_struct{
    bool capture;
    bool scattering;
    bool fission;

    interaction_type_struct(){
        capture    = false;
        scattering = false;
        fission    = false;
    }

    void reset_bool_values(){
        capture    = false;
        scattering = false;
        fission    = false;
    }
};

#endif // STRUCTS_HEADER_H_INCLUDED
