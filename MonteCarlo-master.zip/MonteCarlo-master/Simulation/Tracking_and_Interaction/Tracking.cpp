#include <cmath>
#include <limits>
#include <vector>
#include <algorithm>
#include "Structs_header.h"
#include "multithread_MT64.h"

unsigned short int check_region(const position_struct& Position, const rectangular_geometry_struct& Geometry){
//    if( (fabs(Position.x) < Geometry.X1) &&
//        (fabs(Position.y) < Geometry.Y1) &&
//        (fabs(Position.z) < Geometry.Z)
//       ) {return 1;}
//
//    else if( (fabs(Position.x) < Geometry.X2) &&
//             (fabs(Position.y < Geometry.Y2)) &&
//             (fabs(Position.z) < Geometry.Z)  &&
//             ((fabs(Position.x >= Geometry.X1)) || (fabs(Position.y) >= Geometry.Y1))
//           ) {return 2;}
//
//    else if( (fabs(Position.x) < Geometry.X3) &&
//             (fabs(Position.y < Geometry.Y3)) &&
//             (fabs(Position.z) < Geometry.Z)  &&
//            ((fabs(Position.x >= Geometry.X2)) || (fabs(Position.y) >= Geometry.Y2))
//           ) {return 3;}

    if( (fabs(Position.x) < Geometry.X1) &&
        (fabs(Position.y) < Geometry.Y1) &&
        (fabs(Position.z) < Geometry.Z)
      ) {return 1;}
    else {return 4;}
//    return 1;
//    if (Position.z >= 0) return 1;
//    else return 4;
}

double radial_position (const position_struct& Position) {
    return std::sqrt( std::pow( Position.x, 2.0) +
                      std::pow( Position.y, 2.0) +
                      std::pow( Position.z, 2.0) );
}

//unsigned short int check_region(const position_struct& Position, const rectangular_geometry_struct& Geometry){
//    if( radial_position(Position) <= Geometry.R1 ) return 1;
//
//    else if( (radial_position(Position) > Geometry.R1) && (radial_position(Position) <= Geometry.R2) ) return 2;
//
//    else if( (radial_position(Position) > Geometry.R2) && (radial_position(Position) <= Geometry.R3) ) return 3;
//
////    else if( (radial_position(Position) > Geometry.R3) && (radial_position(Position) <= Geometry.R4) ) return 4;
////
////    else if( (radial_position(Position) > Geometry.R4) && (radial_position(Position) <= Geometry.R5) ) return 5;
////
////    else if( (radial_position(Position) > Geometry.R5) && (radial_position(Position) <= Geometry.R6) ) return 6;
//
//    else return 4;
//}

double min_distance_to_sphere ( neutron_struct & Neutron, double Radius ) {

    double a = std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta);
    double b = std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta);
    double c = std::sin(Neutron.direction.beta);

    double r02 = std::pow(Neutron.sos_position.x, 2.0) + std::pow(Neutron.sos_position.y, 2.0) + std::pow(Neutron.sos_position.z, 2.0);

    double b_term = 2.0 * ( a * Neutron.sos_position.x + b * Neutron.sos_position.y + c * Neutron.sos_position.z );
    double c_term = r02 - std::pow(Radius, 2.0);

    double first_answer  = ( -b_term + std::sqrt( std::pow(b_term, 2.0) - (4 * c_term) ) ) / 2.0;
    double second_answer = ( -b_term - std::sqrt( std::pow(b_term, 2.0) - (4 * c_term) ) ) / 2.0;

    if ( first_answer >= 0 && second_answer >= 0 ) return std::min( first_answer, second_answer );
    else if ( first_answer >= 0 && second_answer <  0 ) return first_answer;
    else if ( first_answer < 0  && second_answer >= 0 ) return second_answer;
    else return std::numeric_limits <double>::infinity();
}


void displacement_function( neutron_struct & Neutron,
                            const rectangular_geometry_struct & Geometry,
                            double Region1_Mix_Total_Macro_CS,
                            double Region2_Mix_Total_Macro_CS,
                            double Region3_Mix_Total_Macro_CS,
//                            double Region4_Mix_Total_Macro_CS,
//                            double Region5_Mix_Total_Macro_CS,
//                            double Region6_Mix_Total_Macro_CS,
                            multithread_mt64 & mt64 ){

    unsigned short int region;
    position_struct Position;

    double distance, speed;

    double A, S; // S is a multiple of mean free path.
    double a, b, c;

    double CS, MFP; // Macroscopic cross-section and mean free path.

    std::vector <double> Dist_to_interface(6, 0); // Multiple of mean free path to interface between regions.
    double Smallest_distance; // Smallest multiple of S.
    int i;

    bool new_region;

    Position = Neutron.sos_position;

    a = std::cos(Neutron.direction.alpha) * std::cos(Neutron.direction.beta);
    b = std::sin(Neutron.direction.alpha) * std::cos(Neutron.direction.beta);
    c = std::sin(Neutron.direction.beta);

    do{
        new_region = false;

        A = mt64.genRand_real2();
        if(A == 1){A = 0.9999999;}

        S = -log(1 - A);

        region = check_region(Position, Geometry);

        if(region == 1){CS = Region1_Mix_Total_Macro_CS;}
        else if(region == 2){CS = Region2_Mix_Total_Macro_CS;}
        else if(region == 3){CS = Region3_Mix_Total_Macro_CS;}
//        else if(region == 4){CS = Region4_Mix_Total_Macro_CS;}
//        else if(region == 5){CS = Region5_Mix_Total_Macro_CS;}
//        else if(region == 6){CS = Region6_Mix_Total_Macro_CS;}
        else{CS = std::numeric_limits<double>::infinity();}


        MFP = 1.0 / CS;


        Smallest_distance = S * MFP;

        Dist_to_interface[0] = ( Geometry.X1 - Position.x) / a;
        Dist_to_interface[1] = ( Geometry.Y1 - Position.y) / b;
        Dist_to_interface[2] = (-Geometry.X1 - Position.x) / a;
        Dist_to_interface[3] = (-Geometry.Y1 - Position.y) / b;

//        Dist_to_interface[4]  = ( Geometry.X2 - Position.x) / a;
//        Dist_to_interface[5]  = ( Geometry.Y2 - Position.y) / b;
//        Dist_to_interface[6]  = (-Geometry.X2 - Position.x) / a;
//        Dist_to_interface[7]  = (-Geometry.Y2 - Position.y) / b;
//
//        Dist_to_interface[8]  = ( Geometry.X3 - Position.x) / a;
//        Dist_to_interface[9]  = ( Geometry.Y3 - Position.y) / b;
//        Dist_to_interface[10] = (-Geometry.X3 - Position.x) / a;
//        Dist_to_interface[11] = (-Geometry.Y3 - Position.y) / b;

        Dist_to_interface[6] = ( Geometry.Z  - Position.z) / c;
        Dist_to_interface[5] = (-Geometry.Z  - Position.z) / c;
//        Smallest_distance = std::min( Smallest_distance, min_distance_to_sphere( Neutron, Geometry.R1 ) );
//        Smallest_distance = std::min( Smallest_distance, min_distance_to_sphere( Neutron, Geometry.R2 ) );
//        Smallest_distance = std::min( Smallest_distance, min_distance_to_sphere( Neutron, Geometry.R3 ) );
//        Smallest_distance = std::min( Smallest_distance, min_distance_to_sphere( Neutron, Geometry.R4 ) );
//        Smallest_distance = std::min( Smallest_distance, min_distance_to_sphere( Neutron, Geometry.R5 ) );
//        Smallest_distance = std::min( Smallest_distance, min_distance_to_sphere( Neutron, Geometry.R6 ) );
//        if ( Smallest_distance < (S * MFP) ) new_region = true;
        for(i = 0; i < 6; i++){
            if(Dist_to_interface[i] > 0 && Dist_to_interface[i] < Smallest_distance){
                Smallest_distance = Dist_to_interface[i];
                new_region = true;
            }
        }

        Position.x = Position.x + Smallest_distance * a;
        Position.y = Position.y + Smallest_distance * b;
        Position.z = Position.z + Smallest_distance * c;

    }while(new_region);

    Neutron.eos_position = Position;

    distance = std::sqrt( std::pow( (Neutron.eos_position.x - Neutron.sos_position.x) , 2 )
                        + std::pow( (Neutron.eos_position.y - Neutron.sos_position.y) , 2 )
                        + std::pow( (Neutron.eos_position.z - Neutron.sos_position.z) , 2 ) ) / 100.00;// 100 is a conversion factor from cm to m.

    speed = ( std::sqrt( 2 * Neutron.energy * (1 / 939.56537821) ) ) * 299792458;// Neutron mass in MeV/c^2, c in m/s.

    Neutron.step_length = distance;
    Neutron.time.step   = (distance / speed);
    Neutron.time.life  += Neutron.time.step;
    Neutron.time.chain += Neutron.time.step;

//    if(Neutron.eos_position.z > Geometry.Z){Neutron.eos_position.z -= (2 * Geometry.Z);}
//    if(Neutron.eos_position.z < (-Geometry.Z)){Neutron.eos_position.z += (2 * Geometry.Z);}

}
