#ifndef TRACKING_AND_INTERACTION_HEADER_H_INCLUDED
#define TRACKING_AND_INTERACTION_HEADER_H_INCLUDED

#include "Structs_header.h"
#include "Properties_Structs_header.h"
#include "Output.h"
#include "Fission_Functions_header.h"
#include "Fission_Buffer.h"
#include "Transfer_Counter.h"
#include "multithread_MT64.h"
#include "Region.h"


struct interaction {

    std::string Reaction;
    double Nuclide_Mass;
    double Molecule_Mass;

};


///Tracking.cpp
unsigned short int check_region(const position_struct& Position, const rectangular_geometry_struct& Geometry);

double radial_position (const position_struct& Position);

double min_distance_to_sphere ( neutron_struct & Neutron, double Radius );

void displacement_function( neutron_struct & Neutron,
                            const rectangular_geometry_struct & Geometry,
                            double Region1_Mix_Total_Macro_CS,
                            double Region2_Mix_Total_Macro_CS,
                            double Region3_Mix_Total_Macro_CS,
//                            double Region4_Mix_Total_Macro_CS,
//                            double Region5_Mix_Total_Macro_CS,
//                            double Region6_Mix_Total_Macro_CS,
                            multithread_mt64 & mt64);

///New_Direction.cpp
void new_direction( neutron_struct & Neutron, collision_struct & Collision, multithread_mt64 & mt64 );

void CM_to_Lab_CoordSystem_function(collision_struct& Collision, double MassNumber);


///Cross_Sections.cpp
void microscopic_cross_section_function( cross_sections_struct & Cross_Section, double Energy );

void macroscopic_cross_section_function(region_properties_struct& Region, const cross_sections_struct& Cross_Section);


///Interaction.cpp
void interaction_roulette( interaction_type_struct & Interaction,
                           isotope_type_struct & Isotope,
                           const region_properties_struct & Region,
                           multithread_mt64 & mt64 );


interaction interaction_roulette( region Region
                                , neutron_struct Neutron
                                , double         RandomEnergy
                                , double         RandomAlpha
                                , double         RandomBeta
                                , multithread_mt64 & mt64
                                );


///Tracking_and_Interaction.cpp
//bool tracking_and_interaction(neutron_struct Neutron, const interaction_type_struct& Interaction, const isotope_type_struct& Isotope,
//                              OutputMatrix <neutron_struct>& Scattering, OutputMatrix <neutron_struct>& Capture,
//                              OutputMatrix <fission_struct>& Fission, OutputMatrix <neutron_struct>& Thermalisation,
//                              FissionBuffer& Buffer, Transfer_Counter& Counter, const double Temperature);

#endif // TRACKING_AND_INTERACTION_HEADER_H_INCLUDED
