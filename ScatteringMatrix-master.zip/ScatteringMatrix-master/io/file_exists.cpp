#include <fstream>
#include <string>
#include "io/file_exists.hpp"

bool file_exists(const std::string name){
    bool state;

    std::ifstream f(name);
    state = f.good();
    f.close();

    return state;
}
