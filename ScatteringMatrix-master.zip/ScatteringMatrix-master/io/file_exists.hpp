#ifndef IO_FILE_EXISTS_HPP
#define IO_FILE_EXISTS_HPP

bool file_exists(const std::string name);

#endif // IO_FILE_EXISTS_HPP
