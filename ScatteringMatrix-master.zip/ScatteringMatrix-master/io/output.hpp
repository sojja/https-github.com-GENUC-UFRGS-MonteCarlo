#ifndef IO_OUTPUT_HPP
#define IO_OUTPUT_HPP

#include <iostream>
#include <fstream>
//#include <sstream>
#include <vector>

//#include <thread>
//#include <algorithm>
//#include "multi_logger.h"

class OutputVectorBuilder{
    public:

        virtual ~OutputVectorBuilder(){};

        template <typename type_of_vector>
         void VectorIncreaser(std::vector <type_of_vector>& Vector, unsigned int& next_storage_position, const type_of_vector& Data){

            if(Vector.size() == 0){Vector.resize(1000);}

            Vector[next_storage_position] = Data;

            next_storage_position++;
            if(next_storage_position >= Vector.size()){Vector.resize(Vector.size() + 1000);}
        }

        template <typename type_of_vector>
         void VectorDecreaser(std::vector <type_of_vector>& Vector, unsigned int& last_stored_position){

            Vector.erase(Vector.begin() + last_stored_position, Vector.end());
        }
};


class OutputMatrixBuilder: private OutputVectorBuilder{
    private:

        std::vector <unsigned int> next_storage_position;
        std::vector <unsigned int> last_stored_position;

    public:

        virtual ~OutputMatrixBuilder(){};

        void NumberOfLines(unsigned int number_of_lines){
            next_storage_position.resize(number_of_lines);
            last_stored_position.resize(number_of_lines);
        }

        template <typename type_of_data>
         void MatrixIncreaser(std::vector < std::vector <type_of_data> >& Matrix, unsigned int line_number, const type_of_data& Data){

            VectorIncreaser <type_of_data> (Matrix[line_number], next_storage_position[line_number], Data);

            last_stored_position[line_number] = next_storage_position[line_number];

        }

        template <typename type_of_data>
         void MatrixDecreaser(std::vector < std::vector <type_of_data> >& Matrix){

            unsigned int line_number;

            for(line_number = 0; line_number < Matrix.size(); line_number++){
                VectorDecreaser <type_of_data> (Matrix[line_number], last_stored_position[line_number]);
            }
        }
};


template <typename data_type> class OutputMatrix: private OutputMatrixBuilder{
    private:

        std::string filename;

        std::vector < std::vector <data_type> > DataMatrix;

        bool assigned_matrix = false;

    public:

        OutputMatrix(){}

        OutputMatrix(unsigned int number_of_steps){
            DataMatrix.resize(number_of_steps);
            NumberOfLines(number_of_steps);
        }

        OutputMatrix(const std::string name){
            filename = name;
        }

        OutputMatrix(unsigned int number_of_steps, const std::string name){
            DataMatrix.resize(number_of_steps);
            NumberOfLines(number_of_steps);
            filename = name;
        }

        ~OutputMatrix(){
            unsigned int number_of_elements = 0;
            unsigned int max_ele_per_line = 0;

            for(unsigned int i = 0; i < DataMatrix.size(); i++){
                    number_of_elements += DataMatrix[i].size();
                    max_ele_per_line = std::max( (unsigned int) DataMatrix[i].size(), max_ele_per_line );
            }

//            std::stringstream msg;
//            msg << "Matrix deallocated:\n"
//                << "    File:     " << filename << "\n"
//                << "    Elements: " << number_of_elements << "\n"
//                << "    Max elements in a line: " << max_ele_per_line << "\n"
//                << "    Bytes:    " << number_of_elements * sizeof(data_type) << "\n"
//                << std::endl;
//            Logger.to_file( "Log_Files/Output_Matrix_Log.txt", std::this_thread::get_id(), msg.str() );
        }

        void NumberOfSteps(unsigned int number_of_steps){
            DataMatrix.resize(number_of_steps);
            NumberOfLines(number_of_steps);
        }

        void Filename(const std::string name){
            filename = name;
        }


        void Add(const data_type& Data, unsigned int step_number){
            MatrixIncreaser <data_type> (DataMatrix, step_number, Data);
        }

        void Assign(const std::vector < std::vector <data_type> > NewMatrix){
            DataMatrix = NewMatrix;
            assigned_matrix = true;
        }

        void Reduce(){
            if(!assigned_matrix){ MatrixDecreaser(DataMatrix); }
        }


        void BinaryOutput(){
            std::ofstream File;

            Reduce();

            unsigned int i;
            unsigned int number_of_lines;
            std::vector <unsigned int> columns_per_line(DataMatrix.size());

            number_of_lines = DataMatrix.size();
            for(i = 0; i < DataMatrix.size(); i++){columns_per_line[i] = DataMatrix[i].size();}

            File.open(filename, std::ios::binary);
            if(!File.good()){std::cout << "Warning: BAD FILE - " << filename << std::endl;}

            File.write(reinterpret_cast<const char*>(&number_of_lines), sizeof(unsigned int));
            File.write(reinterpret_cast<const char*>(&columns_per_line[0]), columns_per_line.size()*sizeof(unsigned int));
            for(i = 0; i < DataMatrix.size(); i++){
                File.write(reinterpret_cast<const char*>(&DataMatrix[i][0]), DataMatrix[i].size()*sizeof(data_type));
            }

            File.close();
        }

        void BinaryOutput(const std::string name){
            std::ofstream File;

            Reduce();

            unsigned int i;
            unsigned int number_of_lines;
            std::vector <unsigned int> columns_per_line(DataMatrix.size());

            number_of_lines = DataMatrix.size();
            for(i = 0; i < DataMatrix.size(); i++){columns_per_line[i] = DataMatrix[i].size();}

            filename = name;

            File.open(filename, std::ios::binary);
            if(!File.good()){std::cout << "Warning: BAD FILE - " << filename << std::endl;}

            File.write(reinterpret_cast<const char*>(&number_of_lines), sizeof(unsigned int));
            File.write(reinterpret_cast<const char*>(&columns_per_line[0]), columns_per_line.size()*sizeof(unsigned int));
            for(i = 0; i < DataMatrix.size(); i++){
                File.write(reinterpret_cast<const char*>(&DataMatrix[i][0]), DataMatrix[i].size()*sizeof(data_type));
            }

            File.close();
        }


        void Clear(){
            unsigned int i;
            for(i = 0; i < DataMatrix.size(); i++){
                DataMatrix[i].clear();
            }
            DataMatrix.clear();
        }
};


template <typename data_type> class OutputVector{
    private:

        OutputMatrix <data_type> output_matrix;

    public:

        OutputVector(){
            output_matrix.NumberOfSteps(1);
        }

        OutputVector(const std::string name){
            output_matrix.NumberOfSteps(1);
            output_matrix.Filename(name);
        }

        void Add(const data_type& Data){
            output_matrix.Add(Data, 0);
        }

        void Assign(const std::vector <data_type> newVector){
            std::vector < std::vector <data_type> > newMatrix(1);
            newMatrix[0] = newVector;
            output_matrix.Assign(newMatrix);
        }

        void Reduce(){
            output_matrix.Reduce();
        }

        void BinaryOutput(){
            output_matrix.BinaryOutput();
        }

        void BinaryOutput(const std::string name){
            output_matrix.BinaryOutput(name);
        }

        void Clear(){
            output_matrix.Clear();
        }
};

#endif // IO_OUTPUT_HPP
