#ifndef MULTITHREAD_LOGGER_H_INCLUDED
#define MULTITHREAD_LOGGER_H_INCLUDED

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <utility>
#include <string>
#include <sstream>
#include <thread>
#include <future>
#include <mutex>

class multi_logger {
    private:

        std::map <std::thread::id, std::string> m_tmp_msg;

        std::string m_terminal_stored_msg;
        std::map <std::string, std::map <std::thread::id, std::string> > m_file_stored_msg;

        std::string m_save_terminal_filename;

        void clear_terminal();

        std::mutex m_mtx;

    public:

        multi_logger(std::string terminal_to_file_filename);

        ~multi_logger();

        void to_terminal_tmp(std::thread::id thread_id, std::string message);

        void to_terminal_store(std::thread::id thread_id, std::string message);

        void refresh_terminal();

        void save_terminal();

        void to_file(std::string filename, std::thread::id thread_id, std::string message);

        void save_file();
};

extern multi_logger Logger;

extern std::string log_filename;

#endif // MULTITHREAD_LOGGER_H_INCLUDED
