#include <iostream>
#include <iomanip>
#include <string>
#include "particles/particles.hpp"
#include "matrices/bin.hpp"
#include "mt64/mt64.hpp"
#include "io/input.hpp"
#include "io/output.hpp"
#include "io/file_exists.hpp"
#include "io/gnuplot.hpp"
#include "logger/multithread_logger.h"
#include "threadPool/threadPool.hpp"

void diff_energy_scattering ( unsigned int sample_size );

void scattering ( particle & neutron
                , particle & target
                , double theta
                );

multi_logger Logger("logs/Terminal.txt");

int main() {

//    particle Neutron (3.0, 1, {0, 0});
//    particle Target  (1.4, 1, {3*M_PI_4, 0});
//
//    std::cout << "Neutron: [" << Neutron.Velocity.transpose() << "]; Norm: " << Neutron.Velocity.norm() << "; Energy: " << Neutron.Energy << "\n";
//    std::cout << "Target:  [" << Target .Velocity.transpose() << "]; Norm: " << Target. Velocity.norm() << "; Energy: " << Target .Energy << "\n";
//
//    scattering(Neutron, Target, M_PI_4);
//
//    std::cout << "Neutron: [" << Neutron.Velocity.transpose() << "]; Norm: " << Neutron.Velocity.norm() << "; Energy: " << Neutron.Energy << "\n";
//    std::cout << "Target:  [" << Target .Velocity.transpose() << "]; Norm: " << Target. Velocity.norm() << "; Energy: " << Target .Energy << "\n";

    diff_energy_scattering(5000);
}


bin_result bin_simulation (bin_parameters Parameters) {

    bin_result result;
    result.CollisionEnergy.resize( Parameters.collision.n_log_bins, 0 );
    result.NeutronEnergy  .resize( Parameters.neutron.n_log_bins, 0 );

    mt64 mt64 (Parameters.initial_bin_number * 1000);

    auto chrono_start = std::chrono::system_clock::now();

    for (unsigned int i = 0; i < Parameters.sample_size; i++){

        double RandomEnergy = Parameters.initial.bin_inferior_energy[Parameters.initial_bin_number]
                            + Parameters.initial.bin_energy_range[Parameters.initial_bin_number] * mt64.genRand_real1();
        double RandomAlpha  = 2.0 * M_PI * mt64.genRand_real2();
        double RandomBeta   = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;

        particle Neutron ( RandomEnergy, 1.0, {RandomAlpha, RandomBeta} );


        RandomEnergy = mt64.genRand_real1();
        RandomAlpha  = 2.0 * M_PI * mt64.genRand_real2();
        RandomBeta   = std::acos( 2 * mt64.genRand_real1() - 1 ) - M_PI_2;

        particle Target ( RandomEnergy, 16.0, {RandomAlpha, RandomBeta} );

//            std::cout << "Neutron: [" << Neutron.Velocity.transpose() << "]; Norm: " << Neutron.Velocity.norm() << "; Energy: " << Neutron.Energy << "\n";
//            std::cout << "Target:  [" << Target .Velocity.transpose() << "]; Norm: " << Target. Velocity.norm() << "; Energy: " << Target .Energy << "\n";


        double theta = 2.0 * M_PI * mt64.genRand_real2();

        scattering(Neutron, Target, theta);

//            std::cout << "Neutron: [" << Neutron.Velocity.transpose() << "]; Norm: " << Neutron.Velocity.norm() << "; Energy: " << Neutron.Energy << "\n";
//            std::cout << "Target:  [" << Target .Velocity.transpose() << "]; Norm: " << Target. Velocity.norm() << "; Energy: " << Target .Energy << "\n";


        double collision_energy = Neutron.CollisionEnergy + Target.CollisionEnergy;

        unsigned int collision_bin_number = (unsigned int) std::floor( ( std::log(collision_energy) - std::log(Parameters.collision.min_energy) )
                                                                     * Parameters.collision.n_log_bins / std::log(Parameters.collision.energy_ratio)
                                                                     );

        unsigned int neutron_bin_number = (unsigned int) std::floor( ( std::log(Neutron.Energy) - std::log(Parameters.neutron.min_energy) )
                                                                   * Parameters.neutron.n_log_bins / std::log(Parameters.neutron.energy_ratio)
                                                                   );

        if ( collision_bin_number >= 0 && collision_bin_number < result.CollisionEnergy.size() ){
            result.CollisionEnergy[collision_bin_number] += 1.0 / ( ( (double) Parameters.sample_size ) * Parameters.collision.bin_energy_range[collision_bin_number] );
        } else { std::cout << "MENOR QUE 0!\n";}
        if ( neutron_bin_number >= 0 && neutron_bin_number < result.NeutronEnergy.size() ) {
            result.NeutronEnergy  [neutron_bin_number]   += 1.0 / ( ( (double) Parameters.sample_size ) * Parameters.neutron  .bin_energy_range[neutron_bin_number] );
        } else { std::cout << "MENOR QUE 0!!!\n";}

    }

    auto chrono_end = std::chrono::system_clock::now();

    std::stringstream msg;
    msg.str("");
    msg << "Interval: " << std::setw(4) << Parameters.initial_bin_number << "/" << Parameters.neutron.n_log_bins
        << "    "       << std::chrono::duration <double> (chrono_end - chrono_start).count() << "s";
    Logger.to_terminal_tmp( std::this_thread::get_id(), msg.str() );

    return result;
}



void diff_energy_scattering ( unsigned int sample_size ) {

    std::string gnuplot_path       = "results/gnuplot/";
    std::string neutron_filename   = "neutronEnergy.txt";
    std::string collision_filename = "collisionEnergy.txt";

    energy_parameters initial   (100, 0.1, 10);
    energy_parameters neutron   (1000, 0.001, 10000);
    energy_parameters collision (1000, 0.001, 10000);


//    for (size_t j = 0 ; j < 100 ; j++) {
//        std::cout << "initial.bin_inferior_energy[" << j << "] = "  << initial.bin_inferior_energy[j] << "\n";
//        std::cout << "initial.bin_superior_energy[" << j << "] = "  << initial.bin_superior_energy[j] << "\n";
//        std::cout << "initial.bin_energy_range["    << j << "] = "  << initial.bin_energy_range[j]    << "\n";
//    }
//
//    for (size_t j = 0 ; j < 1000 ; j++) {
//        std::cout << "neutron.bin_inferior_energy[" << j << "] = "  << neutron.bin_inferior_energy[j] << "\n";
//        std::cout << "neutron.bin_superior_energy[" << j << "] = "  << neutron.bin_superior_energy[j] << "\n";
//        std::cout << "neutron.bin_energy_range["    << j << "] = "  << neutron.bin_energy_range[j]    << "\n";
//    }
//
//    for (size_t j = 0 ; j < 1000 ; j++) {
//        std::cout << "collision.bin_inferior_energy[" << j << "] = "  << collision.bin_inferior_energy[j] << "\n";
//        std::cout << "collision.bin_superior_energy[" << j << "] = "  << collision.bin_superior_energy[j] << "\n";
//        std::cout << "collision.bin_energy_range["    << j << "] = "  << collision.bin_energy_range[j]    << "\n";
//    }


    std::vector <bin_parameters> Parameters;

    for( unsigned int bin_number = 0; bin_number < initial.n_log_bins; bin_number++ ) {
        bin_parameters parameter;
        parameter.sample_size        = sample_size;
        parameter.initial_bin_number = bin_number;
        parameter.initial            = initial;
        parameter.neutron            = neutron;
        parameter.collision          = collision;

        Parameters.push_back( parameter );
    }

    return_pool <bin_result, bin_parameters> ScatteringPool ( Parameters, 1, bin_simulation );

    auto chrono_start = std::chrono::system_clock::now();
    ScatteringPool.Run();

    std::vector <bin_result> results = ScatteringPool.Returns();
    auto chrono_end = std::chrono::system_clock::now();

    std::vector < std::vector <double> > CollisionEnergy;
    std::vector < std::vector <double> > NeutronEnergy;
    for ( size_t i = 0; i < results.size(); i++ ) {
        CollisionEnergy.push_back( results.at(i).CollisionEnergy );
        NeutronEnergy  .push_back( results.at(i).NeutronEnergy );
    }

    gnuplot_splot_output( initial.bin_inferior_energy, neutron.bin_inferior_energy, NeutronEnergy, (gnuplot_path + neutron_filename) );
    gnuplot_splot_output( initial.bin_inferior_energy, collision.bin_inferior_energy, CollisionEnergy, (gnuplot_path + collision_filename) );

    std::stringstream msg;
    msg.str("");
    msg << "Finish: "
        << std::chrono::duration <double> (chrono_end - chrono_start).count() << "s";
    Logger.to_terminal_store( std::this_thread::get_id(), msg.str() );
    Logger.refresh_terminal();

//    OutputMatrix <double> Computed_data;
//    Computed_data.Assign(Differential_Scattering_Matrix);
//    Computed_data.BinaryOutput( path.str() + filename.str() );
}
