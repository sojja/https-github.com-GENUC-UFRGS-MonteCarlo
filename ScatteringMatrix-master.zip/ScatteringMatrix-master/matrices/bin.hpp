#ifndef MATRICES_BIN_HPP
#define MATRICES_BIN_HPP

struct energy_parameters {
    unsigned int n_log_bins;
    double       min_energy;
    double       energy_ratio;

    std::vector <double> bin_inferior_energy;
    std::vector <double> bin_superior_energy;
    std::vector <double> bin_energy_range;

    energy_parameters ( unsigned int n_log_bins, double min_energy, double energy_ratio ) : n_log_bins          {n_log_bins}
                                                                                          , min_energy          {min_energy}
                                                                                          , energy_ratio        {energy_ratio}
                                                                                          , bin_inferior_energy (n_log_bins)
                                                                                          , bin_superior_energy (n_log_bins)
                                                                                          , bin_energy_range    (n_log_bins)
                                                                                          {
        for( size_t bin_number = 0; bin_number < n_log_bins; bin_number++ ) {
            bin_inferior_energy[bin_number] =  min_energy * std::pow( std::exp( std::log(energy_ratio) / (double)n_log_bins ), bin_number );
            bin_superior_energy[bin_number] =  min_energy * std::pow( std::exp( std::log(energy_ratio) / (double)n_log_bins ), ( bin_number + 1 ) );

            bin_energy_range[bin_number] = bin_superior_energy[bin_number] - bin_inferior_energy[bin_number];
        }
    }

    energy_parameters () = default;
};

struct bin_parameters {
    unsigned int sample_size;
    unsigned int initial_bin_number;

    energy_parameters initial;
    energy_parameters neutron;
    energy_parameters collision;

    bin_parameters () = default;
};


struct bin_result {
    std::vector <double> CollisionEnergy;
    std::vector <double> NeutronEnergy;
};

#endif // MATRICES_BIN_HPP
