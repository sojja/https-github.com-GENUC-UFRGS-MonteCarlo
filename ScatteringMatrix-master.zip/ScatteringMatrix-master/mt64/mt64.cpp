#include "mt64/mt64.hpp"

double mt64::genRand_real1 () {
    return (double) m_generator() / (double) m_generator.max();
}

double mt64::genRand_real2 () {
    return (double) m_generator() / ( (double) m_generator.max() + 1.0 );
}

double mt64::genRand_real3 () {
    return ( (double) m_generator() + 1.0 ) / ( (double) m_generator.max() + 2.0 );
}
