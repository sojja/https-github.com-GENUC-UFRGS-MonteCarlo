#ifndef MT64_MT64_HPP
#define MT64_MT64_HPP

#include <random>

class mt64{
    private:

        std::mt19937_64 m_generator;

    public:

        mt64 (unsigned seed) : m_generator(seed) {}

        double genRand_real1();

        double genRand_real2();

        double genRand_real3();
};

#endif // MT64_MT64_HPP
