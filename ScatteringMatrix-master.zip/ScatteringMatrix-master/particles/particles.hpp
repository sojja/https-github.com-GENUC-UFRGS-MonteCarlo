#ifndef PARTICLES_PARTICLES_HPP
#define PARTICLES_PARTICLES_HPP

#include <cmath>
#include <Eigen/Dense>
#include "particles/transformations.hpp"


struct birth{
    double          Energy;
    direction       Direction;
    Eigen::Vector3d Velocity;

    birth () {}

    birth (double Energy, direction Direction, Eigen::Vector3d Velocity) : Energy    {Energy}
                                                                         , Direction {Direction}
                                                                         , Velocity  {Velocity}
                                                                         {}
};


struct particle{
    double          Energy;
    double          CollisionEnergy;
    double          Mass;
    direction       Direction;
    Eigen::Vector3d Velocity;
    birth           Birth;

    particle (double Mass) : Mass {Mass}
                           {
        CollisionEnergy = 0;
    }

    particle (double Energy, double Mass, direction Direction) : Energy    {Energy}
                                                               , Mass      {Mass}
                                                               , Direction {Direction}
                                                               {
        Velocity = E2V(Energy, Mass, Direction);
        Birth = birth (Energy, Direction, Velocity);
        CollisionEnergy = 0;
    }
};


struct particleInPlane{
    double          Energy;
    double          CollisionEnergy;
    double          Mass;
    double          Angle;
    Eigen::Vector2d Velocity;

    particleInPlane (double Energy, double Mass, double Angle) : Energy {Energy}
                                                               , Mass   {Mass}
                                                               , Angle  {Angle}
                                                               {
        Velocity = E2V(Energy, Mass, Angle);
        CollisionEnergy = 0;
    }


    particleInPlane (Eigen::Vector2d Velocity, double Mass) : Mass     {Mass}
                                                            , Velocity {Velocity}
                                                            {
        std::tie(Energy, Angle) = V2E(Velocity, Mass);
        CollisionEnergy = 0;
    }
};

#endif // PARTICLES_PARTICLES_HPP
